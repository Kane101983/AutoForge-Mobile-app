$ErrorActionPreference='Stop'
Write-Host 'AutoForge PC Agent einrichten'
Write-Host 'Kopiert den Agenten fuer deinen Windows-Zugang und oeffnet danach den Verbindungscode.'
Write-Host 'Lokale KI-Modelle sind nicht enthalten. Bisherige Projektauftraege sind auf G:\gpt\AutoForge begrenzt.'
if (-not (Test-Path -LiteralPath 'G:\' -PathType Container)) { throw 'Dieser erste PC-Agent benoetigt Laufwerk G fuer seinen festgelegten Projektbereich. Es wurde nichts installiert.' }
if (Get-Process -Name 'AutoForge.Desktop' -ErrorAction SilentlyContinue) { throw 'AutoForge PC Agent laeuft bereits. Fuer die Kopplung kannst du den dort angezeigten Code verwenden. Fuer eine Neuinstallation bitte den Agenten zuerst beenden.' }
if ((Read-Host 'Installation fuer deinen Windows-Zugang starten? J/N') -notmatch '^(j|ja)$') { Write-Host 'Abgebrochen.';exit }
$sourceRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'agent'))
$installRoot=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'AutoForgePC\0.6.2'))
$manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'agent-sha256.json') -Raw | ConvertFrom-Json
foreach($entry in $manifest){
 $file=[IO.Path]::GetFullPath((Join-Path $sourceRoot $entry.path))
 if (-not $file.StartsWith($sourceRoot+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Ungueltiger Paketpfad' }
 if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $entry.sha256) { throw 'Paket ist beschaedigt. Bitte erneut herunterladen.' }
}
foreach($entry in $manifest){
 $target=[IO.Path]::GetFullPath((Join-Path $installRoot $entry.path))
 if (-not $target.StartsWith($installRoot+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Ungueltiger Installationspfad' }
 New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($target)) -Force | Out-Null
 Copy-Item -LiteralPath (Join-Path $sourceRoot $entry.path) -Destination $target -Force
}
if ((Read-Host 'PC im Heimnetz fuer die AutoForge-App erkennbar machen? J/N') -match '^(j|ja) 'AutoForge.Desktop.exe'
if (-not (Test-Path -LiteralPath $exe)) { throw 'Programm fehlt im Paket' }
$shell=New-Object -ComObject WScript.Shell
$shortcut=$shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'AutoForge PC Agent.lnk'))
$shortcut.TargetPath=$exe;$shortcut.WorkingDirectory=$installRoot;$shortcut.Save()
Write-Host 'Installiert. AutoForge zeigt am PC den Verbindungscode. Diesen im Handy eingeben.'
Start-Process -FilePath $exe -WorkingDirectory $installRoot
) { $discoveryDir=Join-Path $env:LOCALAPPDATA 'AutoForge';New-Item -ItemType Directory -Path $discoveryDir -Force | Out-Null;Set-Content -LiteralPath (Join-Path $discoveryDir 'discovery-enabled') -Value '1' }
$exe=Join-Path $installRoot 'AutoForge.Desktop.exe'
if (-not (Test-Path -LiteralPath $exe)) { throw 'Programm fehlt im Paket' }
$shell=New-Object -ComObject WScript.Shell
$shortcut=$shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'AutoForge PC Agent.lnk'))
$shortcut.TargetPath=$exe;$shortcut.WorkingDirectory=$installRoot;$shortcut.Save()
Write-Host 'Installiert. AutoForge zeigt am PC den Verbindungscode. Diesen im Handy eingeben.'
Start-Process -FilePath $exe -WorkingDirectory $installRoot
