@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
if errorlevel 1 echo Einrichtung fehlgeschlagen. Bitte den Hinweis oben beachten.
pause
