﻿namespace AutoForge.Policy;

public enum AutoForgeMode
{
    Observe,
    Assist,
    Autonomous,
    Owner
}

public sealed class PolicyEngine
{
    public AutoForgeMode Mode { get; private set; } =
        AutoForgeMode.Observe;

    public bool MayModifyFiles => false;
    public bool MayControlPrograms => false;
    public bool MayInstallSoftware => false;
    public bool MayUseGrid => false;

    public string Description =>
        "Beobachtungsmodus: AutoForge darf technische Systemwerte lesen, " +
        "aber keine Dateien, Programme oder Windows-Einstellungen verändern.";
}
