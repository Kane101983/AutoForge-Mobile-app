﻿namespace AutoForge.Core;

public static class AutoForgeInfo
{
    public const string Name = "AutoForge";
    public const string Version = "PC Agent v0.1";
}
