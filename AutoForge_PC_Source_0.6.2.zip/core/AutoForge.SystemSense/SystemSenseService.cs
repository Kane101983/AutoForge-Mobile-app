﻿using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

namespace AutoForge.SystemSense;

public sealed record ProcessInfo(
    string Name,
    int Id,
    double MemoryMb
);

public sealed record SystemSnapshot(
    string ComputerName,
    string Os,
    int LogicalProcessors,
    double CpuPercent,
    double TotalRamGb,
    double AvailableRamGb,
    double SystemDriveFreeGb,
    string NetworkStatus,
    int ProcessCount,
    IReadOnlyList<ProcessInfo> TopProcesses
);

public sealed class SystemSenseService
{
    private ulong _previousIdle;
    private ulong _previousKernel;
    private ulong _previousUser;
    private bool _hasCpuSample;

    public SystemSnapshot GetSnapshot()
    {
        var memory = GetMemory();
        var cpu = GetCpuUsage();

        var systemDrive = DriveInfo.GetDrives()
            .FirstOrDefault(d =>
                d.IsReady &&
                d.Name.Equals(
                    Path.GetPathRoot(Environment.SystemDirectory),
                    StringComparison.OrdinalIgnoreCase));

        double freeDisk =
            systemDrive == null
                ? 0
                : systemDrive.AvailableFreeSpace /
                  1024d / 1024d / 1024d;

        var processObjects =
            Process.GetProcesses();

        var processes =
            new List<ProcessInfo>();

        foreach (var process in processObjects)
        {
            try
            {
                processes.Add(
                    new ProcessInfo(
                        process.ProcessName,
                        process.Id,
                        Math.Round(
                            process.WorkingSet64 /
                            1024d / 1024d,
                            1)));
            }
            catch
            {
            }
            finally
            {
                process.Dispose();
            }
        }

        var top =
            processes
            .OrderByDescending(p => p.MemoryMb)
            .Take(10)
            .ToList();

        bool network =
            NetworkInterface
            .GetAllNetworkInterfaces()
            .Any(n =>
                n.OperationalStatus ==
                    OperationalStatus.Up &&
                n.NetworkInterfaceType !=
                    NetworkInterfaceType.Loopback);

        return new SystemSnapshot(
            Environment.MachineName,
            RuntimeInformation.OSDescription,
            Environment.ProcessorCount,
            Math.Round(cpu, 1),
            Math.Round(
                memory.Total /
                1024d / 1024d / 1024d,
                1),
            Math.Round(
                memory.Available /
                1024d / 1024d / 1024d,
                1),
            Math.Round(freeDisk, 1),
            network ? "Verbunden" : "Keine Verbindung",
            processObjects.Length,
            top);
    }

    private (ulong Total, ulong Available) GetMemory()
    {
        var status =
            new MEMORYSTATUSEX();

        status.dwLength =
            (uint)Marshal.SizeOf<MEMORYSTATUSEX>();

        if (!GlobalMemoryStatusEx(status))
            return (0, 0);

        return (
            status.ullTotalPhys,
            status.ullAvailPhys);
    }

    private double GetCpuUsage()
    {
        if (!GetSystemTimes(
            out var idle,
            out var kernel,
            out var user))
            return 0;

        ulong idleNow = ToUInt64(idle);
        ulong kernelNow = ToUInt64(kernel);
        ulong userNow = ToUInt64(user);

        if (!_hasCpuSample)
        {
            _previousIdle = idleNow;
            _previousKernel = kernelNow;
            _previousUser = userNow;
            _hasCpuSample = true;
            return 0;
        }

        ulong idleDelta =
            idleNow - _previousIdle;

        ulong kernelDelta =
            kernelNow - _previousKernel;

        ulong userDelta =
            userNow - _previousUser;

        ulong total =
            kernelDelta + userDelta;

        _previousIdle = idleNow;
        _previousKernel = kernelNow;
        _previousUser = userNow;

        if (total == 0)
            return 0;

        double busy =
            total - idleDelta;

        return Math.Clamp(
            busy * 100d / total,
            0,
            100);
    }

    private static ulong ToUInt64(
        FILETIME value)
    {
        return
            ((ulong)value.dwHighDateTime << 32) |
            value.dwLowDateTime;
    }

    [StructLayout(LayoutKind.Sequential)]
    private sealed class MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct FILETIME
    {
        public uint dwLowDateTime;
        public uint dwHighDateTime;
    }

    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(
        [In, Out] MEMORYSTATUSEX lpBuffer);

    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetSystemTimes(
        out FILETIME lpIdleTime,
        out FILETIME lpKernelTime,
        out FILETIME lpUserTime);
}
