using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace AutoForge.Desktop;

public sealed class RemoteBridgeService
{
    private const string SupabaseUrl = "https://teqirtttlcqzdnfrivxt.supabase.co";
    private const string PublishableKey = "sb_publishable_seeDF_uigEU2lxqt2wZVHw_XVN0OCLv";
    private const string AgentVersion = "0.6.2";
    public const string ProjectRoot = @"G:\gpt\AutoForge";

    private readonly HttpClient _http = new()
    {
        Timeout = TimeSpan.FromSeconds(90)
    };

    private readonly string _sessionFile =
        Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "AutoForge",
            "remote-session.json");

    private RemoteSession _session = new();

    public string? DeviceId => _session.DeviceId;
    public bool IsPaired { get; private set; }
    public string? PairingCode { get; private set; }
    public DateTimeOffset? PairingExpiresAt { get; private set; }

    public async Task InitializeAsync()
    {
        await EnsureSessionAsync();

        var payload = new JsonObject
        {
            ["action"] = "register_device",
            ["device_name"] = $"{Environment.MachineName} · AutoForge",
            ["machine_name"] = Environment.MachineName,
            ["agent_version"] = AgentVersion,
            ["capabilities"] = new JsonObject
            {
                ["system_sense"] = true,
                ["local_brain"] = File.Exists(Path.Combine(ProjectRoot, "modules", "brain", "Start-Brain.ps1")),
                ["brain_projects"] = File.Exists(Path.Combine(ProjectRoot, "modules", "brain", "Start-Brain.ps1")),
                ["brain_protocol"] = 1,
                ["remote_queue"] = true,
                ["project_scope"] = ProjectRoot,
                ["project_patch"] = true,
                ["build_test"] = true,
                ["live_progress"] = true,
                ["power_control"] = true,
                ["tray_mode"] = true,
                ["windows_autostart"] = true,
                ["wowlan_local_test"] = true,
                ["arbitrary_shell"] = false,
                ["outside_project_access"] = false
            }
        };

        var data = await RemoteRequestAsync(payload);
        var dev = data["device"] as JsonObject;
        if (dev == null)
            throw new InvalidOperationException("Remote Bridge lieferte kein Gerät zurück.");

        _session.DeviceId = dev["id"]?.GetValue<string>() ?? "";
        IsPaired = dev["paired"]?.GetValue<bool>() ?? false;
        PairingCode = data["pairing_code"]?.GetValue<string>();

        var exp = data["pairing_expires_at"]?.GetValue<string>();
        PairingExpiresAt =
            DateTimeOffset.TryParse(exp, out var dto) ? dto : null;

        SaveSession();
    }

    public async Task HeartbeatAsync(JsonObject status)
    {
        if (string.IsNullOrWhiteSpace(_session.DeviceId))
            return;

        var data = await RemoteRequestAsync(new JsonObject
        {
            ["action"] = "heartbeat",
            ["device_id"] = _session.DeviceId,
            ["status"] = status
        });

        IsPaired = data["paired"]?.GetValue<bool>() ?? IsPaired;
        if (IsPaired)
        {
            PairingCode = null;
            PairingExpiresAt = null;
        }
    }

    public async Task<JsonObject?> PullJobAsync()
    {
        if (string.IsNullOrWhiteSpace(_session.DeviceId) || !IsPaired)
            return null;

        var data = await RemoteRequestAsync(new JsonObject
        {
            ["action"] = "pull_job",
            ["device_id"] = _session.DeviceId
        });

        return data["job"] as JsonObject;
    }

    public async Task UpdateJobAsync(
        string jobId,
        string status,
        int progress,
        string message,
        JsonObject? result = null,
        string? error = null)
    {
        if (string.IsNullOrWhiteSpace(_session.DeviceId))
            return;

        await RemoteRequestAsync(new JsonObject
        {
            ["action"] = "job_update",
            ["device_id"] = _session.DeviceId,
            ["job_id"] = jobId,
            ["status"] = status,
            ["progress"] = Math.Clamp(progress, 0, 100),
            ["message"] = message,
            ["result"] = result ?? new JsonObject(),
            ["error"] = error
        });
    }

    public async Task<ProjectJobResult> ExecuteStructuredProjectJobAsync(
        JsonObject job,
        Func<int, string, Task>? localProgress = null)
    {
        var jobId = job["id"]?.GetValue<string>() ?? Guid.NewGuid().ToString("N");
        var payload = job["payload"] as JsonObject ?? new JsonObject();
        var kind = payload["kind"]?.GetValue<string>() ?? "";

        if (kind == "project_patch")
            return await ApplyPatchAsync(jobId, payload, localProgress);

        if (kind == "build_test")
            return await BuildProjectAsync(jobId, localProgress);

        return new ProjectJobResult(
            false,
            "Dieser Auftrag ist noch nicht als sichere strukturierte Aktion freigegeben.",
            "");
    }

    public async Task<ProjectJobResult> BuildProjectAsync(
        string jobId,
        Func<int, string, Task>? localProgress = null)
    {
        async Task Report(int pct, string msg)
        {
            if (localProgress != null)
                await localProgress(pct, msg);
            await UpdateJobAsync(jobId, "running", pct, msg);
        }

        var solution = Path.Combine(ProjectRoot, "AutoForge.slnx");
        await Report(12, "Sicherheitsprüfung: Projektpfad wird geprüft.");

        if (!File.Exists(solution))
            return new ProjectJobResult(false, "AutoForge.slnx wurde nicht gefunden.", solution);

        await Report(22, "Projektstruktur gefunden. Prüfe Abhängigkeiten.");
        var restore = await RunProcessAsync(
            "dotnet",
            $"restore \"{solution}\" --nologo",
            ProjectRoot);

        if (!restore.Success)
            return new ProjectJobResult(false, "Restore fehlgeschlagen.", restore.Details);

        await Report(45, "Abhängigkeiten sind bereit. Build wird gestartet.");
        var build = await RunProcessAsync(
            "dotnet",
            $"build \"{solution}\" --no-restore --nologo -p:UseAppHost=false",
            ProjectRoot);

        if (!build.Success)
        {
            await Report(90, "Build beendet. Fehler werden ausgewertet.");
            return new ProjectJobResult(false, "Build fehlgeschlagen.", build.Details);
        }

        await Report(88, "Build erfolgreich. Ausgabe wird geprüft.");
        await Task.Delay(250);
        await Report(96, "Buildprüfung abgeschlossen. Ergebnis wird an das Handy gesendet.");

        return new ProjectJobResult(
            true,
            "Build erfolgreich. Keine Dateien wurden verändert.",
            build.Details);
    }

    public static bool LooksLikeSafeBuildInstruction(string instruction)
    {
        var t = (instruction ?? "").ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(t)) return false;

        t = t.Replace("ändere noch keine dateien", "")
             .Replace("ändere keine dateien", "")
             .Replace("keine dateien ändern", "")
             .Replace("nichts ändern", "")
             .Replace("ohne etwas zu ändern", "");

        var wantsBuild =
            t.Contains("build") ||
            t.Contains("baue") ||
            t.Contains("bauen") ||
            t.Contains("kompilier") ||
            (t.Contains("prüf") && t.Contains("autoforge"));

        if (!wantsBuild) return false;

        string[] unsafeWords =
        {
            "lösche", "loesche", "installiere", "deinstalliere",
            "verschiebe", "kopiere nach", "registry", "regedit",
            "windows-einstellung", "formatier", "powershell", "cmd.exe",
            "außerhalb", "ausserhalb"
        };

        return !unsafeWords.Any(t.Contains);
    }

    public static string? DetectPowerAction(string instruction)
    {
        var t = (instruction ?? "").Trim().ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(t)) return null;

        if (t.Contains("nicht ausschalten") ||
            t.Contains("nicht herunterfahren") ||
            t.Contains("nicht neu starten") ||
            t.Contains("nicht schlafen"))
            return null;

        if (t.Contains("neu starten") ||
            t.Contains("neustart") ||
            t.Contains("reboot"))
            return "restart";

        if (t.Contains("herunterfahren") ||
            t.Contains("ausschalten") ||
            t.Contains("fahr den rechner runter") ||
            t.Contains("fahr den pc runter"))
            return "shutdown";

        if (t.Contains("energie sparen") ||
            t.Contains("standby") ||
            t.Contains("schlafen legen") ||
            t.Contains("in den schlaf"))
            return "sleep";

        if (t.Contains("aufwecken") ||
            t.Contains("weck den") ||
            t.Contains("einschalten") ||
            t.Contains("schalte den rechner ein") ||
            t.Contains("schalte den pc ein") ||
            t.Contains("mach den rechner an") ||
            t.Contains("mach den pc an"))
            return "wake";

        return null;
    }

    private async Task<ProjectJobResult> ApplyPatchAsync(
        string jobId,
        JsonObject payload,
        Func<int, string, Task>? localProgress)
    {
        if (payload["operations"] is not JsonArray operations || operations.Count == 0)
            return new ProjectJobResult(false, "Keine strukturierten Dateiänderungen enthalten.", "");

        var projectRoot = Path.GetFullPath(ProjectRoot)
            .TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;

        var backupRoot = Path.Combine(ProjectRoot, "backups", "remote", jobId);
        Directory.CreateDirectory(backupRoot);

        if (localProgress != null)
            await localProgress(15, "Sicherung wird erstellt.");
        await UpdateJobAsync(jobId, "running", 15, "Vor Änderungen wird eine Sicherung erstellt.");

        int written = 0;
        int total = operations.Count;

        foreach (var node in operations)
        {
            if (node is not JsonObject op)
                continue;

            var operation = op["op"]?.GetValue<string>() ?? "";
            if (!string.Equals(operation, "write_file", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException(
                    $"Remote-Operation '{operation}' ist nicht erlaubt.");

            var rel = (op["path"]?.GetValue<string>() ?? "")
                .Replace('/', Path.DirectorySeparatorChar)
                .TrimStart(Path.DirectorySeparatorChar);

            if (string.IsNullOrWhiteSpace(rel) ||
                rel.Contains(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal))
                throw new InvalidOperationException("Ungültiger relativer Dateipfad.");

            var target = Path.GetFullPath(Path.Combine(ProjectRoot, rel));
            if (!target.StartsWith(projectRoot, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Zugriff außerhalb G:\\gpt\\AutoForge wurde blockiert.");

            if (File.Exists(target))
            {
                var backupTarget = Path.Combine(backupRoot, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(backupTarget)!);
                File.Copy(target, backupTarget, true);
            }

            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            var content = op["content"]?.GetValue<string>() ?? "";
            await File.WriteAllTextAsync(target, content, new UTF8Encoding(false));
            written++;

            var pct = 20 + (int)Math.Round(30d * written / Math.Max(1, total));
            if (localProgress != null)
                await localProgress(pct, $"Datei {written}/{total} wird aktualisiert.");
        }

        await UpdateJobAsync(jobId, "running", 52, $"{written} Datei(en) aktualisiert. Sicherung vorhanden.");

        if (payload["build"]?.GetValue<bool>() == true)
        {
            var build = await BuildProjectAsync(jobId, localProgress);
            if (!build.Success)
                return new ProjectJobResult(
                    false,
                    $"{written} Datei(en) geändert, aber der Build ist fehlgeschlagen.",
                    build.Details);
        }

        return new ProjectJobResult(
            true,
            $"{written} Datei(en) sicher unter G:\\gpt\\AutoForge aktualisiert. Backup: {backupRoot}",
            "");
    }

    private static async Task<ProcessResult> RunProcessAsync(
        string fileName,
        string arguments,
        string workingDirectory)
    {
        var psi = new ProcessStartInfo
        {
            FileName = fileName,
            Arguments = arguments,
            WorkingDirectory = workingDirectory,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };

        using var process = Process.Start(psi);
        if (process == null)
            return new ProcessResult(false, "Prozess konnte nicht gestartet werden.");

        var stdoutTask = process.StandardOutput.ReadToEndAsync();
        var stderrTask = process.StandardError.ReadToEndAsync();

        await process.WaitForExitAsync();

        var stdout = await stdoutTask;
        var stderr = await stderrTask;
        var details = (stdout + Environment.NewLine + stderr).Trim();
        if (details.Length > 16000)
            details = details[^16000..];

        return new ProcessResult(process.ExitCode == 0, details);
    }

    public Task<JsonObject> SearchWebAsync(string query) => RemoteRequestAsync(new JsonObject { ["query"] = query, ["max_results"] = 6 }, "autoforge-search");

    private async Task<JsonObject> RemoteRequestAsync(JsonObject payload, string function = "autoforge-remote")
    {
        await EnsureSessionAsync();

        async Task<HttpResponseMessage> SendAsync()
        {
            using var req = new HttpRequestMessage(
                HttpMethod.Post,
                SupabaseUrl + "/functions/v1/" + function);

            req.Headers.Add("apikey", PublishableKey);
            req.Headers.Authorization =
                new AuthenticationHeaderValue("Bearer", _session.AccessToken);
            req.Headers.UserAgent.ParseAdd("AutoForge-PC/0.4.0");
            req.Content = new StringContent(
                payload.ToJsonString(),
                Encoding.UTF8,
                "application/json");

            return await _http.SendAsync(req);
        }

        var response = await SendAsync();

        if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
        {
            _session.AccessToken = "";
            _session.ExpiresAt = 0;
            await EnsureSessionAsync();
            response.Dispose();
            response = await SendAsync();
        }

        var raw = await response.Content.ReadAsStringAsync();
        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(
                $"Remote Bridge HTTP {(int)response.StatusCode}: {raw}");

        return JsonNode.Parse(raw) as JsonObject
            ?? throw new InvalidOperationException("Ungültige Remote-Antwort.");
    }

    private async Task EnsureSessionAsync()
    {
        LoadSession();

        var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        if (!string.IsNullOrWhiteSpace(_session.AccessToken) &&
            _session.ExpiresAt > now + 120)
            return;

        if (!string.IsNullOrWhiteSpace(_session.RefreshToken))
        {
            try
            {
                var refreshed = await AuthPostAsync(
                    "/auth/v1/token?grant_type=refresh_token",
                    new JsonObject { ["refresh_token"] = _session.RefreshToken });

                ApplyAuthResponse(refreshed);
                SaveSession();
                return;
            }
            catch
            {
                _session.AccessToken = "";
                _session.RefreshToken = "";
            }
        }

        var created = await AuthPostAsync(
            "/auth/v1/signup",
            new JsonObject
            {
                ["data"] = new JsonObject
                {
                    ["client"] = "autoforge-pc",
                    ["agent_version"] = AgentVersion
                }
            });

        ApplyAuthResponse(created);
        SaveSession();
    }

    private async Task<JsonObject> AuthPostAsync(string path, JsonObject body)
    {
        using var req = new HttpRequestMessage(HttpMethod.Post, SupabaseUrl + path);
        req.Headers.Add("apikey", PublishableKey);
        req.Headers.UserAgent.ParseAdd("AutoForge-PC/0.4.0");
        req.Content = new StringContent(
            body.ToJsonString(),
            Encoding.UTF8,
            "application/json");

        using var response = await _http.SendAsync(req);
        var raw = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(
                $"Cloud-Anmeldung HTTP {(int)response.StatusCode}: {raw}");

        return JsonNode.Parse(raw) as JsonObject
            ?? throw new InvalidOperationException("Ungültige Cloud-Anmeldung.");
    }

    private void ApplyAuthResponse(JsonObject auth)
    {
        var access = auth["access_token"]?.GetValue<string>() ?? "";
        var refresh = auth["refresh_token"]?.GetValue<string>() ?? "";
        if (string.IsNullOrWhiteSpace(access) || string.IsNullOrWhiteSpace(refresh))
            throw new InvalidOperationException("Supabase lieferte keine vollständige Sitzung.");

        _session.AccessToken = access;
        _session.RefreshToken = refresh;

        var expiresAt = auth["expires_at"]?.GetValue<long>() ?? 0;
        if (expiresAt <= 0)
        {
            var expiresIn = auth["expires_in"]?.GetValue<long>() ?? 3600;
            expiresAt = DateTimeOffset.UtcNow.ToUnixTimeSeconds() + expiresIn;
        }

        _session.ExpiresAt = expiresAt;
        _session.UserId =
            auth["user"]?["id"]?.GetValue<string>() ?? _session.UserId;
    }

    private void LoadSession()
    {
        try
        {
            if (!File.Exists(_sessionFile))
                return;

            var raw = File.ReadAllText(_sessionFile);
            _session = JsonSerializer.Deserialize<RemoteSession>(raw)
                ?? new RemoteSession();
        }
        catch
        {
            _session = new RemoteSession();
        }
    }

    private void SaveSession()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_sessionFile)!);
        File.WriteAllText(
            _sessionFile,
            JsonSerializer.Serialize(
                _session,
                new JsonSerializerOptions { WriteIndented = true }));
    }

    private sealed class RemoteSession
    {
        public string AccessToken { get; set; } = "";
        public string RefreshToken { get; set; } = "";
        public string UserId { get; set; } = "";
        public long ExpiresAt { get; set; }
        public string DeviceId { get; set; } = "";
    }

    private sealed record ProcessResult(bool Success, string Details);
}

public sealed record ProjectJobResult(
    bool Success,
    string Message,
    string Details);

