﻿using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace AutoForge.Desktop;

public static class PowerControlService
{
    [DllImport("powrprof.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetSuspendState(
        [MarshalAs(UnmanagedType.Bool)] bool hibernate,
        [MarshalAs(UnmanagedType.Bool)] bool forceCritical,
        [MarshalAs(UnmanagedType.Bool)] bool disableWakeEvent);

    public static void Sleep()
    {
        if (!SetSuspendState(false, false, false))
            throw new InvalidOperationException(
                "Windows konnte nicht in den Standby-Modus versetzt werden.");
    }

    public static void Restart(int delaySeconds = 10)
    {
        StartShutdown($"/r /t {Math.Max(0, delaySeconds)} /d p:0:0 /c \"AutoForge Remote-Neustart\"");
    }

    public static void Shutdown(int delaySeconds = 10)
    {
        StartShutdown($"/s /t {Math.Max(0, delaySeconds)} /d p:0:0 /c \"AutoForge Remote-Herunterfahren\"");
    }

    public static void CancelScheduledShutdown()
    {
        StartShutdown("/a");
    }

    private static void StartShutdown(string arguments)
    {
        var exe = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.System),
            "shutdown.exe");

        Process.Start(new ProcessStartInfo
        {
            FileName = exe,
            Arguments = arguments,
            UseShellExecute = false,
            CreateNoWindow = true
        });
    }
}


