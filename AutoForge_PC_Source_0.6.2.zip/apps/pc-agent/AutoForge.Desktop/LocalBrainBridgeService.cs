using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json.Nodes;

namespace AutoForge.Desktop;

public sealed class LocalBrainBridgeService
{
    private readonly HttpClient _http = new(new HttpClientHandler { UseProxy = false })
    { BaseAddress = new Uri("http://127.0.0.1:8787"), Timeout = TimeSpan.FromSeconds(280) };

    private async Task<bool> IsRunningAsync()
    {
        try
        {
            using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(5));
            var status = JsonNode.Parse(await _http.GetStringAsync("/api/status", timeout.Token));
            return status?["service"]?.GetValue<string>() == "autoforge-local-brain"
                && string.Equals(status?["root"]?.GetValue<string>(), RemoteBridgeService.ProjectRoot, StringComparison.OrdinalIgnoreCase)
                && status?["version"]?.GetValue<string>() is "0.2.0" or "0.3.0";
        }
        catch { return false; }
    }

    public async Task ProcessSearchAsync(RemoteBridgeService remote)
    {
        // Loopback requests are authenticated; external URLs and tokens stay in the existing bridge.
        JsonNode? state;
        try { using var wait = new CancellationTokenSource(TimeSpan.FromSeconds(2)); state = JsonNode.Parse(await _http.GetStringAsync("/api/state", wait.Token)); }
        catch { return; }
        async Task<JsonObject?> Post(string route, JsonObject body)
        {
            using var req = new HttpRequestMessage(HttpMethod.Post, route);
            req.Headers.Add("X-AutoForge-Token", state?["token"]?.GetValue<string>());
            req.Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json");
            using var response = await _http.SendAsync(req);response.EnsureSuccessStatusCode();
            return JsonNode.Parse(await response.Content.ReadAsStringAsync()) as JsonObject;
        }
        var task = (await Post("/api/tools/pull", new JsonObject()))?["task"] as JsonObject;
        if (task is null) return;
        JsonObject result;
        try { result = await remote.SearchWebAsync(task["query"]!.GetValue<string>()); }
        catch (Exception ex) { result = new JsonObject { ["error"] = "Internetsuche fehlgeschlagen: " + ex.Message }; }
        await Post("/api/tools/result", new JsonObject { ["id"] = task["id"]!.DeepClone(), ["result"] = result });
    }

    public async Task<JsonObject> ExecuteAsync(string jobId, JsonObject payload)
    {
        var operation = payload["operation"]?.GetValue<string>();
        if (operation is not ("list" or "delete-chat" or "history" or "chat" or "new-chat" or "memory" or "teach" or "learn-start" or "learn-status" or "learn-stop" or "learn-accept" or "projects" or "storage" or "project-build" or "practice-start" or "practice-status" or "practice-stop"))
            throw new InvalidOperationException("Diese KI-Aktion ist nicht freigegeben.");
        if (!await IsRunningAsync())
        {
            var start = new ProcessStartInfo("powershell.exe")
            { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden };
            // Fixed, installed launcher. No command, path or URL comes from the remote request.
            foreach (var arg in new[] { "-NoProfile", "-File", @"G:\gpt\AutoForge\modules\brain\Start-Brain.ps1", "-NoBrowser" })
                start.ArgumentList.Add(arg);
            using var process = Process.Start(start) ?? throw new InvalidOperationException("KI konnte nicht gestartet werden.");
            using var deadline = new CancellationTokenSource(TimeSpan.FromSeconds(60));
            await process.WaitForExitAsync(deadline.Token);
            if (!await IsRunningAsync()) throw new InvalidOperationException("Lokale KI v0.2 ist nicht erreichbar. Bitte am PC starten.");
        }
        var state = JsonNode.Parse(await _http.GetStringAsync("/api/state"));
        var input = new JsonObject { ["requestId"] = jobId, ["operation"] = operation };
        foreach (var key in new[] { "chatId", "message", "title", "body", "messageId", "answer", "learning", "noteId", "baseId", "review", "practice" })
            if (payload[key] is not null) input[key] = payload[key]!.DeepClone();
        using var request = new HttpRequestMessage(HttpMethod.Post, "/api/remote");
        request.Headers.Add("X-AutoForge-Token", state?["token"]?.GetValue<string>());
        request.Content = new StringContent(input.ToJsonString(), Encoding.UTF8, "application/json");
        using var response = await _http.SendAsync(request);
        var result = JsonNode.Parse(await response.Content.ReadAsStringAsync()) as JsonObject;
        if (!response.IsSuccessStatusCode || result is null || result["error"] is not null)
            throw new InvalidOperationException(result?["error"]?.GetValue<string>() ?? "Lokale KI antwortet nicht korrekt.");
        return result;
    }
}
