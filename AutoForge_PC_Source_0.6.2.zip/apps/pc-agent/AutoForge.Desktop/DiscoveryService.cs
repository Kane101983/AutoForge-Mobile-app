using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Text.Json.Nodes;

namespace AutoForge.Desktop;

// Discovery announces a name only. Pairing and every command still require the Cloud identity.
public sealed class DiscoveryService : IDisposable
{
    private UdpClient? _socket;
    private DateTime _lastReply = DateTime.MinValue;
    public void Start()
    {
        if (_socket != null) return;
        var networks = NetworkInterface.GetAllNetworkInterfaces()
            .Where(n => n.OperationalStatus == OperationalStatus.Up)
            .SelectMany(n => n.GetIPProperties().UnicastAddresses)
            .Where(a => a.Address.AddressFamily == AddressFamily.InterNetwork && Private(a.Address))
            .ToArray();
        if (networks.Length == 0) return;
        try { _socket = new UdpClient(new IPEndPoint(IPAddress.Any, 47771)); }
        catch (SocketException) { return; }
        var socket = _socket;
        _ = Task.Run(async () => {
            try {
                while (true) {
                    var packet = await socket.ReceiveAsync();
                    if (packet.Buffer.Length > 256 || DateTime.UtcNow - _lastReply < TimeSpan.FromSeconds(1)) continue;
                    var peer = packet.RemoteEndPoint.Address;
                    if (!Private(peer) || !networks.Any(n => SameSubnet(peer, n.Address, n.IPv4Mask))) continue;
                    JsonObject? request;
                    try { request = JsonNode.Parse(Encoding.UTF8.GetString(packet.Buffer)) as JsonObject; } catch { continue; }
                    var nonce = request?["nonce"]?.ToString() ?? "";
                    if (request?["service"]?.ToString() != "autoforge-discovery" || request?["v"]?.ToString() != "1" || nonce.Length != 32 || nonce.Any(c => !Uri.IsHexDigit(c))) continue;
                    var answer = new JsonObject { ["service"] = "autoforge-discovery", ["v"] = 1, ["nonce"] = nonce, ["name"] = Environment.MachineName, ["version"] = "0.6.2" };
                    var bytes = Encoding.UTF8.GetBytes(answer.ToJsonString());
                    await socket.SendAsync(bytes, packet.RemoteEndPoint);
                    _lastReply = DateTime.UtcNow;
                }
            } catch (SocketException) { } catch (ObjectDisposedException) { }
        });
    }
    private static bool Private(IPAddress ip) { var b = ip.GetAddressBytes(); return b.Length == 4 && (b[0] == 10 || b[0] == 192 && b[1] == 168 || b[0] == 172 && b[1] >= 16 && b[1] <= 31); }
    private static bool SameSubnet(IPAddress a, IPAddress b, IPAddress mask) { var aa=a.GetAddressBytes();var bb=b.GetAddressBytes();var mm=mask.GetAddressBytes();return aa.Length==4&&bb.Length==4&&mm.Length==4&&Enumerable.Range(0,4).All(i=>(aa[i]&mm[i])==(bb[i]&mm[i])); }
    public void Dispose() { _socket?.Dispose(); _socket=null; }
}
