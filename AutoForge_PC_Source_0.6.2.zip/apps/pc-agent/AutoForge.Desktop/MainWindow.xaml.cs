﻿using System.ComponentModel;
using System.Drawing;
using System.Net.NetworkInformation;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Threading;
using AutoForge.Policy;
using AutoForge.SystemSense;

namespace AutoForge.Desktop;

public partial class MainWindow : Window
{
    private readonly SystemSenseService _systemSense = new();
    private readonly PolicyEngine _policy = new();
    private readonly RemoteBridgeService _remote = new();
    private readonly DiscoveryService _discovery = new();
    private readonly LocalBrainBridgeService _brain = new();

    private readonly DispatcherTimer _systemTimer;
    private readonly DispatcherTimer _remoteTimer;
    private readonly System.Windows.Forms.NotifyIcon _trayIcon;

    private bool _remoteBusy;
    private bool _allowClose;
    private readonly bool _startHidden;

    public MainWindow()
    {
        InitializeComponent();

        _startHidden = Environment.GetCommandLineArgs()
            .Any(a => string.Equals(a, "--tray", StringComparison.OrdinalIgnoreCase));

        _systemTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(2)
        };
        _systemTimer.Tick += (_, _) => RefreshSystemState();

        _remoteTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(5)
        };
        _remoteTimer.Tick += async (_, _) => await RefreshRemoteAsync();

        var menu = new System.Windows.Forms.ContextMenuStrip();
        menu.Items.Add("AutoForge öffnen", null, (_, _) => Dispatcher.Invoke(ShowFromTray));
        menu.Items.Add("Beenden", null, (_, _) => Dispatcher.Invoke(ExitFromTray));

        Icon? icon = null;
        try
        {
            if (!string.IsNullOrWhiteSpace(Environment.ProcessPath))
                icon = System.Drawing.Icon.ExtractAssociatedIcon(Environment.ProcessPath);
        }
        catch { }

        _trayIcon = new System.Windows.Forms.NotifyIcon
        {
            Text = "AutoForge PC Agent · Remote aktiv",
            Icon = icon ?? SystemIcons.Application,
            Visible = true,
            ContextMenuStrip = menu
        };
        _trayIcon.DoubleClick += (_, _) => Dispatcher.Invoke(ShowFromTray);

        StateChanged += (_, _) =>
        {
            if (WindowState == WindowState.Minimized)
                HideToTray();
        };
        Closing += MainWindow_Closing;
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        RefreshSystemState();
        if (System.IO.File.Exists(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AutoForge", "discovery-enabled"))) _discovery.Start();
        _systemTimer.Start();

        await ConnectRemoteAsync();
        _remoteTimer.Start();

        if (_startHidden)
            HideToTray();
    }

    private void MainWindow_Closing(object? sender, CancelEventArgs e)
    {
        if (_allowClose)
        {
            _trayIcon.Visible = false;
            _trayIcon.Dispose();
            return;
        }

        e.Cancel = true;
        HideToTray();
    }

    private void HideToTray()
    {
        Hide();
        ShowInTaskbar = false;
    }

    private void ShowFromTray()
    {
        ShowInTaskbar = true;
        Show();
        WindowState = WindowState.Normal;
        Activate();
        Topmost = true;
        Topmost = false;
    }

    private void ExitFromTray()
    {
        _discovery.Dispose();
        _allowClose = true;
        _trayIcon.Visible = false;
        _trayIcon.Dispose();
        Close();
        System.Windows.Application.Current.Shutdown();
    }

    private void RefreshSystemState()
    {
        try
        {
            var s = _systemSense.GetSnapshot();

            CpuText.Text = $"{s.CpuPercent:0.0} %";
            RamText.Text = $"{s.TotalRamGb - s.AvailableRamGb:0.0} / {s.TotalRamGb:0.0} GB";
            DiskText.Text = $"{s.SystemDriveFreeGb:0.0} GB";
            NetworkText.Text = s.NetworkStatus;
            ComputerText.Text = s.ComputerName;
            OsText.Text = s.Os;
            CoreText.Text = s.LogicalProcessors.ToString();
            ProcessCountText.Text = s.ProcessCount.ToString();

            ProcessList.Items.Clear();
            foreach (var process in s.TopProcesses)
                ProcessList.Items.Add($"{process.Name}    ·    {process.MemoryMb:0.0} MB");

            LastUpdateText.Text = $"Letzte Prüfung: {DateTime.Now:HH:mm:ss}";
        }
        catch (Exception ex)
        {
            LastUpdateText.Text = $"System Sense Fehler: {ex.Message}";
        }
    }

    private async Task ConnectRemoteAsync()
    {
        try
        {
            SetCloudBadge(false, "● CLOUD VERBINDET…");
            RemoteStatusText.Text = "AutoForge Cloud wird verbunden…";
            await _remote.InitializeAsync();
            SetCloudBadge(true, "● CLOUD VERBUNDEN · FERNZUGRIFF AKTIV");
            UpdateRemoteUi();
            await RefreshRemoteAsync();
        }
        catch (Exception ex)
        {
            SetCloudBadge(false, "● CLOUD OFFLINE");
            RemoteStatusText.Text = "Remote Bridge nicht verbunden: " + ex.Message;
            PairCodePanel.Visibility = Visibility.Collapsed;
        }
    }

    private void SetCloudBadge(bool connected, string text)
    {
        CloudBadgeText.Text = text;
        if (connected)
        {
            CloudBadge.Background = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(16, 37, 26));
            CloudBadge.BorderBrush = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(69, 217, 147));
            CloudBadgeText.Foreground = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(101, 231, 168));
        }
        else
        {
            CloudBadge.Background = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(37, 32, 26));
            CloudBadge.BorderBrush = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(182, 139, 52));
            CloudBadgeText.Foreground = new System.Windows.Media.SolidColorBrush(
                System.Windows.Media.Color.FromRgb(255, 214, 110));
        }
    }

    private void UpdateRemoteUi()
    {
        if (_remote.IsPaired)
        {
            RemoteStatusText.Text =
                "✅ Mit AutoForge Cloud gekoppelt · Heim-PC ist von unterwegs erreichbar.";
            PairCodePanel.Visibility = Visibility.Collapsed;
        }
        else if (!string.IsNullOrWhiteSpace(_remote.PairingCode))
        {
            RemoteStatusText.Text = "Warte auf einmalige Kopplung mit deinem Handy.";
            PairCodeText.Text = _remote.PairingCode;
            PairCodePanel.Visibility = Visibility.Visible;
        }
        else
        {
            RemoteStatusText.Text = "Remote Bridge verbunden, aber noch nicht gekoppelt.";
            PairCodePanel.Visibility = Visibility.Collapsed;
        }
    }

    private void SetRemoteProgress(int percent, string message)
    {
        percent = Math.Clamp(percent, 0, 100);
        RemoteProgressBar.Value = percent;
        RemoteProgressPct.Text = $"{percent} %";
        RemoteStepText.Text = message;
        RemoteLiveLog.AppendText(
            $"[{DateTime.Now:HH:mm:ss}] {percent,3}%  {message}{Environment.NewLine}");
        RemoteLiveLog.ScrollToEnd();
    }

    private static string? GetWakeMac()
    {
        try
        {
            var nics = NetworkInterface.GetAllNetworkInterfaces()
                .Where(n =>
                    n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211 ||
                    n.Description.Contains("Wi-Fi", StringComparison.OrdinalIgnoreCase) ||
                    n.Description.Contains("Wireless", StringComparison.OrdinalIgnoreCase) ||
                    n.Description.Contains("AX200", StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(n => n.OperationalStatus == OperationalStatus.Up)
                .ToList();

            foreach (var nic in nics)
            {
                var bytes = nic.GetPhysicalAddress().GetAddressBytes();
                if (bytes.Length == 6)
                    return string.Join(":", bytes.Select(b => b.ToString("X2")));
            }
        }
        catch { }

        return null;
    }

    private JsonObject CreateRemoteStatus()
    {
            var s = _systemSense.GetSnapshot();
            return new JsonObject
            {
                ["summary"] =
                    $"CPU {s.CpuPercent:0}% · RAM {s.TotalRamGb - s.AvailableRamGb:0.0}/{s.TotalRamGb:0.0} GB · C: frei {s.SystemDriveFreeGb:0.0} GB",
                ["cpu_percent"] = s.CpuPercent,
                ["ram_total_gb"] = s.TotalRamGb,
                ["ram_available_gb"] = s.AvailableRamGb,
                ["disk_c_free_gb"] = s.SystemDriveFreeGb,
                ["process_count"] = s.ProcessCount,
                ["network"] = s.NetworkStatus,
                ["power_state"] = "online",
                ["autostart"] = true,
                ["tray_mode"] = true,
                ["wake_supported"] = !string.IsNullOrWhiteSpace(GetWakeMac()),
                ["wake_method"] = "wowlan_local",
                ["wake_mac"] = GetWakeMac() ?? ""
            };

    }

    private async Task RefreshRemoteAsync()
    {
        if (_remoteBusy)
            return;

        _remoteBusy = true;

        try
        {
            var status = CreateRemoteStatus();

            await _remote.HeartbeatAsync(status);
            SetCloudBadge(true, "● CLOUD VERBUNDEN · FERNZUGRIFF AKTIV");
            UpdateRemoteUi();

            await _brain.ProcessSearchAsync(_remote);
            var job = await _remote.PullJobAsync();
            if (job != null)
                await HandleRemoteJobAsync(job);
        }
        catch (Exception ex)
        {
            SetCloudBadge(false, "● CLOUD OFFLINE");
            RemoteStatusText.Text = "⚠ Remote Bridge: " + ex.Message;
        }
        finally
        {
            _remoteBusy = false;
        }
    }

    private async Task HandleRemoteJobAsync(JsonObject job)
    {
        var jobId = job["id"]?.GetValue<string>() ?? "";
        var type = job["job_type"]?.GetValue<string>() ?? "project_task";
        var instruction = job["instruction"]?.GetValue<string>() ?? "Remote-Auftrag";
        var payload = job["payload"] as JsonObject ?? new JsonObject();
        var kind = payload["kind"]?.GetValue<string>() ?? "";

        RemoteJobText.Text = "📨 " + instruction;
        RemoteLiveLog.Clear();
        SetRemoteProgress(5, "Auftrag vom Handy empfangen.");

        try
        {
            // Dispatch structured AI requests before any natural-language power/build heuristic.
            if (kind == "local_brain")
            {
                await _remote.UpdateJobAsync(jobId, "running", 15, "Deine lokale KI auf ROBERT arbeitet.");
                var pending = _brain.ExecuteAsync(jobId, payload);
                while (!pending.IsCompleted)
                {
                    if (await Task.WhenAny(pending, Task.Delay(10000)) == pending) break;
                    // Keep the device online while inference runs, without pulling a second job.
                    try { await _remote.HeartbeatAsync(CreateRemoteStatus()); await _brain.ProcessSearchAsync(_remote); }
                    catch { /* Inference can finish locally during a temporary cloud outage. */ }
                }
                var result = await pending;
                await _remote.UpdateJobAsync(jobId, "completed", 100, "Lokale KI: Ergebnis bereit.", result);
                SetRemoteProgress(100, "Ergebnis deiner lokalen KI wurde übertragen.");
                return;
            }

            if (type == "status_check")
            {
                SetRemoteProgress(40, "Systemstatus wird gelesen.");
                var s = _systemSense.GetSnapshot();
                await _remote.UpdateJobAsync(
                    jobId,
                    "completed",
                    100,
                    "Systemstatus übertragen.",
                    new JsonObject
                    {
                        ["cpu_percent"] = s.CpuPercent,
                        ["ram_total_gb"] = s.TotalRamGb,
                        ["ram_available_gb"] = s.AvailableRamGb,
                        ["disk_c_free_gb"] = s.SystemDriveFreeGb,
                        ["network"] = s.NetworkStatus,
                        ["wake_mac"] = GetWakeMac() ?? ""
                    });

                SetRemoteProgress(100, "Systemstatus wurde an das Handy gesendet.");
                RemoteJobText.Text = "✅ Systemstatus wurde an die Cloud gesendet.";
                return;
            }

            var powerAction =
                kind == "power_action"
                    ? payload["action"]?.GetValue<string>()
                    : RemoteBridgeService.DetectPowerAction(instruction);

            if (!string.IsNullOrWhiteSpace(powerAction))
            {
                await HandlePowerActionAsync(jobId, powerAction!);
                return;
            }

            var safeBuild =
                type == "build_test" ||
                kind == "build_test" ||
                RemoteBridgeService.LooksLikeSafeBuildInstruction(instruction);

            if (safeBuild)
            {
                await _remote.UpdateJobAsync(
                    jobId, "running", 8,
                    "Sicherer Build-Auftrag wird vorbereitet.");

                var result = await _remote.BuildProjectAsync(
                    jobId,
                    async (pct, msg) =>
                    {
                        SetRemoteProgress(pct, msg);
                        await Task.CompletedTask;
                    });

                await _remote.UpdateJobAsync(
                    jobId,
                    result.Success ? "completed" : "failed",
                    100,
                    result.Message,
                    new JsonObject
                    {
                        ["message"] = result.Message,
                        ["details"] = result.Details,
                        ["action"] = "build_test",
                        ["project"] = @"G:\gpt\AutoForge"
                    },
                    result.Success ? null : result.Message);

                SetRemoteProgress(100, result.Message);
                RemoteJobText.Text = (result.Success ? "✅ " : "❌ ") + result.Message;
                return;
            }

            if (kind == "project_patch")
            {
                await _remote.UpdateJobAsync(
                    jobId, "running", 10,
                    "Strukturierter Projektauftrag wird ausgeführt.");

                var result = await _remote.ExecuteStructuredProjectJobAsync(
                    job,
                    async (pct, msg) =>
                    {
                        SetRemoteProgress(pct, msg);
                        await Task.CompletedTask;
                    });

                await _remote.UpdateJobAsync(
                    jobId,
                    result.Success ? "completed" : "failed",
                    100,
                    result.Message,
                    new JsonObject
                    {
                        ["message"] = result.Message,
                        ["details"] = result.Details
                    },
                    result.Success ? null : result.Message);

                SetRemoteProgress(100, result.Message);
                RemoteJobText.Text = (result.Success ? "✅ " : "❌ ") + result.Message;
                return;
            }

            await _remote.UpdateJobAsync(
                jobId,
                "waiting_approval",
                10,
                "Auftrag empfangen. Diese Art von Änderung benötigt noch eine strukturierte Freigabe.");

            SetRemoteProgress(10, "Wartet auf sichere strukturierte Freigabe.");
            RemoteJobText.Text =
                "🟡 Auftrag empfangen: " + instruction +
                "\nBuilds und bestätigte Power-Aktionen können v0.4 automatisch laufen; freie Systembefehle bleiben gesperrt.";
        }
        catch (Exception ex)
        {
            await _remote.UpdateJobAsync(
                jobId,
                "failed",
                100,
                "Remote-Auftrag fehlgeschlagen.",
                error: ex.Message);

            SetRemoteProgress(100, "Fehler: " + ex.Message);
            RemoteJobText.Text = "❌ " + ex.Message;
        }
    }

    private async Task HandlePowerActionAsync(string jobId, string action)
    {
        action = action.Trim().ToLowerInvariant();

        if (action == "wake")
        {
            await _remote.UpdateJobAsync(
                jobId, "completed", 100,
                "Der Rechner ist bereits eingeschaltet und mit AutoForge verbunden.",
                new JsonObject
                {
                    ["action"] = "wake",
                    ["already_online"] = true
                });
            SetRemoteProgress(100, "Der Rechner ist bereits eingeschaltet.");
            RemoteJobText.Text = "✅ Rechner ist bereits online.";
            return;
        }

        if (action == "sleep")
        {
            SetRemoteProgress(45, "Standby wird vorbereitet.");
            await _remote.UpdateJobAsync(
                jobId, "completed", 100,
                "Standby wird jetzt aktiviert. AutoForge verbindet sich nach dem Aufwecken automatisch wieder.",
                new JsonObject { ["action"] = "sleep" });

            SetRemoteProgress(100, "Standby wird aktiviert.");
            RemoteJobText.Text = "🌙 Rechner wechselt in Standby.";
            await Task.Delay(1200);
            PowerControlService.Sleep();
            return;
        }

        if (action == "restart")
        {
            SetRemoteProgress(55, "Neustart wird vorbereitet.");
            await _remote.UpdateJobAsync(
                jobId, "completed", 100,
                "Windows wird in 10 Sekunden neu gestartet. AutoForge startet danach automatisch im Hintergrund.",
                new JsonObject
                {
                    ["action"] = "restart",
                    ["delay_seconds"] = 10
                });

            SetRemoteProgress(100, "Neustart in 10 Sekunden.");
            RemoteJobText.Text = "🔄 Neustart geplant · 10 Sekunden.";
            PowerControlService.Restart(10);
            return;
        }

        if (action == "shutdown")
        {
            SetRemoteProgress(55, "Herunterfahren wird vorbereitet.");
            await _remote.UpdateJobAsync(
                jobId, "completed", 100,
                "Windows wird in 10 Sekunden heruntergefahren.",
                new JsonObject
                {
                    ["action"] = "shutdown",
                    ["delay_seconds"] = 10
                });

            SetRemoteProgress(100, "Herunterfahren in 10 Sekunden.");
            RemoteJobText.Text = "⏻ Herunterfahren geplant · 10 Sekunden.";
            PowerControlService.Shutdown(10);
            return;
        }

        throw new InvalidOperationException(
            $"Power-Aktion '{action}' ist nicht freigegeben.");
    }
}




