AutoForge Mobile v0.8.7 – Remote Bridge

Neu:
- Neuer Tab „Mein PC“
- Heim-PC per 6-stelligem Code sicher mit dem mobilen AutoForge-Konto koppeln
- Online/Offline-Status des AutoForge PC Agent anzeigen
- System-Sense-Kurzstatus vom Heim-PC anzeigen
- Remote-Aufträge aus der App an den PC senden
- Zentrale Remote Bridge über Supabase
- Keine Portfreigabe am Router nötig
- PC-seitiger Sicherheitsbereich bleibt G:\gpt\AutoForge
- Kritische Systemaktionen bleiben gesperrt

Wichtig:
Dazu gehört der PC Agent v0.2. Einmal den PC-Agenten aktualisieren, dann den
angezeigten 6-stelligen Code in AutoForge Mobile unter „Mein PC“ eingeben.
