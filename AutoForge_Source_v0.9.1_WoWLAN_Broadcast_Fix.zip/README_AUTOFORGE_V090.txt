AutoForge Mobile v0.9.0 – Always Connected + Power Control

- Mein PC zeigt Online/Offline, Agent-Version und Live-Systemstatus.
- Eigene PC-Steuerung: Standby, Neustart und Herunterfahren mit Bestätigung.
- Freitext wie „Mach den Rechner an“ wird als Power-Befehl erkannt statt als Builder-Auftrag.
- Lokaler WoWLAN-Test im selben Heim-WLAN über die vom PC gemeldete WLAN-MAC.
- Wake von unterwegs ist bewusst noch nicht aktiv: dafür braucht es einen Wake-Node oder eine geeignete Router-Brücke.
- Remote-Builder-Livefortschritt bleibt erhalten.
- Normale Nutzer benötigen keine API-Schlüssel.
