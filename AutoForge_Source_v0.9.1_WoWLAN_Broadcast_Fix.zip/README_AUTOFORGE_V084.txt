AutoForge Mobile v0.8.4 – Context / Cloud Sync / Image Intent Fix

- Bild mit Auftrag wie „Mach mir den Mann am Strand“ wird als image_edit erkannt, auch ohne das Wort Bild.
- Kurze Bild-Folgeantworten wie „Stehen“, „heller“, „jünger“ verwenden den aktiven Bildkontext desselben Chats.
- Unabhängige neue Aufgaben wie Web-/Autosuche übernehmen keinen alten Bildkontext.
- „Wo ist das Bild?“ wird nicht mehr fälschlich als generische capability=image geroutet.
- Veraltete Cloud-Chat-IDs nach anonymer Neu-Anmeldung werden automatisch neu verknüpft.
- Cloud-Sync versucht bei ungültiger alter Chat-Zuordnung automatisch einen frischen Cloud-Chat.
- Cloud-Router erhält has_images zur robusteren serverseitigen Einordnung.
- Ergebnisbilder werden als neuer Bildkontext im laufenden Chat gehalten.
