AutoForge Mobile v0.7.3 – Stable Signing & Backup

Neu:
- Backup/Import für Chats, Chat-Gedächtnis und ungefährliche Einstellungen.
- Cloud-Schlüssel, PC-Token und das lokale ~550-MB-Modell werden absichtlich NICHT exportiert.
- Release-Build ist für eine dauerhaft gleiche Signatur vorbereitet.
- VersionCode 19 / VersionName 0.7.3.

WICHTIG ZUR SIGNATUR:
Die bisher auf dem Handy installierten Debug-Builds wurden von wechselnden GitHub-Runnern signiert.
Darum kann die erste dauerhaft signierte AutoForge-Version die alte App nicht aktualisieren.
Einmalig muss die alte Debug-App entfernt und die neue Release-APK installiert werden.
Danach funktionieren Updates normal – solange derselbe AutoForge-Signierschlüssel verwendet wird.

Den Signierschlüssel niemals in ein öffentliches GitHub-Repository hochladen.
Speichere das separate Signing-Bundle sicher außerhalb des Repositories.
