AutoForge Mobile v0.8.8 – Remote Feedback Fix

- PC-Statusprüfung als eigener sicherer Remote-Job
- Freitext wie „Prüfe meinen PC-Status“ wird als status_check erkannt
- Handy wartet auf Rückmeldung des Heim-PCs und zeigt CPU/RAM/Speicher/Netzwerk
- Neuer Button „PC jetzt prüfen“
- Remote-Aufträge zeigen running/completed/failed/waiting_approval statt nur „gesendet“
- Keine Änderung an der bestehenden Kopplung erforderlich
