AutoForge Mobile v0.7.1 – Chats, Langzeit-Kontext, Links & Einfach-Modus

Neu:
- Mehrere getrennte Chats wie bei ChatGPT (☰ oben links, Neuer Chat, Umbenennen/Löschen).
- Chatverlauf wird lokal auf dem Gerät gespeichert und zusätzlich im App-Dateispeicher gesichert.
- Jeder Chat hat eigenes Langzeitgedächtnis: ältere Nachrichten werden kompakt zusammengefasst, die letzten Nachrichten vollständig als Kontext an die KI weitergegeben.
- Folgefragen wie „Hast du mein Foto von eben bearbeitet?“ werden als Gesprächsfolge erkannt und nicht fälschlich als neue Bildgenerierung geroutet.
- Antworten unterstützen anklickbare https-Links und Markdown-Links; externe Links öffnen im Browser.
- Bei Such-/Bestell-/Restaurant-Fragen ergänzt AutoForge echte anklickbare Suchlinks (Google, Maps, bei Essen zusätzlich Lieferando).
- Einfach-Modus ist standardmäßig aktiv und blendet technische Provider-Menüs aus.
- Familie/Freunde können die APK installieren und lokale Chat-/Textfunktionen ohne Provider-Konfiguration nutzen. Für Cloud-Bilder/Video ist weiterhin ein eigener Cloud-Zugang oder ein verbundener AutoForge-PC nötig.
- Native Tastatur-/Systemleisten-Korrektur aus v0.6.5 bleibt erhalten.
- Universal Router, Vision, Bildbearbeitung, KI-Scout und Fortsetzungs-Engine bleiben enthalten.

Hinweis zu Cloud-Zugängen:
AutoForge speichert keinen gemeinsamen geheimen Schlüssel in der APK. Das wäre unsicher und würde bei Weitergabe der App dein Kontingent mit anderen teilen. Im Einfach-Modus gibt es deshalb nur ein einzelnes Feld „Cloud-Zugangsschlüssel“; die technischen Provider-Felder bleiben verborgen. Später kann ein OAuth/PKCE-Login ergänzt werden, wenn ein eigener App-Client registriert ist.
