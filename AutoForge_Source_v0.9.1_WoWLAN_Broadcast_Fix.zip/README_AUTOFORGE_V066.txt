AutoForge Mobile v0.6.6

Fixes:
- Pollinations image edit now uses the documented multipart/form-data endpoint.
- Pollinations field is a bearer access key (sk_), not a publishable pk_ app key.
- Live /image/models discovery for image editing.
- Automatic ranking / failover across discovered image-edit models.
- One-tap link to Pollinations key page.
- Existing native Samsung keyboard fix retained.

Cloud image generation still requires a provider login/token because current public providers no longer permit anonymous generation calls. AutoForge can discover model catalogs without a key, but cannot execute a cloud generation without provider authorization.
