AutoForge Mobile v0.7.2 – Stability / Progress / Chat Control

Neu:
- Modi heißen jetzt „Kontrolliert“ und „Automatisch“; Auswahl bleibt nach Neustart gespeichert.
- Sichtbarer Auftragsstatus mit ungefährem Fortschritt, aktuellem Schritt, Provider und Laufzeit.
- Einzelne Chats haben einen sichtbaren Papierkorb; zusätzlich „Alle Chats löschen“.
- Lokale Qwen2.5-0.5B-KI ist als Offline-Fallback gekennzeichnet.
- Lokale Antworten werden auf Wiederholungen geprüft und bei Bedarf einmal kurz neu versucht.
- Im Modus Automatisch werden eingerichtete stärkere kostenlose Cloud-Provider vor der kleinen lokalen Fallback-KI versucht.
- Lokale Inferenz nutzt weniger Tokens/KV-Speicher (512 Tokens) und konservativere Sampling-Werte, um Abstürze/Wiederholungen zu reduzieren.
- Nach App-Neustart wird ein unterbrochener Auftrag als unterbrochen markiert; Senden ist wieder möglich.
- KI-Scout-Cap wurde deutlich erhöht: OpenRouter/Pollinations plus bis zu 500 aktuelle Hugging-Face-Modelle; Treffer werden als Katalogkandidaten gekennzeichnet.
- Scout zeigt getrennt, wie viele Kandidaten mit den aktuell eingerichteten Adaptern tatsächlich direkt nutzbar sind.

Hinweis:
Die ~550-MB-KI ist bewusst klein und offline nutzbar. Sie kann qualitativ nicht mit großen Cloud-Modellen mithalten.
