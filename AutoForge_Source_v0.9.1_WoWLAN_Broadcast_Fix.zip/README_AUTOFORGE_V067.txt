AutoForge Mobile v0.6.7 – Vision / Image Understanding Fix

Neu:
- image_understand ist jetzt vollständig an Pollinations Vision angebunden.
- Bilder werden als Data-URL an ein multimodales Modell weitergegeben.
- Vision-Modelle werden aus dem Live-Katalog gesucht und automatisch mit Fallback ausprobiert.
- Optionales eigenes Vision-Modell in Einstellungen.
- Pollinations-Schlüsselhinweis auf mobile Publishable Keys (pk_) angepasst.
- Continuation/Resume, Bildbearbeitung, Tastatur-Fix und Provider-Failover bleiben erhalten.

Hinweis: Für Cloud-Generierung/-Analyse ist ein autorisierter Provider-Zugang nötig. AutoForge kann keine internen Zwischenstände eines fremden Providers auslesen, wenn dieser vor jeder Ausgabe abbricht.
