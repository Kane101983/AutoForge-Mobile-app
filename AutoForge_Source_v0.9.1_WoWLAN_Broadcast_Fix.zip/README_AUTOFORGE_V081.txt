AutoForge Mobile v0.8.1 - Attachment Lifecycle Fix

Fix:
- Ein Anhang gehoert jetzt nur zu der Nachricht, mit der er gesendet wurde.
- Nach dem Absenden wird der Anhang sofort aus dem Eingabefeld entfernt, auch wenn der Auftrag spaeter fehlschlaegt.
- Der laufende Auftrag behaelt intern trotzdem seine Datei fuer Vision/Bildbearbeitung/PC-Upload und Failover.
- Spaetere Textfragen werden nicht mehr versehentlich als Bildanalyse behandelt.
- Fehlerhafte Auftraege lassen keine alten Anhänge im Composer zurueck.

VersionCode 21 / VersionName 0.8.1
