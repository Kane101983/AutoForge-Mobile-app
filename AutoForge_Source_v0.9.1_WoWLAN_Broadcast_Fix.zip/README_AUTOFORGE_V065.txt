AutoForge Mobile v0.6.5 – Native IME/System-Bar Fix

- Android/Samsung keyboard height is handled natively via WindowInsets.Type.ime().
- Status/navigation bars are reserved natively.
- WebView is laid out only inside the actually visible area.
- Composer remains inside the visible WebView and cannot sit behind the keyboard.
- Continuation/Resume, Universal Router, attachments, KI-Scout and MediaPipe fixes retained.
