AutoForge Mobile v0.8.6 – Semantic Router + Live Web Scout

Neu:
- Live-Websuche liefert echte aktuelle Treffer statt nur Google-Suchlinks.
- Suchtreffer werden als anklickbare Karten mit Titel, Quelle, Beschreibung und – wenn verfügbar – Vorschaubild angezeigt.
- AutoForge Web Scout nutzt einen Suchdienst plus KI-Ranking; Pollinations LixSearch kann serverseitig als Such-KI genutzt werden.
- Semantischer Router versteht kurze/mehrdeutige Folgefragen und Tippfehler im Chatkontext besser.
- Beispiel: „Liks zu gebrauchten Autos“ wird im passenden Kontext als „Links zu gebrauchten Autos“ verstanden.
- „links“ bedeutet nur bei klar räumlicher Formulierung wie „nach links“ eine Bildposition.
- Neue Web-/Marktsuche beendet den alten Bildbezug für diese Nachricht.
- Web-Suchergebnisse bleiben im Chat gespeichert und werden auch nach erneutem Öffnen als Karten dargestellt.

VersionCode 26 / Version 0.8.6.
