AutoForge Mobile v0.8.9 – Remote Builder Live Progress

- Erkennt sichere Build-/Prüfaufträge und sendet sie als build_test
- Live-Fortschrittsbalken im Bereich Mein PC
- Zeigt die letzten Remote-Schritte mit Uhrzeit und Prozentwert
- Status wird etwa jede Sekunde aus der Cloud aktualisiert
- Ergebnis von dotnet restore/build wird verständlich angezeigt
- Freie Shell-/Systembefehle bleiben gesperrt
- Zugriff des PC-Agenten bleibt auf G:\gpt\AutoForge beschränkt
