AutoForge Mobile v0.6.4 – Keyboard / Viewport Fix

Neu:
- Schreibfeld bleibt beim Öffnen der Android/Samsung-Tastatur sichtbar.
- Chat besitzt einen eigenen scrollbaren Nachrichtenbereich; der Composer bleibt im sichtbaren Bereich.
- visualViewport passt die App-Höhe dynamisch an die Tastatur an.
- Fokusmodus vergrößert das Eingabefeld beim Schreiben.
- Status- und Navigationsleisten werden weiterhin berücksichtigt.
- Alle Funktionen aus v0.6.3 (Universal Router, Continuation/Resume, MediaPipe API Fix) bleiben erhalten.

Hinweis:
Bildbearbeitung benötigt weiterhin einen tatsächlich verfügbaren Bildbearbeitungs-Adapter.
Die Router-Fehlermeldung ist davon unabhängig vom Tastatur-Fix.
