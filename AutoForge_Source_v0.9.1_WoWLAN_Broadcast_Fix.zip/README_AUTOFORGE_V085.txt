AutoForge Mobile v0.8.5
- Bild-Chat-Kontext robuster: kurze Folgeantworten bleiben beim aktiven Bildauftrag.
- 'Wo ist das Bild?' ist Statusabfrage und startet keine neue Bildanalyse.
- Cloud-Router repariert ungültige Chat-Zuordnungen automatisch.
- Medienaufträge versuchen bei Cloud-Verbindung einen direkten zentralen Pollinations-Fallback.
- Text-KI darf Nutzer nicht mehr zu Pollinations/OpenRouter/API-Key-Einstellungen schicken.
- Versionscode 25 / Version 0.8.5.
