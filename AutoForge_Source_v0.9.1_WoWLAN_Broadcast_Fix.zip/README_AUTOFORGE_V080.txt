AutoForge Mobile v0.8.0 - Cloud Foundation
==========================================

Neu in v0.8.0:
- Automatische anonyme Supabase-Anmeldung beim ersten App-Start.
- Kein Benutzername, Passwort oder API-Key fuer normale Nutzer erforderlich.
- Verbindung mit dem AutoForge Cloud Gateway (Supabase Edge Function).
- Chats und Nachrichten werden zusaetzlich in AutoForge Cloud synchronisiert.
- Vorhandene lokale Chats werden beim ersten Cloud-Start schrittweise uebernommen.
- Cloud-Chats werden im Chat-Menue auf weiteren Sitzungen wieder angezeigt.
- Umbenennen und Loeschen eines Chats wird mit der Cloud synchronisiert.
- Router-Auftraege werden im Backend als Jobs angelegt; Live-/Failover-Daten koennen serverseitig gespeichert werden.
- Lokale Handy-KI und der persoenliche AutoForge-PC bleiben als Fallbacks erhalten.
- Der Einfach-Modus zeigt keine Provider/API-Key-Einrichtung fuer normale Nutzer mehr.
- VersionCode 20 / VersionName 0.8.0.

Cloud-Projekt:
https://teqirtttlcqzdnfrivxt.supabase.co

Sicherheit:
- In der APK ist nur der oeffentliche Supabase Publishable Key enthalten. Das ist beabsichtigt.
- Provider-Secret-Keys gehoeren spaeter ausschliesslich in das Backend/Secret-Management, niemals in die APK oder das GitHub-Repository.
- Die Edge Function prueft ein gueltiges Supabase-JWT.
- Row Level Security beschraenkt Chats, Nachrichten und Jobs auf den jeweiligen Benutzer.

Wichtig zum aktuellen Stand:
- v0.8.0 ist das Cloud-Grundgeruest. Chats/Auth/Jobs sind angebunden.
- Serverseitige Text-/Bild-/Video-Generierung braucht noch mindestens einen vom Betreiber hinterlegten Cloud-Provider oder eigene Worker/GPU-Modelle.
- Bis dahin funktionieren lokale Handy-KI bzw. ein verbundener AutoForge-PC weiterhin als Rechenwege.
- Anonyme Konten sind geraetebezogen. Fuer echte Synchronisation zwischen mehreren Handys wird spaeter optional ein dauerhaftes Konto (E-Mail/Google) verknuepft.
