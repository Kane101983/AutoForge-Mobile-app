AutoForge Mobile v0.8.3 - Cloud Execution Fix

- Zentrale AutoForge-Cloud kann Pollinations serverseitig ausführen.
- Pollinations-Secret bleibt ausschließlich in Supabase; keine Benutzer-Keys nötig.
- Bildbearbeitung, Bildgenerierung und Vision werden zuerst über Cloud ausgeführt.
- Bei Cloud-Fehler folgt Failover zu PC/lokalen Wegen.
- Lokale 521-MB-KI ist klar als Text/Code-Fallback gekennzeichnet; sie bearbeitet keine Bilder.
- VersionCode 23 / VersionName 0.8.3.
