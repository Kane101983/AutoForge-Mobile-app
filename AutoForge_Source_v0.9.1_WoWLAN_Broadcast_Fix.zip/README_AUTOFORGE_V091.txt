AutoForge Mobile v0.9.1 – WoWLAN Broadcast Reliability Fix

Änderungen:
- Lokaler Wake sendet jetzt über das tatsächlich aktive WLAN-Netzwerk.
- Broadcast-Adresse wird aus der Android-LinkProperties/Praefixlaenge berechnet (z. B. 192.168.1.255 bei /24).
- 255.255.255.255 bleibt als Fallback.
- Magic Packet wird 8-mal an UDP 9 und 7 gesendet.
- Wi-Fi MulticastLock waehrend des kurzen Wake-Bursts.
- Handy zeigt Anzahl und verwendete Broadcast-Ziele an.
- Fuer den lokalen Test muessen Handy und Heim-PC im selben normalen WLAN sein.
