AutoForge Mobile v0.8.2 - Intent Router & Cloud UX Fix

- Text intent now overrides unrelated/stale image attachments.
- "Suche/Find/Angebote/mobile.de/AutoScout" routes to web_search instead of image_understand unless the user explicitly references the image.
- Abort/Stop commands cancel the current task and discard pending attachments.
- Car/market searches get clickable Google, mobile.de, AutoScout24 and Kleinanzeigen search links.
- User-facing image errors no longer tell normal Cloud users to configure Pollinations.
- Provider setup is clarified as operator/admin-side in Cloud mode.
- VersionCode 22 / VersionName 0.8.2.
