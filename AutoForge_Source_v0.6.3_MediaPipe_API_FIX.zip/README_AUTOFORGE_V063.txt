AutoForge Mobile v0.6.3 – Continuation / Resume Engine

Build-Fix 0.6.3:
- MediaPipe Tasks GenAI 0.10.27 API korrigiert.
- topK/topP/temperature liegen jetzt korrekt in LlmInferenceSessionOptions.
- Engine-Optionen enthalten nur Modellpfad und MaxTokens.
- Lokale Antwortgenerierung läuft über LlmInferenceSession.
- Java 21 bleibt für den GitHub-Build vorgesehen.

Alle Funktionen aus v0.6.1/v0.6.2 bleiben erhalten:
- Universal AI Router
- Continuation / Resume Engine
- Checkpoints und Provider-Failover
- Datei-/Bildanhänge
- KI-Scout
- nur-kostenlose-Anbieter-Modus
