plugins {
    id("com.android.application")
}

android {
    namespace = "ai.autoforge.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "ai.autoforge.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 17
        versionName = "0.7.1"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
}


dependencies {
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
