plugins {
    id("com.android.application")
}

android {
    namespace = "ai.autoforge.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "ai.autoforge.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 21
        versionName = "0.8.1"
    }

    signingConfigs {
        create("release") {
            val ksPath = System.getenv("AUTOFORGE_KEYSTORE_PATH")
            if (!ksPath.isNullOrBlank()) {
                storeFile = file(ksPath)
                storePassword = System.getenv("AUTOFORGE_STORE_PASSWORD")
                keyAlias = System.getenv("AUTOFORGE_KEY_ALIAS")
                keyPassword = System.getenv("AUTOFORGE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
}


dependencies {
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
