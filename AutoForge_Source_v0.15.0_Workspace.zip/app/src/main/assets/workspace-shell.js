/* Reuses the existing scoped chat, family and owner-PC controls. */
(()=>{
 const main=document.querySelector('main'),drawer=$('settings'),menu=drawer.querySelector('.menuList');
 const make=(tag,text,cls)=>{const node=element(tag,text,cls);return node;};
 function section(id,title,description){const node=make('section','');node.id=id;node.hidden=true;node.append(make('h1',title),make('p',description,'pageIntro'));main.append(node);return node;}
 const family=section('people','Familie','Gemeinsam chatten. Deine privaten Gespräche bleiben getrennt.');
 const devices=section('devices','Meine Geräte','Dein PC, seine Freigabe und die Fernbedienung an einem Ort.');
 const tools=section('tools','Werkzeuge','Wähle eine Aufgabe. Dein Chat bleibt erhalten.');
 const preferences=section('preferences','Einstellungen','App-Version, KI-Zugang und zusätzliche Informationen.');
 const scope=drawer.querySelector('.menuScopes');scope.className='chatScopes';$('privateChatButton').textContent='Privat';$('familyChatButton').textContent='Familie';const manage=$('familyManageButton');scope.removeChild(manage);family.append(manage);$('chat').prepend(scope);
 const familySettings=$('familySettings');familySettings.open=true;familySettings.classList.add('workspaceSection');family.append(familySettings);
 const pcSettings=$('pcSettings');pcSettings.open=true;pcSettings.classList.add('workspaceSection');devices.append(pcSettings);
 const card=make('article','','deviceCard');card.append(make('small','DEIN GEKOPPELTER PC'),make('h2','Noch kein PC ausgewählt'));
 const pcStatus=make('p','PC-Liste aktualisieren, um den Zustand zu prüfen.');pcStatus.id='deviceSummary';card.append(pcStatus);
 const permission=make('p','Freigabe noch nicht geprüft.','permissionState');permission.id='devicePermission';card.append(permission,$('desktopOpen'));
 const update=make('button','Status aktualisieren');update.type='button';update.onclick=()=>action(loadDevices);card.append(update);devices.insertBefore(card,pcSettings);
 $('pcPower').open=true;$('pcPower').classList.add('visibleControlGroup');
 const oldButtons=[...menu.querySelectorAll('button[data-page]')];for(const button of oldButtons){button.onclick=()=>open(button.dataset.page);const box=make('article','','toolCard');box.append(button);tools.append(box);}
 const advanced=$('advancedSettings');advanced.open=true;advanced.classList.add('workspaceSection');preferences.append($('appVersion'),advanced);
 for(const detail of [...drawer.children].filter(n=>n.tagName==='DETAILS'&&!n.id)){detail.open=true;preferences.append(detail);}
 const scopeLabel=$('scopeLabel');familySettings.prepend(scopeLabel);
 const chatActions=drawer.querySelector('.chatActions');drawer.insertBefore(chatActions,menu);
 const conversations=$('conversations');conversations.open=true;new MutationObserver(()=>{if(!conversations.open)conversations.open=true;}).observe(conversations,{attributes:true,attributeFilter:['open']});drawer.insertBefore(conversations,menu);$('conversationsButton').hidden=true;
 const list=make('div','','conversationList');list.id='conversationList';conversations.prepend(list);$('chatSelect').classList.add('screenReaderSelect');
 const heading=drawer.querySelector('.menuHeading h2');heading.textContent='AutoForge';
 menu.replaceChildren();
 for(const [id,label,description] of [['people','Familie','Mitglieder und Einladungen'],['devices','Geräte','Bildschirm und PC-Steuerung'],['tools','Werkzeuge','Programme, Recherche und Üben'],['preferences','Einstellungen','Version und KI-Zugang']]){
  const button=make('button',label);button.type='button';button.dataset.workspace=id;button.append(make('span',description));button.onclick=()=>open(id);menu.append(button);
 }
 const dock=make('nav','','workspaceDock');dock.setAttribute('aria-label','Hauptbereiche');
 for(const [id,label] of [['chat','Chats'],['people','Familie'],['devices','Geräte']]){const button=make('button',label);button.type='button';button.dataset.workspace=id;button.onclick=()=>open(id);dock.append(button);}document.body.append(dock);
 const names={chat:'AutoForge',people:'Familie',devices:'Geräte',tools:'Werkzeuge',preferences:'Einstellungen',projects:'Programme',learning:'Recherche & Üben'};
 function open(id){
  if(!names[id])return;
  openPage(id);$('areaTitle').textContent=id==='chat'?(cloud.groupId?'Gemeinsamer Chat':'Privater Chat'):names[id];document.querySelectorAll('[data-workspace]').forEach(b=>b.classList.toggle('active',b.dataset.workspace===id));
  if(id==='devices')action(loadDevices);if(id==='people')familyAction(loadFamily);
 }
 function renderChats(){
  list.replaceChildren();
  for(const row of chatRows){const button=make('button','','conversationRow');button.type='button';button.title=row.fullTitle||row.title;button.classList.toggle('selected',row.id===chat);
   button.append(make('span',row.fullTitle||row.title||'Gespräch'),make('small',new Date(row.updated||row.created).toLocaleString('de-DE')));
   button.onclick=()=>{open('chat');$('chatSelect').value=row.id;$('chatSelect').dispatchEvent(new Event('change'));};list.append(button);}
  if(!chatRows.length)list.append(make('p','Hier erscheinen deine Gespräche.'));
 }
 new MutationObserver(renderChats).observe($('chatSelect'),{childList:true});$('chatSelect').addEventListener('change',renderChats);
 const originalNew=$('newChat').onclick;$('newChat').onclick=()=>{open('chat');originalNew();};
 const originalBadge=$('aiBadge').onclick;$('aiBadge').onclick=()=>{originalBadge();open('devices');$('providerSettings').open=true;$('providerSettings').scrollIntoView({block:'start'});};
 $('familyManageButton').onclick=()=>open('people');const shared=make('button','Gemeinsamen Chat öffnen');shared.onclick=async()=>{await chooseChatArea(true);if(cloud.groupId)open('chat');};family.insertBefore(shared,manage);
 const originalProvider=$('providerButton').onclick;$('providerButton').onclick=()=>{originalProvider();open('devices');};
 // Legacy setup handlers may still open their original drawer; route the actual group.
 for(const group of [familySettings,pcSettings,advanced])new MutationObserver(()=>{if(group.open&&drawer.open){drawer.open=false;open(group===pcSettings?'devices':group===familySettings?'people':'preferences');}}).observe(group,{attributes:true,attributeFilter:['open']});
 const oldSetup=$('setupCloud').onclick;$('setupCloud').onclick=()=>{oldSetup();open('preferences');$('cloudSetup').open=true;};
 window.AutoForgeShell={open,devices(rows,selected){const pc=rows.find(r=>r.id===selected);card.querySelector('h2').textContent=pc?.device_name||'Noch kein PC verbunden';const online=pc&&Number.isFinite(Date.parse(pc.last_seen_at))&&Date.now()-Date.parse(pc.last_seen_at)<70000;
  card.classList.toggle('online',!!online);pcStatus.textContent=pc?(online?'● Online':'○ Offline')+' · Agent '+(pc.agent_version||'unbekannt'):'Füge deinen PC unten hinzu.';
  permission.textContent=pc?.status?.desktop_persistent===true?'Dauerfreigabe aktiv · erneutes Verbinden ohne Klick am PC möglich':pc?.status?.desktop_enabled===true?'Zeitweise Freigabe aktiv · für unterwegs am PC Dauerfreigabe wählen':pc?.status?.desktop_enabled===false?'Bildschirmzugriff aus · am PC einmal Dauerfreigabe einschalten':'Freigabestatus noch nicht gemeldet · Status aktualisieren';
  $('desktopOpen').disabled=!pc;},renderChats};
 const originalFamilyTabs=familyTabs;familyTabs=()=>{originalFamilyTabs();$('privateChatButton').textContent='Privat';$('familyChatButton').textContent='Familie';};familyTabs();new MutationObserver(()=>{if(innerWidth>=1000&&!drawer.open)drawer.open=true;}).observe(drawer,{attributes:true,attributeFilter:['open']});window.addEventListener('resize',()=>{drawer.open=innerWidth>=1000;});renderChats();open('chat');if(innerWidth>=1000)drawer.open=true;
})();
