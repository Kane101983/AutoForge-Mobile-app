# Mobile 0.13.5 / PC 0.6.3

Mein PC enthält jetzt KI auswählen. Der Kopf zeigt die zuletzt verwendete oder gerade angefragte KI; Antippen öffnet den KI-Katalog. Öffentlich gefundene kostenlose OpenRouter-Modelle benötigen einen eigenen Schlüssel. Der bestehende AutoForge-Cloudzugang ist getrennt aufgeführt; Restkontingente sind unbekannt. Eine Katalogsuche installiert oder trainiert keine Modelle.

Das Schreibfeld nutzt die volle Breite, wächst mit Text und lässt sich vergrößern. Anhänge stehen in einer Werkzeugleiste darunter. Neue Fotos erhalten Vorschaubilder im Chatverlauf. Höchstens 96 Nachrichten mit verkleinerten Vorschaubildern werden auf diesem Gerät gespeichert; keine automatische Übertragung der Originale an Familienmitglieder. Der vollständige Foto-Kontext bleibt wie bisher höchstens 24 Stunden für Folgeaufträge. Chat löschen entfernt auch die Vorschau.

PC 0.6.3 enthält einen nativen Chat über die vorhandene lokale Ollama-KI, bestehende Chats und ein Formular für kontrollierte Wikipedia-Recherche mit Internetfreigabe, Grenzen, Endzeit, Stoppen und Protokoll/Speicheranzeige. Vorausgesetzt sind die vorhandene AutoForge-Brain-Installation auf G, Node und Ollama mit Modell. Modelle werden nicht mitgeliefert. Sprachdialog ist noch nicht eingebaut; Schreiben funktioniert im neuen Chatfenster. Quellen landen im Gedächtnis; Modellgewichte werden nicht trainiert.

Die grüne Handy-Ampel verwendet eine Besitzer-Heartbeatmeldung der geöffneten neuen App (alle 30 Sekunden), mit 75 Sekunden Ablaufzeit. Kopplung, Aktivität und Cloud-Fehler sind getrennte Zustände. Familienmitglieder können diese Besitzer-Aktivität nicht melden. Die App muss für die Ampel geöffnet und mit dem gekoppelten PC ausgewählt sein.
