/* Catalog entries, connected routes and completed models are distinct counts. */
(()=>{
 let catalog=[],routes=[],scanned=0,lastCloud=localStorage.getItem('af_last_model')||'',used;
 try{used=new Set(JSON.parse(localStorage.getItem('af_used_models')||'[]'));}catch{used=new Set();}
 const update=()=>{const free=catalog.filter(x=>x.source==='openrouter'&&x.model_id?.endsWith(':free'));$('activeModel').textContent=engine==='local'?'PC · '+(localModel||'Ollama'):lastCloud||'Cloud · bereit';$('aiBadge').title=engine==='local'?localModel||'Lokale KI auf deinem PC':lastCloud||'Modell erscheint nach einer Antwort';$('freeCount').textContent=scanned?free.length+' kostenlose Modelle':'KI-Katalog';$('catalogStatus').textContent=(scanned?'Katalog vom '+new Date(scanned).toLocaleString('de-DE')+': '+catalog.length+' Angebote, davon '+free.length+' kostenlose OpenRouter-Modelle.':'Noch keine erfolgreiche Katalogsuche.')+' '+routes.length+' Cloud-Zugänge gemeldet. Auf diesem Handy bisher '+used.size+' verschiedene Cloud-Modelle verwendet. Restkontingent: unbekannt.';$('catalogList').replaceChildren();for(const r of routes){$('catalogList').append(element('p',(r.enabled?'● ':'○ ')+(r.name||r.id)+' · '+(r.model||'Modell beim Aufruf')+' · '+(r.requires_user_key?'eigener Schlüssel nötig':'Cloud-Zugang')+' · '+(r.health||'Verfügbarkeit unbekannt')));}for(const x of free.slice(0,40))$('catalogList').append(element('p',x.name+' · OpenRouter-Schlüssel erforderlich'));};
 window.AutoForgeAIStatus={record(messages,scope){if(scope!=='cloud'){update();return;}for(const m of messages)if(m.role==='assistant'&&m.metadata?.model){lastCloud=m.metadata.model;used.add(lastCloud);}localStorage.setItem('af_last_model',lastCloud);localStorage.setItem('af_used_models',JSON.stringify([...used].slice(-100)));update();}};
 $('aiBadge').onclick=()=>{$('settings').open=true;$('pcSettings').open=true;$('providerSettings').open=true;$('aiCatalog').open=true;$('aiCatalog').scrollIntoView({block:'nearest'});};
 $('scanModels').onclick=async()=>{const b=$('scanModels');b.disabled=true;$('catalogStatus').textContent='Öffentliche KI-Kataloge werden geprüft …';try{const d=await bridge('scanFreeAI');catalog=d.items||[];scanned=d.scanned_at||0;update();if(d.errors?.length)$('catalogStatus').append(document.createTextNode(' Einige Quellen nicht erreichbar: '+d.errors.join('; ')));}catch(e){$('catalogStatus').textContent=e.message;}finally{b.disabled=false;}};
 bridge('getScoutCache').then(d=>{catalog=d.items||[];scanned=d.scanned_at||0;update();}).catch(()=>update());
 cloud.gateway('providers').then(d=>{routes=d.providers||[];update();}).catch(()=>update());
 $('engineSelect').addEventListener('change',update);
 window.addEventListener('af-task-progress',e=>{const model=e.detail?.active?.model;if(model){$('activeModel').textContent=model;$('aiBadge').title=model;}});
 window.addEventListener('af-ai-model',e=>{if(e.detail?.model){$('activeModel').textContent=e.detail.model;$('aiBadge').title=e.detail.model;}});
 $('expandInput').onclick=()=>{const expanded=$('chatForm').classList.toggle('expanded');$('expandInput').textContent=expanded?'↕ Kleiner':'↕ Größer';$('expandInput').setAttribute('aria-pressed',expanded);$('prompt').focus();};
 $('prompt').addEventListener('input',()=>{if(!$('chatForm').classList.contains('expanded')){$('prompt').style.height='auto';$('prompt').style.height=Math.min($('prompt').scrollHeight,innerHeight*.28)+'px';}});
 let presenceBusy=false;
 async function presence(){if(document.hidden||!device||presenceBusy)return;presenceBusy=true;try{await remote('mobile_presence',{device_id:device});}catch{}finally{presenceBusy=false;}}
 setInterval(presence,30000);document.addEventListener('visibilitychange',presence);setTimeout(presence,5000);
 update();
})();
