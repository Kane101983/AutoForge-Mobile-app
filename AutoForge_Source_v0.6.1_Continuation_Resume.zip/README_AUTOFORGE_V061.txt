AutoForge Mobile v0.6.1 – Continuation / Resume Engine

Neu in 0.6.1:
- Fortsetzungs-Engine mit persistentem Job-Zustand
- Checkpoints für Text/Projektstände und erzeugte Medien
- automatischer Failover bei Quota/Rate-Limit, Provider-Fehlern und Verbindungsproblemen
- nächster Provider erhält Originalauftrag + Verlauf + letzten nutzbaren Zwischenstand
- mehrere kostenlose OpenRouter-Modelle können nacheinander probiert werden, wenn ein Key optional eingerichtet ist
- Hybrid-Modus fällt bei PC-Fehlern auf den Handy-Router zurück
- Projekt-JSON, das sich nicht speichern lässt, bleibt als Checkpoint erhalten und kann vom nächsten Provider repariert werden
- Resume-Zustand wird zusätzlich im App-Dokumentbereich unter AutoForge/Resume gespeichert

Wichtige technische Grenze:
Wenn ein externer KI-Dienst bei einem Abbruch keinerlei Zwischenergebnis zurückgibt, kann AutoForge dessen internen Rechenzustand nicht auslesen. In diesem Fall werden Originaldateien, Auftrag, Verlauf und der letzte bereits vorhandene Checkpoint an den nächsten Provider weitergegeben.
