const $=id=>document.getElementById(id);let cb=0;const callbacks={};let device='',chat='',busy=false,pending=null,followOutput=true,shownChat='',chatRows=[],practiceRunning=false,engine='cloud',localChat='',cloudChat='';let localModel='',activity='',initializing=true,pcOnline=false;const cloud=new AutoForgeCloudChat((...args)=>bridge(...args),localStorage);
try{const saved=JSON.parse(localStorage.getItem('af_studio_selection')||'{}');device=saved.device||'';localChat=saved.localChat||saved.chat||'';cloudChat=saved.cloudChat||'';engine=saved.engine==='local'?'local':'cloud';chat=engine==='cloud'?cloudChat:localChat;pending=JSON.parse(localStorage.getItem('af_studio_pending')||'null');}catch{}
window.AFBridgeResult=(id,json)=>{const p=callbacks[id];if(!p)return;delete callbacks[id];clearTimeout(p.timer);try{p.resolve(JSON.parse(json));}catch(e){p.reject(e);}};
function bridge(method,...args){return new Promise((resolve,reject)=>{if(!window.AndroidBridge||typeof AndroidBridge[method]!=='function')return reject(Error('Android-Verbindung fehlt.'));const id='studio'+(++cb),timer=setTimeout(()=>{delete callbacks[id];reject(Error('Verbindung hat zu lange gedauert.'));},['freeOpenRouterChat','cloudMediaRequest'].includes(method)?180000:90000);callbacks[id]={resolve,reject,timer};AndroidBridge[method](...args,id);});}
async function remote(action,extra={}){const data=await bridge('cloudRemoteRequest',JSON.stringify({action,...extra}));if(data._cloud_ok===false||data.error)throw Error(data.error||'Cloud nicht erreichbar.');return data;}
function element(tag,text,cls){const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;}
function save(){if(engine==='local')localChat=chat;else if(!cloud.groupId)cloudChat=chat;localStorage.setItem('af_studio_selection',JSON.stringify({device,chat:localChat,localChat:engine==='local'?chat:localChat,cloudChat,engine}));}
function notice(text){$('notice').textContent=text;$('sendStatus').textContent=text;}
$('conversationsButton').onclick=()=>{$('conversations').open=!$('conversations').open;if($('conversations').open&&engine==='cloud'&&!busy)return action(async()=>{await chats();await history();});};
$('providerButton').onclick=()=>{$('settings').open=true;$('providerSettings').open=true;$('engineSelect').focus();};
bridge('getAppInfo').then(info=>{$('appVersion').textContent=info.versionName?'Installiert: v'+info.versionName+' · Build '+info.versionCode:'Installierte Version nicht lesbar';}).catch(()=>{$('appVersion').textContent='Version erst in der Android-App verfügbar';});
function cloudReady(){try{cloud.config();return true;}catch{return false;}}
function providerStatus(){const name=engine==='cloud'?((localStorage.getItem('af_cloud_provider')||(localStorage.getItem('af_or_key')?'openrouter':'gateway'))==='gateway'?'AutoForge Cloud · Pollinations':'OpenRouter · '+(localStorage.getItem('af_or_model')||'Modell noch auswählen')):($('deviceSelect').selectedOptions?.[0]?.textContent||'Mein PC')+' · '+(localModel||'Lokale KI');$('cloudHelp').hidden=engine!=='cloud'||cloudReady();$('providerStatus').textContent=activity==='Bild wird erstellt'?'Bildauftrag: Pollinations · kostenloses Community-Modell':engine==='cloud'&&!cloudReady()?'OpenRouter · Einrichtung fehlt':(activity?activity+' · ':'Antworten: ')+name;}
function controls(){
 if(typeof familyTabs==='function')familyTabs();
 providerStatus();const localBlocked=engine==='local'&&!!pending,cloudBlocked=engine==='cloud'&&!!cloud.pending();
 for(const id of ['newChat','chatSelect','deviceSelect','build','learnStart','remember','practiceStart','practiceRefresh','practiceStop','retryCloud'])$(id).disabled=busy||localBlocked;
 $('practiceStart').disabled=busy||!!pending||practiceRunning;
 $('engineSelect').disabled=busy||initializing;
 $('retryCloud').hidden=!cloud.pending();
 $('newChat').disabled=busy||localBlocked||cloudBlocked;
 // Keep the action reachable: taps explain waiting or recover the existing request.
 $('send').disabled=false;
 $('send').textContent=initializing?'Verbinde …':busy?'Bitte warten …':localBlocked?'Auftrag prüfen':cloudBlocked?'Antwort abholen':'Senden ↑';
 $('engineSelect').value=engine;$('scopeLabel').hidden=engine!=='cloud'||$('chatScope').children.length<2;
}

async function poll(){const attempts=['list','history','projects','storage','learn-status','practice-status'].includes(pending?.operation)?10:20;for(let i=0;i<attempts;i++){const {job}=await remote('job_status',{job_id:pending.id});if(job?.status==='completed'){pending=null;localStorage.removeItem('af_studio_pending');const result=job.result||{};if(result.run)renderPractice(result);return result;}if(['failed','cancelled','waiting_approval'].includes(job?.status)){pending=null;localStorage.removeItem('af_studio_pending');throw Error(job.error||'Auftrag nicht abgeschlossen.');}notice(job?.status==='queued'?'Auftrag wartet auf den PC-Agenten. Die lokale KI hat noch nicht geantwortet.':'PC-Agent bearbeitet den Auftrag; die lokale KI wird gegebenenfalls gestartet …');await new Promise(r=>setTimeout(r,1500));}throw Error('Dauert länger. Aktualisieren holt denselben Auftrag ab.');}
async function job(operation,extra={}){if(pending)throw Error('Bitte zuerst Aktualisieren: ein Auftrag ist noch offen.');if(!device)throw Error('Bitte zuerst deinen PC verbinden.');const {job}=await remote('create_job',{device_id:device,job_type:'project_task',instruction:'AutoForge Studio · '+operation,payload:{kind:'local_brain',operation,...extra}});if(!job?.id)throw Error('Auftrag nicht angelegt.');pending={id:job.id,operation,device};localStorage.setItem('af_studio_pending',JSON.stringify(pending));return poll();}
async function action(fn){if(busy){notice('AutoForge bearbeitet noch den laufenden Auftrag. Deine Eingabe bleibt erhalten.');return;}busy=true;controls();try{await fn();}catch(e){notice(e.message);}finally{busy=false;controls();}}
async function loadDevices(){const {devices=[]}=await remote('list_devices');$('deviceSelect').replaceChildren(new Option('PC auswählen',''));for(const d of devices)$('deviceSelect').add(new Option(d.device_name,d.id));if(!devices.some(d=>d.id===device)){device=devices.length===1?devices[0].id:'';localChat='';if(engine==='local')chat='';} $('deviceSelect').value=device;save();const pc=devices.find(d=>d.id===device);pcOnline=!!pc&&Date.now()-Date.parse(pc.last_seen_at)<70000;$('connection').textContent=pc?(Date.now()-Date.parse(pc.last_seen_at)<70000?'PC-Agent erreichbar · KI noch nicht geprüft':'PC-Agent zuletzt offline'):'PC verbinden';}
function messageBody(text){text=String(text||'').replace(/```autoforge-(pptx|xlsx)\n[\s\S]*?```/g,'');const box=element('div','');const expression=/!?\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)|https?:\/\/[^\s<>]+/g;let last=0;for(const match of text.matchAll(expression)){box.append(document.createTextNode(text.slice(last,match.index)));const raw=match[2]||match[0],url=raw.replace(/[.,;!?\])]+$/,'');if(match[0].startsWith('![')&&AutoForgeChatTools.mediaUrl(url)){const image=document.createElement('img');image.src=url;image.alt=match[1]||'Bild';image.className='chatImage';image.loading='lazy';box.append(image);const download=element('button','↓ Bild speichern');download.type='button';download.onclick=()=>{if(window.AndroidBridge?.download){AndroidBridge.download(url,'','AutoForge-Bild-'+Date.now()+'.png');notice('Bild wird im Download-Ordner gespeichert.');}else window.open(url,'_blank','noopener');};box.append(download);last=match.index+match[0].length;continue;}const link=element('a',match[1]||url);link.href=url;link.rel='noopener noreferrer';box.append(link);last=match.index+match[0].length;}box.append(document.createTextNode(text.slice(last)));return box;}
function renderChatHeading(){const selected=chatRows.find(c=>c.id===chat);$('chatHeading').hidden=!selected;$('chatFullTitle').textContent=selected?.fullTitle||selected?.title||'';}
async function history(){renderChatHeading();const same=shownChat===chat;const previousTop=$('messages').scrollTop;if(!same)followOutput=true;shownChat=chat;if(!chat){$('messages').replaceChildren(element('p','Wobei kann ich dir helfen?','welcome'));return;}const result=engine==='cloud'?{messages:await cloud.history(chat)}:await job('history',{chatId:chat});$('messages').replaceChildren();for(const m of result.messages||[]){const box=element('article','','message '+m.role);box.append(element('small',m.role==='user'?(m.author||'DU'):'AUTOFORGE'+(m.metadata?.model?' · '+m.metadata.model:'')),messageBody(m.content));if(m.role==='assistant'&&window.AutoForgeChatTools){for(const file of window.AutoForgeOffice?.blocks(m.content)||[]){const preview=element('details','');preview.append(element('summary',file.spec.title));if(file.kind==='pptx'){file.spec.slides.forEach((slide,i)=>{preview.append(element('h3',(i+1)+'. '+slide.title),element('p',slide.bullets.join('\n')));});}else{const table=document.createElement('table');file.spec.rows.slice(0,12).forEach(row=>{const tr=document.createElement('tr');row.forEach(v=>tr.append(element('td',String(v??''))));table.append(tr);});preview.append(table);if(file.spec.rows.length>12)preview.append(element('p','Vorschau: 12 von '+file.spec.rows.length+' Zeilen. Die Datei enthält alle Zeilen.'));}box.append(preview);const button=element('button','↓ '+(file.kind==='pptx'?'Präsentation.pptx':'Tabelle.xlsx')+' speichern');button.onclick=()=>downloadOfficeFile(file);box.append(button);}for(const file of AutoForgeChatTools.fileBlocks(m.content)){const button=element('button','↓ '+file.name+' speichern');button.onclick=()=>downloadChatFile(file);box.append(button);}}$('messages').append(box);} $('messages').scrollTop=followOutput?$('messages').scrollHeight:previousTop;}
function renderChats(){const order=$('chatOrder').value;const rows=[...chatRows].sort((a,b)=>order==='oldest'?a.created.localeCompare(b.created):order==='newest'?b.created.localeCompare(a.created):(b.updated||b.created).localeCompare(a.updated||a.created));$('chatSelect').replaceChildren(new Option('Neues Gespräch',''));for(const c of rows)$('chatSelect').add(new Option(c.title+' · Erstellt '+new Date(c.created).toLocaleDateString('de-DE')+' · Zuletzt '+new Date(c.updated||c.created).toLocaleString('de-DE'),c.id));$('chatSelect').value=chat;renderChatHeading();}
async function chats(){const d=engine==='cloud'?{chats:await cloud.list()}:await job('list');if(engine==='local'&&d.model)localModel=d.model;providerStatus();chatRows=d.chats||[];renderChats();}
async function projects(){const d=await job('projects');$('projectList').replaceChildren();for(const p of d.projects||[]){const card=element('article','','card');card.append(element('h3',p.title),element('p',p.notes),element('small',p.quality),element('p','Vorschau im Windows-Programm unter Projekte.'));if(p.secondOpinion)card.append(element('p','KI-Zweitmeinung ('+p.secondOpinion.model+'): '+p.secondOpinion.text));const edit=element('button','Dieses Projekt überarbeiten');edit.onclick=()=>{$('baseId').value=p.id;$('projectPrompt').focus();notice('Neue Version von '+p.title);};card.append(edit);$('projectList').append(card);}if(!d.projects?.length)$('projectList').append(element('p','Hier erscheinen deine erstellten Programme.'));}
function renderLearning(data){const j=data.job;if(!j){$('learningStatus').textContent='Noch kein Lernlauf.';return;} $('learningStatus').textContent='Recherchequelle: Wikipedia · '+j.message+' · '+j.processed+'/'+j.plan.length+' Quellen · '+j.percent+' %';$('learnProgress').value=j.percent;$('learnLog').textContent=j.events.map(e=>new Date(e.time).toLocaleTimeString()+'  '+e.message).join('\n');$('flow').textContent='Internet → '+j.completed+' Quellen → automatisch ins Gedächtnis\nDer Chat läuft lokal. Eine zweite lokale KI ist für Projekt-Einschätzungen optional.';$('sources').replaceChildren();for(const n of j.notes){const row=element('article','','card');row.append(element('h3',n.title),element('p',n.reason),element('p',n.text));const accept=element('button',n.accepted?'Automatisch gespeichert':'Speichern erneut versuchen');accept.disabled=n.accepted;accept.onclick=()=>action(async()=>{await job('learn-accept',{noteId:n.id});renderLearning(await job('learn-status'));});row.append(accept);$('sources').append(row);}}
async function learning(){renderPractice(await job('practice-status'));renderLearning(await job('learn-status'));const d=await job('storage');$('space').textContent=[['Lernquellen',d.research],['Chats & Wissen',d.memory],['Projekte',d.projects],['Modelle',d.models]].map(([k,v])=>k+': '+(v/1048576).toLocaleString('de-DE',{maximumFractionDigits:2})+' MB').join('\n');}
$('settingsButton').onclick=()=>$('settings').open=!$('settings').open;
$('refresh').onclick=()=>action(async()=>{if(pending){const old=pending;const r=await poll();if(r.chatId){localChat=r.chatId;device=old.device;if(engine==='local')chat=r.chatId;save();}}try{await loadDevices();}catch(e){if(engine==='local')throw e;}await chats();await history();notice('Aktuell.');});
$('newChat').onclick=()=>{$('conversations').open=false;chat='';save();if(typeof chatAttachments!=='undefined'){chatAttachments=[];renderAttachments();}$('chatSelect').value='';history();};
$('chatSelect').onchange=()=>action(async()=>{chat=$('chatSelect').value;$('conversations').open=false;save();await history();});
$('deviceSelect').onchange=()=>action(async()=>{device=$('deviceSelect').value;localChat='';if(engine==='local')chat='';save();await chats();await history();});
async function recoverLocal(){
 const old=pending;const r=await poll();
 if(r.chatId){localChat=r.chatId;device=old.device;if(engine==='local')chat=r.chatId;save();}
 await chats();await history();notice('Auftrag abgeholt. Deinen Entwurf kannst du jetzt senden.');
}
function sendChat(e){
 e?.preventDefault();
 if(initializing){notice('Verbindung wird noch hergestellt. Deine Nachricht bleibt im Eingabefeld.');return;}
 if(busy){notice('AutoForge arbeitet noch. Deine Nachricht bleibt im Eingabefeld; bitte kurz warten.');return;}
 if(typeof attachmentLoading!=='undefined'&&attachmentLoading){notice('Die Dateien werden noch vorbereitet. Bitte kurz warten.');return;}
 if(engine==='local'&&pending)return action(recoverLocal);
 if(engine==='cloud'&&cloud.pending())return $('retryCloud').onclick();
 const message=$('prompt').value.trim();
 if(!message){notice('Schreibe zuerst deine Frage ins Eingabefeld.');$('prompt').focus();return;}
 return action(async()=>{
  if(engine==='local'){await loadDevices();if(!device||!pcOnline){$('settings').open=true;$('providerSettings').open=true;throw Error('Dein PC ist nicht erreichbar. Schalte den PC ein oder wähle im Menü die Cloud-KI. Deine Nachricht bleibt erhalten.');}}
  else {try{cloud.config();}catch(e){throw Error(e.message+' Oder öffne hier den bisherigen Cloud-Chat.');}}
  let attachments=typeof chatAttachments==='undefined'?[]:[...chatAttachments];
  if(engine==='cloud'&&chat&&!attachments.some(a=>a.dataUrl)&&AutoForgeChatTools.referencesImage(message)&&window.AutoForgePhotos){const photo=await AutoForgePhotos.get(cloud.groupId,chat);if(photo)attachments=[...attachments,photo];}
  if(engine==='local'&&attachments.length)throw Error('Für Anhänge bitte oben die Cloud-KI wählen. Deine Dateien bleiben bereit.');
  const imageIntent=engine==='cloud'?AutoForgeChatTools.imageIntent(message,attachments):null;
  let mediaConsent=false;if(imageIntent){mediaConsent=confirm('Bildauftrag über ein kostenloses Community-Modell von Pollinations senden? Der Anbieter speichert Eingaben und Ergebnisse laut Modellhinweis. Ergebnis-Bildlinks sind beim Anbieter öffentlich abrufbar. Bitte keine vertraulichen Fotos senden.'+(cloud.groupId?' Das Ergebnis erscheint außerdem im Familienchat.':''));if(!mediaConsent){notice('Bildauftrag abgebrochen. Foto und Nachricht bleiben bereit.');return;}}
  if(imageIntent==='edit'&&!attachments.some(a=>a.dataUrl))throw Error('Bitte das Ausgangsfoto über ＋ anhängen. Ein früheres Foto aus der alten App-Version ist noch nicht auf diesem Gerät gespeichert.');
  activity=imageIntent?'Bild wird erstellt':'Antwort wird erstellt';providerStatus();notice('Nachricht wird gesendet …');
  let r;try{r=engine==='cloud'?await cloud.send(chat||null,message,attachments,mediaConsent):await job('chat',{chatId:chat||null,message});}finally{activity='';providerStatus();}
  chat=r.chatId;save();if($('prompt').value.trim()===message)$('prompt').value='';
  if(typeof chatAttachments!=='undefined'){chatAttachments=[];renderAttachments();}
  await chats();await history();notice('Antwort gespeichert.');
 });
}
$('chatForm').onsubmit=sendChat;
$('send').onclick=sendChat;

$('projectForm').onsubmit=e=>{e.preventDefault();action(async()=>{const r=await job('project-build',{message:$('projectPrompt').value,baseId:$('baseId').value||undefined,review:$('review').checked});if(r.chatId){localChat=r.chatId;if(engine==='local')chat=r.chatId;save();}await projects();notice('Projekt erstellt. Vorschau am PC öffnen.');});};
$('freshProject').onclick=()=>{$('baseId').value='';notice('Neues Projekt.');};
$('learnForm').onsubmit=e=>{e.preventDefault();action(async()=>{if(!$('learnInternet').checked)throw Error('Bitte Internet für diesen Recherchelauf erlauben.');renderLearning(await job('learn-start',{learning:{topic:$('topic').value,cpuPercent:Number($('cpu').value),ramMb:Number($('ram').value),diskMb:Number($('disk').value),packages:Number($('packages').value),deadline:new Date($('deadline').value).toISOString()}}));});};
$('learnStop').onclick=()=>action(async()=>{if(pending)await poll();renderLearning(await job('learn-stop'));});
$('learnRefresh').onclick=()=>action(learning);
$('remember').onclick=()=>action(async()=>{await job('memory',{title:$('ideaTitle').value,body:$('idea').value});$('idea').value='';notice('Gedanke auf G gespeichert.');});
$('pair').onclick=()=>action(async()=>{await remote('pair_device',{code:$('pairCode').value});await loadDevices();notice('PC gekoppelt.');});
const deadline=new Date(Date.now()+3600000);$('deadline').value=new Date(deadline.getTime()-deadline.getTimezoneOffset()*60000).toISOString().slice(0,16);
setInterval(()=>{if(!document.hidden&&!$('learning').hidden&&!busy&&!pending&&$('live').checked)action(learning);},15000);
(async()=>{try{
 controls();await bridge('cloudBootstrap');
 try{await loadDevices();}catch(e){if(engine==='local')throw e;notice('PC-Liste nicht erreichbar. Cloud-Chat bleibt verfügbar.');}
 initializing=false;
 if(engine==='local'&&pending)notice('Ein Auftrag ist noch offen. Mit „Auftrag prüfen“ abholen oder zur Cloud-KI wechseln.');
 else if(engine==='cloud'||pcOnline)await action(async()=>{await chats();await history();});
 else notice('Dein PC ist nicht erreichbar. Du kannst oben zur Cloud-KI wechseln.');
 }catch(e){notice(e.message);}finally{initializing=false;controls();}})();

$('deleteChat').onclick=()=>action(async()=>{if(!chat)return;if(!confirm('Diesen Chat löschen? Separat gespeicherte Notizen und Sicherungen bleiben erhalten.'))return;if(engine==='cloud')await cloud.remove(chat);else await job('delete-chat',{chatId:chat});if(window.AutoForgePhotos)await AutoForgePhotos.remove(cloud.groupId,chat);chat='';save();await chats();await history();});

$('chatOrder').onchange=renderChats;
$('messages').addEventListener('scroll',()=>{const box=$('messages');followOutput=box.scrollHeight-box.scrollTop-box.clientHeight<40;$('followOutput').hidden=followOutput;},{passive:true});
$('followOutput').onclick=()=>{followOutput=true;$('messages').scrollTop=$('messages').scrollHeight;};


function renderPractice({run:r}){
 if(!r){practiceRunning=false;$('practiceStatus').textContent='Noch keine Übung auf diesem PC.';$('practiceLog').textContent='';$('practiceDetails').textContent='';$('practiceProgress').value=0;return;}
 practiceRunning=r.status==='running';
 const score=Number.isInteger(r.before)&&Number.isInteger(r.after)?' · Vorher '+r.before+'/3 → Nachher '+r.after+'/3':'';
 $('practiceStatus').textContent=r.message+score+' · '+r.completed+'/'+r.total+' Modellanfragen · '+(r.bytes/1024).toFixed(1)+' KB Ergebnisdaten';
 $('practiceProgress').value=r.completed;
 $('practiceLog').textContent=r.events.map(e=>new Date(e.time).toLocaleTimeString()+' '+e.message).join('\n');
 $('practiceDetails').textContent=r.results.map(x=>x.phase+': '+(x.passed?'bestanden':'nicht bestanden')+'\n'+(x.prompt||x.task)+'\n'+x.answer).join('\n\n')+'\n\nKandidat (nicht aktiviert):\n'+r.candidate;
 controls();
}
$('practiceForm').onsubmit=e=>{e.preventDefault();return action(async()=>renderPractice(await job('practice-start',{practice:{minutes:Number($('practiceMinutes').value),threads:Number($('practiceThreads').value)}})));};
$('practiceStop').onclick=()=>action(async()=>renderPractice(await job('practice-stop')));
$('practiceRefresh').onclick=()=>action(async()=>renderPractice(await job('practice-status')));
$('improveMobile').onclick=()=>{$('settings').open=false;
 document.querySelectorAll('main>section').forEach(p=>p.hidden=p.id!=='learning');
 document.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page==='learning'));
 $('learningChoice').hidden=false;$('learningChoice').scrollIntoView({block:'start'});
 action(learning);
};
$('choosePractice').onclick=()=>{$('practiceForm').scrollIntoView({block:'center'});$('practiceMinutes').focus();};
$('chooseResearch').onclick=()=>{$('learnForm').scrollIntoView({block:'center'});$('topic').focus();};

$('engineSelect').onchange=()=>{const next=$('engineSelect').value;return action(async()=>{save();engine=next==='cloud'?'cloud':'local';if(typeof chatAttachments!=='undefined'){chatAttachments=[];renderAttachments();}cloud.setGroup('');$('chatScope').value='';chat=engine==='cloud'?cloudChat:localChat;shownChat='';chatRows=[];save();renderChats();if(engine==='local'&&pending){notice('Ein PC-Auftrag ist noch offen. Mit „Auftrag prüfen“ abholen.');return;}if(engine==='local'&&!pcOnline){notice('Dein PC ist nicht erreichbar. Cloud-KI bleibt verfügbar.');return;}await chats();await history();$('settings').open=false;notice(engine==='cloud'?(cloudReady()?'Cloud-KI ist ausgewählt. Du kannst deine Frage senden.':'OpenRouter braucht einen eigenen Schlüssel und ein :free-Modell. Wähle unten Einrichten oder den bisherigen Cloud-Chat.'):'Lokale KI ausgewählt. Der PC-Agent muss erreichbar sein; die KI kann von ihm gestartet werden.');});};
$('retryCloud').onclick=()=>action(async()=>{const r=await cloud.resume();if(!cloud.groupId)cloudChat=r.chatId;if(engine==='cloud')chat=r.chatId;save();if(typeof chatAttachments!=='undefined'){chatAttachments=[];renderAttachments();}if(engine==='cloud'){await chats();await history();}notice('Cloud-Antwort gespeichert.');});
$('saveCloud').onclick=()=>{const model=$('cloudModel').value.trim();if(!model.endsWith(':free'))return notice('Bitte ein Modell mit der Endung :free angeben.');const key=$('cloudKey').value.trim();if(!key&&!localStorage.getItem('af_or_key'))return notice('Der OpenRouter-Schlüssel fehlt noch. Bitte hier eintragen oder den bisherigen Cloud-Chat verwenden.');if(key)localStorage.setItem('af_or_key',key);localStorage.setItem('af_or_model',model);providerStatus();$('cloudKey').value='';$('settings').open=false;notice('OpenRouter eingerichtet. Deine Frage steht weiterhin im Chat – jetzt Senden antippen.');};
$('cloudModel').value=localStorage.getItem('af_or_model')||'';

$('setupCloud').onclick=()=>{$('settings').open=true;$('cloudSetup').open=true;$('cloudSetup').scrollIntoView({block:'nearest'});$('cloudKey').focus();};
$('legacyCloud').onclick=()=>{localStorage.setItem('af_studio_transfer_draft',$('prompt').value);};

$('cloudRoute').value=localStorage.getItem('af_cloud_provider')||(localStorage.getItem('af_or_key')?'openrouter':'gateway');
$('cloudRoute').onchange=()=>{localStorage.setItem('af_cloud_provider',$('cloudRoute').value);providerStatus();notice($('cloudRoute').value==='gateway'?'AutoForge Cloud ausgewählt. Du kannst zum Chat zurückgehen und senden.':'OpenRouter benötigt deinen eigenen Schlüssel und ein :free-Modell.');};
