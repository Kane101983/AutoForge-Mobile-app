AutoForge Mobile v0.9.2 – Lokales Aufwecken nach Standby

Ausgangsstand: v0.9.1, GitHub Commit dab7be98aba20da5123d426b928aaba2a5ce72be.

Behobene Fehler:
- Der Button "Lokal aufwecken" sendet auch dann, wenn die letzte PC-Meldung noch
  als online angezeigt wird. Diese Meldung kann nach dem Standby bis zu 70 Sekunden
  alt sein. Vorher wurde in dieser Zeit kein Aufweckpaket gesendet.
- Ein alter Online-Status wird nicht als Ergebnis des neuen Versuchs angezeigt.
  Die App wartet auf einen neueren Heartbeat mit Zeitstempel ab Versuchsbeginn.
  Dafür sollten Handy und Cloud eine korrekt eingestellte Uhr verwenden.
- Scheitert die Bindung an das WLAN, wird ein Fehler angezeigt und nicht über
  ein möglicherweise anderes Standardnetz weitergesendet.
- Die Version 0.9.2 steht sichtbar im Bereich PC-Steuerung.

Grenzen:
- Eine neue Online-Meldung beweist nicht, dass das Magic Packet den PC geweckt hat.
  Auch manuelles Aufwecken kann eine neue Meldung auslösen.
- Erfolgreiches Senden beweist keinen Paketempfang und keine WoWLAN-Fähigkeit.
- BIOS, Treiber, Netzwerkkonfiguration und Cloud werden mit diesem Update nicht geändert.

Test an ROBERT:
1. Handy und ROBERT im selben normalen Heim-WLAN verwenden.
2. ROBERT per AutoForge in Standby schicken.
3. Nach etwa 30 Sekunden "Lokal aufwecken" drücken. Jetzt muss der Sendeversuch
   auch bei einer noch sichtbaren Online-Anzeige stattfinden.
4. Sendemeldung, Zieladressen und Ergebnis festhalten. Beim bisher beobachteten
   Netz 192.168.1.0/24 sollte 192.168.1.255 als Ziel enthalten sein.
5. Bei ausbleibender Reaktion ROBERT erst nach Ende des Versuchs manuell wecken.

Mit unveränderter v0.9.1 erst mindestens 90 Sekunden nach Standby warten und
gegebenenfalls die Geräteliste aktualisieren, bevor "Lokal aufwecken" gedrückt wird.

Bereitstellung:
Die Source-ZIP im Hauptordner von Kane101983/AutoForge-Mobile-app ablegen.
Der vorhandene GitHub-Workflow wählt die höchste Source-Version und erstellt
mit dem vorhandenen Signierschlüssel das Artefakt AutoForge-Mobile-SIGNED-APK.
Diese ZIP enthält Quellcode, keine installierbare APK.

Prüfung:
Die Verhaltensregressionen werden durch den beigefügten Node-Test abgedeckt.
Die eigentliche Android-Kompilierung und der Test am Handy stehen noch aus.
