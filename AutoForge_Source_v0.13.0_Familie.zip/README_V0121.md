# AutoForge Mobile 0.12.1 – Chat als Startseite

Die Startseite zeigt den Chat mit Eingabefeld, „Chats“ und „Neuer Chat“. Programme, Recherche, Übungen und Verbindungseinstellungen liegen im Menü. Chatdaten und gespeicherte KI-Einstellungen bleiben erhalten.

Unter AutoForge steht die tatsächlich installierte Android-Version mit Buildnummer. Sie wird aus der installierten App gelesen. Darunter steht die ausgewählte KI: ROBERT mit dem vom PC gemeldeten Modell oder OpenRouter mit der gewählten Modell-ID. Antippen öffnet die KI-Auswahl. Während einer Antwort steht dort „Antwort wird erstellt“. Wikipedia-Recherchen sind im Recherchebereich als solche bezeichnet. Cloud-Chat allein besitzt weiterhin keine Live-Websuche.

## Handy-Update bauen und installieren

1. `AutoForge_Source_v0.12.1_Chat.zip` unverändert bei https://github.com/Kane101983/AutoForge-Mobile-app/upload/main hochladen und speichern. Nicht entpacken.
2. Unter Actions den neuen erfolgreichen Build öffnen. Artefakt `AutoForge-Mobile-SIGNED-APK` herunterladen und entpacken.
3. `app-release.apk` auf dem Handy als Update installieren. Die bestehende App nicht deinstallieren.

Danach sollte im Kopfbereich **v0.12.1 · Build 38** stehen. Ein lokaler Chat braucht den eingeschalteten, verbundenen PC. Für OpenRouter im Menü den vorhandenen Schlüssel und ein kostenloses `:free`-Modell hinterlegen, sofern noch nicht gespeichert.

17 JavaScript-Prüfungen bestanden. Vollständiger Android-Build und Bedienung auf einem echten Handy sind für diese Version noch offen. Das ZIP ist Quellcode und keine installierbare APK. Neuer Stand liegt in der Codex-Arbeitskopie `work/mobile-v0.12.0`; deren Ordnername bleibt aus Kompatibilitätsgründen bestehen. Das Original auf G wurde mangels gewährter Schreibrechte nicht verändert.
