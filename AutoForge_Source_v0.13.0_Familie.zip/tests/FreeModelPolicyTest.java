import ai.autoforge.mobile.FreeModelPolicy;
import java.util.Map;

public class FreeModelPolicyTest {
    public static void main(String[] args) {
        check(FreeModelPolicy.allowed("demo:free",Map.of("prompt","0","completion","0.0")),"free");
        check(!FreeModelPolicy.allowed("demo",Map.of("prompt","0","completion","0")),"paid name");
        check(!FreeModelPolicy.allowed("demo:free",Map.of("prompt","0","completion","0.00001")),"paid completion");
        check(!FreeModelPolicy.allowed("demo:free",Map.of("prompt","0","completion","0","request","1")),"request charge");
        check(!FreeModelPolicy.allowed("demo:free",Map.of("prompt","0")),"missing price");
        check(!FreeModelPolicy.allowed("demo:free",Map.of("prompt","unknown","completion","0")),"malformed price");
        System.out.println("6 free-model policy checks passed");
    }
    private static void check(boolean condition,String message) { if(!condition)throw new AssertionError(message); }
}
