'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const sourceArgument = process.argv[2];
if (!sourceArgument) {
  console.error('Usage: node mobile-wake-tests.cjs <path-to-index.html>');
  process.exit(2);
}

const sourcePath = path.resolve(sourceArgument);
const html = fs.readFileSync(sourcePath, 'utf8');

// Extract complete, real declarations up to the following top-level function.
// These tests execute production code without duplicating its implementation.
function extractFunction(name) {
  const declaration = new RegExp(`^(?:async\\s+)?function\\s+${name}\\s*\\(`, 'm');
  const found = declaration.exec(html);
  assert.ok(found, `Production function ${name} must exist`);
  const remaining = html.slice(found.index);
  const nextDeclaration = /\n(?:async\s+)?function\s+\w+\s*\(/.exec(remaining);
  assert.ok(nextDeclaration, `Cannot locate the end of ${name}`);
  return remaining.slice(0, nextDeclaration.index);
}

const production = new vm.Script(
  `${extractFunction('remoteIsOnline')}\n${extractFunction('remoteLocalWake')}`,
  { filename: sourcePath },
);

const NOW = Date.parse('2026-09-25T18:00:00.000Z');
const DEVICE_ID = 'robert-test-device';
const MAC = '44:AF:28:35:D9:14';
const stamp = (milliseconds) => new Date(milliseconds).toISOString();

function device(lastSeen = NOW - 120000, overrides = {}) {
  return {
    id: DEVICE_ID,
    device_name: 'ROBERT',
    is_online: true,
    last_seen_at: stamp(lastSeen),
    status: { wake_mac: MAC },
    ...overrides,
  };
}

async function runWake({ initial, refreshed, nativeResult, nativeError } = {}) {
  let current = initial || device();
  const calls = { bridge: [], refresh: 0, timers: [] };
  const output = { textContent: '' };
  class FixedDate extends Date {
    constructor(...args) {
      super(...(args.length ? args : [NOW]));
    }
    static now() { return NOW; }
  }
  const sandbox = vm.createContext({
    Date: FixedDate,
    setTimeout(callback, delay) {
      calls.timers.push(delay);
      callback();
      return calls.timers.length;
    },
    remoteSelectedDevice(id) {
      return id === DEVICE_ID ? current : null;
    },
    async remoteRefreshDevices() {
      calls.refresh += 1;
      if (refreshed) current = refreshed;
    },
    async bridge(method, ...args) {
      calls.bridge.push({ method, args });
      if (nativeError) throw nativeError;
      return nativeResult || {
        ok: true,
        sent: 32,
        broadcasts: ['192.168.1.255', '255.255.255.255'],
      };
    },
  });
  production.runInContext(sandbox);
  await sandbox.remoteLocalWake(DEVICE_ID, output);
  return { calls, output: output.textContent };
}

function assertWakeSent(result) {
  assert.equal(result.calls.bridge.length, 1, 'An explicit local wake must call the native sender once');
  assert.equal(result.calls.bridge[0].method, 'sendWakePacket');
  assert.deepEqual(result.calls.bridge[0].args, [MAC]);
}

function assertNotConfirmed(result) {
  assert.ok(!result.output.includes('✅'), `A stale heartbeat must not confirm success: ${result.output}`);
  assert.ok(result.calls.refresh > 0, 'The wake attempt must check for a new heartbeat');
}

const cases = [
  ['Explicit wake sends despite a recent online record', async () => {
    const result = await runWake({ initial: device(NOW - 5000), refreshed: device(NOW) });
    assertWakeSent(result);
  }],
  ['An unchanged old online heartbeat cannot confirm wake', async () => {
    const old = device(NOW - 5000);
    const result = await runWake({ initial: old, refreshed: { ...old } });
    assertWakeSent(result);
    assertNotConfirmed(result);
    assert.match(result.output, /noch nicht online erkannt|nicht bestätigt|nicht bestaetigt|Zeitüberschreitung|Zeitueberschreitung/i);
  }],
  ['A fresh heartbeat at the time of the attempt confirms online', async () => {
    const result = await runWake({ initial: device(), refreshed: device(NOW) });
    assertWakeSent(result);
    assert.match(result.output, /✅.*ROBERT.*online/);
  }],
  ['A newer heartbeat from before the attempt cannot confirm wake', async () => {
    const result = await runWake({ initial: device(), refreshed: device(NOW - 30000) });
    assertWakeSent(result);
    assertNotConfirmed(result);
  }],
  ['Missing MAC explains the problem without sending', async () => {
    const result = await runWake({ initial: device(NOW - 120000, { status: {} }) });
    assert.equal(result.calls.bridge.length, 0);
    assert.equal(result.calls.refresh, 0);
    assert.match(result.output, /❌.*MAC/);
  }],
  ['Native sender failure remains visible', async () => {
    const error = 'WLAN-Bindung fehlgeschlagen: Netzwerk nicht verfügbar';
    const result = await runWake({ nativeResult: { ok: false, error } });
    assertWakeSent(result);
    assert.equal(result.calls.refresh, 0);
    assert.ok(result.output.includes(error), 'The native failure must not be replaced with a success message');
    assert.match(result.output, /^❌/);
  }],
  ['Rejected native bridge call remains visible', async () => {
    const error = new Error('Native Bridge nicht erreichbar');
    const result = await runWake({ nativeError: error });
    assertWakeSent(result);
    assert.equal(result.calls.refresh, 0);
    assert.ok(result.output.includes(error.message));
    assert.match(result.output, /^❌/);
  }],
];

(async () => {
  let failures = 0;
  console.log(`Wake regression tests: ${sourcePath}`);
  for (const [name, check] of cases) {
    try {
      await check();
      console.log(`PASS ${name}`);
    } catch (error) {
      failures += 1;
      console.error(`FAIL ${name}: ${error.message}`);
    }
  }
  console.log(`${cases.length - failures}/${cases.length} passed`);
  process.exitCode = failures ? 1 : 0;
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
