AutoForge Mobile 0.10.0 — PC Agent 0.5 / Brain 0.2

Neu: Meine KI mit gemeinsamen PC-Gesprächen und Ideen speichern.
Lernen: Wikipedia-Recherche, Quellenplan, Endzeit, CPU/RAM-Limits, Dateibudget je Lauf,
Stopp und Live-Protokoll. Das ist Wissenssammlung, noch kein Modelltraining.
Die Limits gelten nur für den Rechercheprozess. Chatmodell/GPU bleiben getrennt.

Voraussetzung: aktualisierter PC-Agent und Brain auf ROBERT.
Signierung unverändert über bestehenden GitHub-Workflow und vorhandenen Schlüssel.
versionCode 33; bestehende App aktualisieren, nicht deinstallieren, damit Kopplung erhalten bleibt.

Tests: Node-Backend/Recherche 9 bestanden; Mobile-Bridge 4 bestanden; bestehende
Wake-Regression 7 bestanden. .NET-Agent und Ressourcenhelfer bauen ohne Warnungen.
Echter Recherchetest: 2 Quellen, CPU 50 %, RAM 512 MB, Dateibudget 1 MB, erfolgreich.
Android-Build und visuelle Prüfung auf dem Handy sind noch ausstehend.
