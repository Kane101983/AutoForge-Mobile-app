# AutoForge Mobile 0.12.2 – Senden reagiert

Der Sendeknopf bleibt bedienbar. Bei laufender Arbeit erklärt ein weiterer Tipp den Zustand. Offene PC-Aufträge lassen sich über „Auftrag prüfen“ abholen; ein neuer Entwurf wird dabei nicht verschickt oder gelöscht. Ein offener PC-Auftrag blockiert den Wechsel zu OpenRouter nicht mehr.

Beim Start werden für einen als offline gemeldeten PC keine Chatlisten-Aufträge angelegt. Fehlende Verbindung oder Cloud-Einstellungen werden am Eingabefeld erklärt, die Einstellungen bei Bedarf geöffnet. Lesende PC-Abfragen warten nur noch begrenzt; offene Aufträge bleiben zur Wiederaufnahme gespeichert. Doppeltippen erzeugt keinen zweiten Auftrag.

## Auf dem Handy installieren

1. `AutoForge_Source_v0.12.2_Send_Fix.zip` bei https://github.com/Kane101983/AutoForge-Mobile-app/upload/main unverändert hochladen und speichern.
2. Nach erfolgreichem Actions-Build das Artefakt `AutoForge-Mobile-SIGNED-APK` herunterladen und entpacken.
3. Die enthaltene `app-release.apk` als Update installieren. Bestehende App nicht deinstallieren.

Danach wird oben **v0.12.2 · Build 39** angezeigt. Frage eintippen und Senden antippen. Für lokale Antworten muss ROBERT erreichbar sein. Die Cloud-KI benötigt weiterhin den eingerichteten OpenRouter-Schlüssel und ein kostenloses Modell.

24 automatische JavaScript-Prüfungen bestanden. APK-Bau und Test auf dem Handy stehen noch aus; dieses ZIP enthält Quellcode, keine installierbare APK. Der konkrete Fehlerzustand auf dem Handy ist ohne Gerätedaten nicht bestätigt, die im Quellcode gefundenen Sendesperren wurden behoben.

Arbeitskopie: `work/mobile-v0.12.0` (Ordnername bleibt bestehen). G-Original und installierte App wurden nicht verändert.
