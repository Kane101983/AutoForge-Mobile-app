
create table public.af_family_groups (
 id uuid primary key default gen_random_uuid(), owner_user_id uuid not null unique references auth.users(id) on delete cascade,
 name text not null default 'Meine Familie', created_at timestamptz not null default now()
);
create table public.af_family_members (
 group_id uuid not null references public.af_family_groups(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 display_name text not null, joined_at timestamptz not null default now(), primary key(group_id,user_id)
);
create index af_family_members_user on public.af_family_members(user_id);
create table public.af_family_invites (
 digest text primary key, group_id uuid not null references public.af_family_groups(id) on delete cascade,
 label text not null, expires_at timestamptz not null, used_by uuid references auth.users(id), created_at timestamptz not null default now()
);
create index af_family_invites_group on public.af_family_invites(group_id);
create table public.af_family_chats (
 id uuid primary key default gen_random_uuid(), group_id uuid not null references public.af_family_groups(id) on delete cascade,
 user_id uuid not null references auth.users(id), title text not null,
 archived boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index af_family_chats_group on public.af_family_chats(group_id,updated_at desc);
create table public.af_family_messages (
 id uuid primary key default gen_random_uuid(), chat_id uuid not null references public.af_family_chats(id) on delete cascade,
 user_id uuid not null references auth.users(id), role text not null check(role in ('user','assistant')), content text not null,
 local_id text not null, metadata jsonb not null default '{}', created_at timestamptz not null default now(),
 unique(chat_id,user_id,local_id)
);
create index af_family_messages_chat on public.af_family_messages(chat_id,created_at);
alter table public.af_family_groups enable row level security;
alter table public.af_family_members enable row level security;
alter table public.af_family_invites enable row level security;
alter table public.af_family_chats enable row level security;
alter table public.af_family_messages enable row level security;
revoke all on public.af_family_groups,public.af_family_members,public.af_family_invites,public.af_family_chats,public.af_family_messages from anon,authenticated;
grant all on public.af_family_groups,public.af_family_members,public.af_family_invites,public.af_family_chats,public.af_family_messages to service_role;

-- Only the authenticated Edge Function may supply actor. Not callable by app JWT roles.
-- Separate shared tables never broaden access to existing private chats or PC actions.
create function public.af_family_command(actor uuid, action text, payload jsonb default '{}')
returns jsonb language plpgsql security invoker set search_path = public, extensions, pg_temp as $$
declare
 gid uuid; cid uuid; owner_id uuid; token text; inv public.af_family_invites%rowtype;
 row_chat public.af_family_chats%rowtype; result jsonb; can_admin boolean;
begin
 if actor is null then raise exception 'Anmeldung erforderlich'; end if;
 if length(payload::text)>30000 then raise exception 'Anfrage zu groß'; end if;
 if action='overview' then
   select exists(select 1 from public.autoforge_remote_devices where owner_user_id=actor and revoked_at is null) into can_admin;
   select coalesce(jsonb_agg(jsonb_build_object('id',g.id,'name',g.name,'is_admin',g.owner_user_id=actor)), '[]'::jsonb)
     into result from public.af_family_groups g join public.af_family_members m on m.group_id=g.id where m.user_id=actor;
   return jsonb_build_object('groups',result,'can_create',can_admin);
 end if;
 if action='create' then
   if not exists(select 1 from public.autoforge_remote_devices where owner_user_id=actor and revoked_at is null) then
     raise exception 'Nur der gekoppelte PC-Besitzer kann eine Familie anlegen';
   end if;
   insert into public.af_family_groups(owner_user_id,name) values(actor,'Meine Familie')
     on conflict(owner_user_id) do update set name=af_family_groups.name returning id into gid;
   insert into public.af_family_members(group_id,user_id,display_name) values(gid,actor,'Admin')
     on conflict do nothing;
   return jsonb_build_object('group_id',gid);
 end if;
 if action='join' then
   token:=upper(replace(trim(coalesce(payload->>'code','')),'-',''));
   if token !~ '^[0-9A-F]{32}$' then raise exception 'Einladungscode ungültig'; end if;
   select * into inv from public.af_family_invites where digest=encode(extensions.digest(token,'sha256'),'hex') for update;
   if not found or inv.expires_at<=now() or inv.used_by is not null then raise exception 'Einladung ungültig, abgelaufen oder bereits verwendet'; end if;
   perform 1 from public.af_family_groups where id=inv.group_id for update;
   if (select count(*) from public.af_family_members where group_id=inv.group_id)>=16 then raise exception 'Maximal 16 Familienmitglieder'; end if;
   insert into public.af_family_members(group_id,user_id,display_name) values(inv.group_id,actor,left(coalesce(nullif(trim(payload->>'name'),''),inv.label),60))
     on conflict do nothing;
   update public.af_family_invites set used_by=actor where digest=inv.digest;
   return jsonb_build_object('group_id',inv.group_id);
 end if;
 gid:=(payload->>'group_id')::uuid;
 select owner_user_id into owner_id from public.af_family_groups where id=gid;
 if owner_id is null or not exists(select 1 from public.af_family_members where group_id=gid and user_id=actor) then
   raise exception 'Kein Zugriff auf diese Familie';
 end if;
 if action='members' then
   select coalesce(jsonb_agg(jsonb_build_object('user_id',user_id,'name',display_name,'is_admin',user_id=owner_id)),'[]'::jsonb)
     into result from public.af_family_members where group_id=gid;
   return jsonb_build_object('members',result);
 end if;
 if action='invite' then
   if owner_id<>actor then raise exception 'Nur der Admin darf einladen'; end if;
   perform 1 from public.af_family_groups where id=gid for update;
   if (select count(*) from public.af_family_invites where group_id=gid and used_by is null and expires_at>now())>=16 then raise exception 'Zu viele offene Einladungen'; end if;
   token:=upper(replace(gen_random_uuid()::text,'-',''));
   insert into public.af_family_invites(digest,group_id,label,expires_at)
     values(encode(extensions.digest(token,'sha256'),'hex'),gid,left(coalesce(nullif(trim(payload->>'name'),''),'Familienmitglied'),60),now()+interval '24 hours');
   return jsonb_build_object('code',token,'expires_at',now()+interval '24 hours');
 end if;
 if action='revoke_invites' then
   if owner_id<>actor then raise exception 'Nur der Admin darf Einladungen widerrufen'; end if;
   update public.af_family_invites set expires_at=now() where group_id=gid and used_by is null;
   return jsonb_build_object('ok',true);
 end if;
 if action='remove_member' then
   if owner_id<>actor then raise exception 'Nur der Admin darf Mitglieder entfernen'; end if;
   if (payload->>'user_id')::uuid=owner_id then raise exception 'Admin kann nicht entfernt werden'; end if;
   delete from public.af_family_members where group_id=gid and user_id=(payload->>'user_id')::uuid;
   return jsonb_build_object('ok',true);
 end if;
 if action='chat_list' then
   select coalesce(jsonb_agg(to_jsonb(c) order by c.updated_at desc),'[]'::jsonb) into result
     from public.af_family_chats c where group_id=gid and not archived;
   return jsonb_build_object('chats',result);
 end if;
 if action='chat_create' then
   insert into public.af_family_chats(group_id,user_id,title) values(gid,actor,left(coalesce(nullif(trim(payload->>'title'),''),'Familienchat'),160)) returning * into row_chat;
   return jsonb_build_object('chat',to_jsonb(row_chat));
 end if;
 cid:=(payload->>'chat_id')::uuid;
 select * into row_chat from public.af_family_chats where id=cid and group_id=gid and not archived;
 if not found then raise exception 'Familienchat nicht zugänglich'; end if;
 if action='chat_load' then
   select coalesce(jsonb_agg(to_jsonb(m) || jsonb_build_object('author',coalesce(n.display_name,'Ehemaliges Mitglied')) order by m.created_at),'[]'::jsonb)
   into result from (select * from public.af_family_messages where chat_id=cid order by created_at desc limit 250) m
   left join public.af_family_members n on n.group_id=gid and n.user_id=m.user_id;
   return jsonb_build_object('chat',to_jsonb(row_chat),'messages',result);
 end if;
 if action='chat_delete' then
   if owner_id<>actor and row_chat.user_id<>actor then raise exception 'Nur Ersteller oder Admin darf diesen gemeinsamen Chat löschen'; end if;
   update public.af_family_chats set archived=true where id=cid;
   return jsonb_build_object('ok',true);
 end if;
 if action='message_add' then
   if coalesce(payload->>'role','') not in ('user','assistant') or length(coalesce(payload->>'content','')) not between 1 and 20000
      or length(coalesce(payload->'metadata'->>'local_id','')) not between 1 and 160 then raise exception 'Nachricht ungültig'; end if;
   insert into public.af_family_messages(chat_id,user_id,role,content,local_id,metadata)
     values(cid,actor,payload->>'role',payload->>'content',payload->'metadata'->>'local_id',
       jsonb_build_object('local_id',payload->'metadata'->>'local_id','model',left(payload->'metadata'->>'model',200)))
     on conflict(chat_id,user_id,local_id) do nothing;
   update public.af_family_chats set updated_at=now() where id=cid;
   return jsonb_build_object('chat_id',cid);
 end if;
 raise exception 'Familienaktion nicht unterstützt';
end;
$$;
revoke all on function public.af_family_command(uuid,text,jsonb) from public,anon,authenticated;
grant execute on function public.af_family_command(uuid,text,jsonb) to service_role;

