import { familyHandler } from './handler.mjs';
Deno.serve(familyHandler({url:Deno.env.get('SUPABASE_URL')!,key:Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!}));
