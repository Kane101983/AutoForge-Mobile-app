const actions=new Set(['overview','create','join','members','invite','revoke_invites','remove_member','chat_list','chat_create','chat_load','chat_delete','message_add']);
export function familyHandler({url,key,fetcher=fetch}){
 const reply=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,apikey,content-type'}});
 return async req=>{
  if(req.method==='OPTIONS')return reply({ok:true});
  if(req.method!=='POST')return reply({error:'POST erforderlich'},405);
  const auth=req.headers.get('authorization')||'';
  if(!auth.startsWith('Bearer '))return reply({error:'Anmeldung erforderlich'},401);
  try{
   const userResponse=await fetcher(url+'/auth/v1/user',{headers:{apikey:key,Authorization:auth},signal:AbortSignal.timeout(10000)});
   if(!userResponse.ok)return reply({error:'Anmeldung ungültig'},401);
   const user=await userResponse.json();if(!user.id)return reply({error:'Anmeldung ungültig'},401);
   const raw=await req.text();if(raw.length>30000)return reply({error:'Anfrage zu groß'},413);
   const body=JSON.parse(raw);if(!actions.has(body.action))return reply({error:'Familienaktion nicht unterstützt'},400);
   // actor is derived exclusively from the verified session, never from body fields.
   const result=await fetcher(url+'/rest/v1/rpc/af_family_command',{method:'POST',headers:{apikey:key,Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({actor:user.id,action:body.action,payload:body}),signal:AbortSignal.timeout(15000)});
   const data=await result.json();
   if(!result.ok)return reply({error:data.message||'Familienaktion fehlgeschlagen'},403);
   return reply(data);
  }catch{return reply({error:'Familienverbindung vorübergehend nicht verfügbar. Bitte erneut versuchen.'},503);}
 };
}
