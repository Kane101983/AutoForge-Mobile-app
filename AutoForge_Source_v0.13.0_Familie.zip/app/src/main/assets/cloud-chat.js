/* Cloud conversations use only their own history, never local PC messages. */
window.AutoForgeCloudChat=class {
 constructor(bridge,storage){this.bridge=bridge;this.storage=storage;this.pendingKey='af_studio_cloud_pending';this.groupId='';}
 setGroup(groupId){this.groupId=groupId||'';this.pendingKey='af_studio_cloud_pending'+(this.groupId?'_'+this.groupId:'');}
 async gateway(action,extra={}){const d=await this.bridge('cloudRequest',JSON.stringify({action,...extra}));if(!d||d._cloud_ok===false||d.error||d.ok===false)throw Error(d?.error||'Cloud-Anfrage fehlgeschlagen');return d;}
 async call(action,extra={}){const d=await this.bridge(this.groupId?'familyRequest':'cloudRequest',JSON.stringify({action,...extra,...(this.groupId?{group_id:this.groupId}:{})}));if(!d||d._cloud_ok===false||d.error)throw Error(d?.error||'AutoForge Cloud nicht erreichbar.');return d;}
 pending(){try{return JSON.parse(this.storage.getItem(this.pendingKey)||'null');}catch{throw Error('Auftragsdaten beschädigt. Bitte Cloud-Verlauf prüfen.');}}
 save(p){this.storage.setItem(this.pendingKey,JSON.stringify(p));}
 config(){const key=this.storage.getItem('af_or_key')||'',model=(this.storage.getItem('af_or_model')||'').trim();const provider=this.storage.getItem('af_cloud_provider')||(key?'openrouter':'gateway');if(provider==='gateway')return {provider};if(!key)throw Error('Bitte deinen OpenRouter-Schlüssel unter Einstellungen hinterlegen.');if(!model.endsWith(':free'))throw Error('Bitte ein OpenRouter-Modell mit der Endung :free auswählen.');return {key,model,provider};}
 async list(){const d=await this.call('chat_list');return (d.chats||[]).map(c=>({...c,created:c.created_at,updated:c.updated_at,fullTitle:c.title}));}
 async history(chatId){if(!chatId)return [];return (await this.call('chat_load',{chat_id:chatId})).messages||[];}
 async remove(chatId){if(this.pending())throw Error('Bitte zuerst den offenen Cloud-Auftrag klären.');return this.call('chat_delete',{chat_id:chatId});}
 async send(chatId,message){this.config();if(typeof message!=='string'||!message.trim()||message.length>6000)throw Error('Bitte eine Nachricht mit höchstens 6000 Zeichen eingeben.');if(this.pending())throw Error('Ein Cloud-Auftrag ist offen. Bitte Antwort erneut abrufen.');
  if(!chatId){const d=await this.call('chat_create',{title:message.slice(0,65)});chatId=d.chat?.id;if(!chatId)throw Error('Cloud-Gespräch konnte nicht erstellt werden.');}
  const id='studio-'+Date.now()+'-'+Math.random().toString(36).slice(2);this.save({chatId,message,id,stage:'user'});return this.resume();
 }
 async resume(){const p=this.pending();if(!p)throw Error('Kein offener Cloud-Auftrag.');const config=this.config();
  let rows=await this.history(p.chatId);
  if(p.stage==='user'){
   if(!rows.some(m=>m.metadata?.local_id===p.id))await this.call('message_add',{chat_id:p.chatId,role:'user',content:p.message,metadata:{local_id:p.id,type:'text'}});
   p.stage='answer';this.save(p);rows=await this.history(p.chatId);
  }
  if(p.stage==='answer'){
   let remaining=12000;const recent=[];
   for(const m of [...rows].reverse()){if(!['user','assistant'].includes(m.role)||recent.length>=12||remaining<=0)continue;const content=String(m.content||'').slice(-Math.min(remaining,4000));recent.unshift({role:m.role,content});remaining-=content.length;}
   const system='Du bist AutoForge. Antworte verständlich auf Deutsch und berücksichtige den Gesprächsverlauf. Behaupte keine ausgeführten PC-Aktionen oder Internetsuchen. Dieser Cloud-Chat besitzt diese Werkzeuge nicht. Stelle höchstens eine notwendige Rückfrage.';
   let r;
   if(config.provider==='gateway'){
    const {providers=[]}=await this.gateway('providers');
    const route=providers.find(x=>x.id==='pollinations'&&x.enabled&&x.free_tier&&!x.requires_user_key&&x.execution_location==='cloud'&&!['down','quota_exhausted'].includes(x.health));
    if(!route)throw Error('Der bisherige Cloud-Zugang ist gerade nicht verfügbar. Bitte später erneut versuchen.');
    r=await this.gateway('execute',{provider:route.id,capability:'general',model:route.model||'',system,prompt:'Gesprächsverlauf (JSON mit Rollen). Beantworte die letzte Nutzerfrage unter Berücksichtigung dieses Verlaufs:\n'+JSON.stringify(recent)});
   }else r=await this.bridge('freeOpenRouterChat',config.key,config.model,JSON.stringify(recent),system);
   if(!r?.ok||!String(r.text||'').trim())throw Error(r?.error||'Cloud-KI lieferte keine Antwort.');
   p.answer=r.text;p.model=r.model||config.model||r.provider||'AutoForge Cloud';p.stage='save';this.save(p);
  }
  rows=await this.history(p.chatId);
  if(!rows.some(m=>m.metadata?.local_id===p.id+'-answer'))await this.call('message_add',{chat_id:p.chatId,role:'assistant',content:p.answer,metadata:{local_id:p.id+'-answer',type:'text',model:p.model}});
  this.storage.removeItem(this.pendingKey);return {chatId:p.chatId};
 }
};
