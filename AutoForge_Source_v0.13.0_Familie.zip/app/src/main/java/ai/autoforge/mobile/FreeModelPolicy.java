package ai.autoforge.mobile;

import java.math.BigDecimal;
import java.util.Map;

/** Fail closed when the live catalog is missing, malformed, or priced. */
public final class FreeModelPolicy {
    private FreeModelPolicy() {}
    public static boolean allowed(String model, Map<String, String> pricing) {
        if (model == null || !model.endsWith(":free") || pricing == null
                || !pricing.containsKey("prompt") || !pricing.containsKey("completion")) return false;
        try {
            for (String value : pricing.values())
                if (value == null || new BigDecimal(value).compareTo(BigDecimal.ZERO) != 0) return false;
            return true;
        } catch (NumberFormatException e) { return false; }
    }
}
