# AutoForge Mobile 0.13.0 – Cloud-Chat und Familie

## Installieren

`AutoForge_Source_v0.13.0_Familie.zip` unverändert in das vorhandene GitHub-Projekt hochladen:
https://github.com/Kane101983/AutoForge-Mobile-app/upload/main

Nach erfolgreichem Actions-Build das Artefakt **AutoForge-Mobile-SIGNED-APK** herunterladen und entpacken. Die enthaltene **app-release.apk** ist die Datei für dein Handy, deine Frau und deinen Schwager. Das Quell-ZIP selbst lässt sich nicht als App installieren.

Auf deinem Handy als Update installieren, nicht vorher deinstallieren. Oben muss danach **v0.13.0 · Build 41** stehen. Die APK enthält keine Anmeldung und keine persönlichen Chats; jede neue Installation bekommt einen eigenen Zugang.

## Direkt chatten

Neue Installationen starten mit Cloud-KI. Bei einem bestehenden Handy im Menü unter **Antworten mit** die Cloud-KI und unter **Cloud-Zugang** **AutoForge Cloud · vorhandener Zugang** wählen. Dann zurück zu Chat, Frage eingeben und Senden.

Dieser Weg benutzt den bereits eingerichteten Cloud-Zugang. Ein eigener OpenRouter-Schlüssel ist hierfür nicht erforderlich. OpenRouter bleibt eine zusätzliche, ausdrücklich auswählbare Möglichkeit. Verfügbarkeit und Nutzungslimits des bestehenden Cloud-Anbieters gelten weiterhin. Normale Cloud-Antworten sind noch keine Live-Internetsuche; der bisherige Web-Scout bleibt über die bisherige Oberfläche erreichbar.

## Deine Frau oder deinen Schwager einladen

1. Auf deinem gekoppelten Besitzer-Handy: **Menü → Familie & Einladungen → Familie anzeigen**.
2. Beim ersten Mal **Meine Familie anlegen**. Diese Funktion erhält nur ein gekoppelter PC-Besitzer.
3. Namen eintragen, **Einladungscode erstellen**, danach **Einladung teilen**. Der Android-Teilen-Dialog überlässt dir Empfänger und Versand.
4. Die andere Person installiert dieselbe APK und öffnet **Menü → Familie & Einladungen → Einladung annehmen**. Dort Namen und Code eingeben.
5. Nach **Familie anzeigen** lässt sich im Cloud-Chat zwischen **Privat · nur ich** und **Meine Familie · gemeinsam** wechseln.

Jeder Code gilt 24 Stunden und nur einmal. Für die zweite Person einen eigenen Code erstellen. Nur ausdrücklich neu angelegte Familienchats sind gemeinsam. Bestehende private Chats werden nicht kopiert. Du kannst Mitglieder entfernen oder offene Einladungen widerrufen. Durch die Einladung erhält niemand Zugriff auf deinen PC. Gemeinsame Chats aktualisiert man über Chats; ein automatischer Echtzeit-Abgleich ist noch nicht eingebaut.

## Stand und Grenzen

- Familien-Datenbank und authentifizierter Familien-Endpunkt sind bereits bereitgestellt. Bestehende private Chat- und PC-Rechte wurden nicht erweitert.
- 32 automatische JavaScript-Prüfungen bestanden. Datenbanktests bestätigen Einmal-Einladungen, Mitgliedersperren, getrennte private Chats, verweigerte Admin-Aktionen und Nachrichtenduplikat-Schutz; Testdaten zurückgerollt.
- Echter Cloud-Test erfolgreich, Modellrückmeldung `openai/gpt-5.4-nano`. Familien-Endpunkt mit neuer Testsitzung erfolgreich geprüft, Nicht-Besitzer beim Anlegen einer Familie abgewiesen. Die Testsitzung wurde anschließend entfernt.
- Vollständiger Android-Bau und Prüfung auf echten Familien-Handys stehen noch aus. Stand daher noch nicht als fertig getestete APK ausgeben.
- Zugang derzeit an die App-Installation gebunden. App-Daten nicht löschen. Kontoanmeldung mit Wiederherstellung für Gerätewechsel fehlt noch. Ein Verbindungsfehler erzeugt jetzt keine neue Identität mehr.
- Quellstand liegt im Codex-Arbeitsordner `work/mobile-v0.12.0` (Ordnername beibehalten). G-Original wurde mangels gewährter Schreibrechte nicht aktualisiert.

Die neue Datenbank verwendet absichtlich RLS ohne Client-Leserechte; Zugriff ausschließlich über den geprüften Familien-Endpunkt. Der entsprechende [Supabase-Prüfhinweis](https://supabase.com/docs/guides/database/database-linter?lint=0008_rls_enabled_no_policy) ist bei diesen fünf Tabellen erwartetes Verhalten. Bestehende Hinweise zu gerätegebundenen anonymen Anmeldungen bleiben bestehen; [Hintergrund](https://supabase.com/docs/guides/auth/auth-anonymous).
