/* A pending cloud job is not a streamed model response. Report only confirmed states. */
(()=>{
 const panel=element('aside','','localTask card');panel.id='localTask';panel.hidden=true;panel.setAttribute('aria-label','Offener PC-Auftrag');
 const title=element('strong',''),detail=element('p',''),time=element('small',''),actions=element('div','','row');
 const pause=element('button','Warten beenden'),check=element('button','Auftrag prüfen'),chooseCloud=element('button','Cloud-KI nutzen');
 pause.id='localTaskPause';check.id='localTaskCheck';chooseCloud.id='localTaskCloud';title.id='localTaskTitle';detail.id='localTaskDetail';time.id='localTaskTime';
 for(const b of [pause,check,chooseCloud])b.type='button';
 actions.append(pause,check,chooseCloud);panel.append(title,detail,time,actions);$('messages').before(panel);
 let jobState='',jobId='';
 function render(){
  panel.hidden=!pending||engine!=='local'||!!cloud.groupId;if(panel.hidden)return;
  if(jobId!==pending.id){jobId=pending.id;jobState='';}
  const labels={chat:'Antwort', 'project-build':'Programmauftrag',history:'Chatverlauf',list:'Chatliste',projects:'Projektliste',storage:'Speicherübersicht','learn-start':'Rechercheauftrag','practice-start':'Übungsauftrag'};
  title.textContent=(labels[pending.operation]||'PC-Auftrag')+' · '+(jobState==='queued'?'Wartet auf den PC':jobState==='running'?'Vom PC übernommen':'Bestätigung prüfen');
  detail.textContent=jobState==='queued'?'Der PC-Agent hat diesen Auftrag noch nicht übernommen. Der PC muss eingeschaltet und mit AutoForge verbunden sein.':jobState==='running'?'Der PC bearbeitet den Auftrag. Einzelne Modellschritte und laufender Antworttext werden noch nicht ans Handy übertragen.':'Dieser Auftrag bleibt gespeichert. Erneut prüfen fragt denselben Auftrag ab und sendet ihn nicht noch einmal.';
  const age=Number.isFinite(pending.createdAt)?Math.max(0,Math.floor((Date.now()-pending.createdAt)/1000)):null;
  time.textContent=age===null?'Startzeit für diesen älteren Auftrag nicht gespeichert.':'Seit Übertragung: '+Math.floor(age/60)+' Min. '+(age%60)+' Sek.';
  pause.hidden=!busy;pause.disabled=localPollPaused;check.hidden=busy;chooseCloud.hidden=busy;
 }
 pause.onclick=()=>{localPollPaused=true;pause.disabled=true;detail.textContent='Die Anzeige wird angehalten. Der PC-Auftrag wird dadurch nicht abgebrochen.';};
 check.onclick=()=>{if(!busy&&pending)action(recoverLocal);};
 chooseCloud.onclick=()=>{if(busy)return;$('engineSelect').value='cloud';$('engineSelect').onchange?.();};
 window.AutoForgeLocalTask={render,begin(){jobState='queued';jobId=pending?.id||'';render();},update(job){jobState=job.status;jobId=pending?.id||'';render();}};
 setInterval(()=>{if(!document.hidden)render();},1000);render();
})();
