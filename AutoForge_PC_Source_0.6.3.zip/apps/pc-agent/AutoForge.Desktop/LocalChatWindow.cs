using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Button = System.Windows.Controls.Button;
using TextBox = System.Windows.Controls.TextBox;
using ComboBox = System.Windows.Controls.ComboBox;
using CheckBox = System.Windows.Controls.CheckBox;
using Panel = System.Windows.Controls.Panel;
using Color = System.Windows.Media.Color;
using Brushes = System.Windows.Media.Brushes;
using Orientation = System.Windows.Controls.Orientation;
using TabControl = System.Windows.Controls.TabControl;

namespace AutoForge.Desktop;

// Uses the installed, token-authenticated loopback brain; no arbitrary commands.
public sealed class LocalChatWindow : Window
{
    private readonly LocalBrainBridgeService _brain;
    private readonly ComboBox _chats = new() { MinWidth = 220, Margin = new Thickness(4) };
    private readonly TextBox _prompt = new() { AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 90, MaxLength = 6000, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private readonly StackPanel _messages = new();
    private readonly ScrollViewer _scroll = new() { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    private readonly TextBlock _status = new() { Text = "Lokale KI über Ollama · wird bei Bedarf gestartet", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(4, 8, 4, 8) };
    private readonly TextBlock _researchStatus = new() { TextWrapping = TextWrapping.Wrap };
    private readonly TextBox _topic = new() { MaxLength = 200 };
    private readonly TextBox _cpu = new() { Text = "50" }, _ram = new() { Text = "512" }, _disk = new() { Text = "10" }, _sources = new() { Text = "5" }, _deadline = new() { Text = DateTime.Now.AddHours(1).ToString("yyyy-MM-dd HH:mm") };
    private readonly CheckBox _internet = new() { Content = "Internet für diesen Recherchelauf erlauben" };
    private readonly TextBox _log = new() { IsReadOnly = true, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MinHeight = 120 };
    private readonly Button _send = new() { Content = "Senden ↑", Margin = new Thickness(4) };
    private readonly Button _new = new() { Content = "＋ Neuer Chat", Margin = new Thickness(4) };
    private string? _chat;
    private bool _busy, _selecting;

    public LocalChatWindow(LocalBrainBridgeService brain)
    {
        _brain = brain; Title = "AutoForge · Meine lokale KI"; Width = 920; Height = 760; MinWidth = 580; MinHeight = 500;
        Background = new SolidColorBrush(Color.FromRgb(7, 19, 30)); Foreground = Brushes.White;
        foreach (var type in new[] { typeof(Button), typeof(TextBox), typeof(ComboBox), typeof(ComboBoxItem), typeof(TabControl), typeof(TabItem) })
        {
            var style = new Style(type); style.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(16, 43, 58)))); style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White)); style.Setters.Add(new Setter(Control.BorderBrushProperty, Brushes.DarkCyan)); Resources[type] = style;
        }
        var textStyle = new Style(typeof(TextBlock)); textStyle.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.White)); Resources[typeof(TextBlock)] = textStyle;
        var tabs = new TabControl { Margin = new Thickness(16) };
        var chatTab = new TabItem { Header = "Chat · Ollama" }; var researchTab = new TabItem { Header = "Internet & Gedächtnis" };
        tabs.Items.Add(chatTab); tabs.Items.Add(researchTab); Content = tabs;
        var grid = new Grid { Margin = new Thickness(14) };
        foreach (var h in new[] { GridLength.Auto, GridLength.Auto, new GridLength(1, GridUnitType.Star), GridLength.Auto, GridLength.Auto }) grid.RowDefinitions.Add(new RowDefinition { Height = h });
        var toolbar = new StackPanel { Orientation = Orientation.Horizontal }; toolbar.Children.Add(_chats); toolbar.Children.Add(_new);
        var reload = new Button { Content = "Verlauf laden", Margin = new Thickness(4) }; toolbar.Children.Add(reload);
        grid.Children.Add(toolbar); Grid.SetRow(_status, 1); grid.Children.Add(_status);
        _scroll.Content = _messages; Grid.SetRow(_scroll, 2); grid.Children.Add(_scroll);
        Grid.SetRow(_prompt, 3); grid.Children.Add(_prompt); Grid.SetRow(_send, 4); grid.Children.Add(_send); chatTab.Content = grid;
        _send.Click += async (_, _) => await Run(Send); reload.Click += async (_, _) => await Run(async () => { await LoadChats(); await History(); });
        _new.Click += (_, _) => { if (_busy) return; _chat = null; _selecting = true; _chats.SelectedIndex = -1; _selecting = false; _messages.Children.Clear(); _prompt.Focus(); };
        _chats.SelectionChanged += async (_, _) => { if (!_selecting && !_busy && _chats.SelectedItem is ComboBoxItem item) { _chat = item.Tag as string; await Run(History); } };
        _prompt.PreviewKeyDown += async (_, e) => { if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.Control) { e.Handled = true; await Run(Send); } };
        var panel = new StackPanel { Margin = new Thickness(14) }; researchTab.Content = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        panel.Children.Add(new TextBlock { Text = "Quellen für spätere Antworten recherchieren. Keine Änderung der Modellgewichte. Internet nur nach deiner Freigabe; Daten auf G.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 12) });
        AddField(panel, "Thema", _topic); AddField(panel, "Endzeit (yyyy-MM-dd HH:mm, höchstens 24 Stunden)", _deadline); AddField(panel, "CPU-Limit Rechercheprozess (%)", _cpu); AddField(panel, "RAM-Limit Rechercheprozess (MB)", _ram); AddField(panel, "Neue Dateien maximal (MB)", _disk); AddField(panel, "Maximale Wikipedia-Quellen", _sources);
        panel.Children.Add(new TextBlock { Text = "Grenzen gelten für den Rechercheprozess. Das Ollama-Chatmodell hat eigene Anforderungen.", TextWrapping = TextWrapping.Wrap }); panel.Children.Add(_internet);
        var start = new Button { Content = "Recherche starten", Margin = new Thickness(0, 10, 0, 6) }; var stop = new Button { Content = "Recherche stoppen", Margin = new Thickness(0, 0, 0, 6) }; var refresh = new Button { Content = "Protokoll & Speicher aktualisieren", Margin = new Thickness(0, 0, 0, 10) };
        panel.Children.Add(start); panel.Children.Add(stop); panel.Children.Add(refresh); panel.Children.Add(_researchStatus); panel.Children.Add(_log);
        start.Click += async (_, _) => await Run(async () => { if (_internet.IsChecked != true) throw new InvalidOperationException("Bitte Internet für diesen Lauf erlauben."); if (!DateTime.TryParseExact(_deadline.Text, "yyyy-MM-dd HH:mm", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var end)) throw new InvalidOperationException("Bitte eine gültige Endzeit eingeben."); await Call("learn-start", new JsonObject { ["learning"] = new JsonObject { ["topic"] = _topic.Text, ["cpuPercent"] = int.Parse(_cpu.Text), ["ramMb"] = int.Parse(_ram.Text), ["diskMb"] = int.Parse(_disk.Text), ["packages"] = int.Parse(_sources.Text), ["deadline"] = new DateTimeOffset(end).ToUniversalTime().ToString("O") } }); await ResearchStatus(); });
        stop.Click += async (_, _) => await Run(async () => { await Call("learn-stop"); await ResearchStatus(); }); refresh.Click += async (_, _) => await Run(ResearchStatus);
        Loaded += async (_, _) => await Run(LoadChats);
    }
    private static void AddField(Panel panel, string label, TextBox field) { panel.Children.Add(new TextBlock { Text = label, Margin = new Thickness(0, 8, 0, 3) }); field.Padding = new Thickness(7); panel.Children.Add(field); }
    private Task<JsonObject> Call(string operation, JsonObject? extra = null) { var p = extra ?? new JsonObject(); p["operation"] = operation; return _brain.ExecuteAsync("desktop-" + Guid.NewGuid().ToString("N"), p); }
    private async Task Run(Func<Task> action) { if (_busy) return; _busy = true; _send.IsEnabled = _new.IsEnabled = _chats.IsEnabled = false; _status.Text = "AutoForge arbeitet …"; try { await action(); _status.Text = "Bereit · lokale KI über Ollama · Strg+Enter sendet"; } catch (Exception e) { _status.Text = e.Message + " · Entwurf bleibt erhalten. Verlauf laden prüft bereits gespeicherte Antworten."; } finally { _busy = false; _send.IsEnabled = _new.IsEnabled = _chats.IsEnabled = true; } }
    private async Task LoadChats() { var d = await Call("list"); _selecting = true; try { _chats.Items.Clear(); foreach (var c in (d["chats"] as JsonArray ?? new JsonArray())) { var id = c?["id"]?.GetValue<string>(); var item = new ComboBoxItem { Tag = id, Content = c?["title"]?.GetValue<string>() ?? "Gespräch", ToolTip = c?["updated"]?.GetValue<string>() ?? c?["created"]?.GetValue<string>() }; _chats.Items.Add(item); if (id == _chat) _chats.SelectedItem = item; } } finally { _selecting = false; } }
    private async Task History() { if (_chat is null) return; var d = await Call("history", new JsonObject { ["chatId"] = _chat }); var follow = _scroll.ScrollableHeight - _scroll.VerticalOffset < 45; var previous = _scroll.VerticalOffset; _messages.Children.Clear(); foreach (var m in d["messages"] as JsonArray ?? new JsonArray()) { var user = m?["role"]?.GetValue<string>() == "user"; _messages.Children.Add(new TextBlock { Text = (user ? "DU" : "AUTOFORGE · " + d["model"]?.GetValue<string>()) + "\n" + m?["content"]?.GetValue<string>(), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(user ? 30 : 4, 10, 4, 15), Foreground = user ? Brushes.LightCyan : Brushes.White }); } _scroll.UpdateLayout(); if (follow) _scroll.ScrollToEnd(); else _scroll.ScrollToVerticalOffset(previous); }
    private async Task Send() { var text = _prompt.Text.Trim(); if (text.Length == 0) throw new InvalidOperationException("Bitte eine Nachricht eingeben."); var d = await Call("chat", new JsonObject { ["chatId"] = _chat, ["message"] = text }); _chat = d["chatId"]?.GetValue<string>() ?? _chat; _prompt.Clear(); await LoadChats(); await History(); }
    private async Task ResearchStatus() { var d = await Call("learn-status"); var j = d["job"]; var storage = await Call("storage"); _researchStatus.Text = j is null ? "Noch keine Recherche." : $"{j["message"]} · {j["processed"]}/{j["packages"]} Quellen · {j["percent"]}% · {j["bytes"]} Bytes\nLogdatei: {j["logFile"]}"; _researchStatus.Text += $"\nRecherchedateien: {storage["research"]} Bytes · Modelle: {storage["models"]} Bytes"; _log.Text = string.Join("\n", (j?["events"] as JsonArray ?? new JsonArray()).Select(e => $"{e?["time"]} · {e?["message"]}")); }
}
