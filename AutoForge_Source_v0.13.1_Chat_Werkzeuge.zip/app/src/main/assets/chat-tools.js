/* Web results and selected files are data, never instructions for executing code. */
window.AutoForgeChatTools={
 searchIntent(message,rows=[]){
  const explicit=/\b(such\w*|recherch\w*|finde|find\w*|internet|web|angebote|links)\b/i.test(message);
  const car=/\b(auto|autos|wagen|pkw|fahrzeug|gebrauchtwagen)\b/i.test(message);
  const earlier=rows.filter(m=>m.role==='user').slice(-4).reverse().map(m=>String(m.content||'').split('\n\n--- Angefügte Datei:')[0]).find(text=>/\b(auto|wagen|pkw)\b/i.test(text));
  const follow=/\b(links|angebote|billiger|teurer|unter|bis)\b/i.test(message)&&!!earlier;
  if(!explicit&&!follow)return null;
  const base=follow&&!car?earlier+' · '+message:message;
  const query=base+((car||follow)&&!/\b(deutschland|berlin|hamburg|münchen|umkreis|nähe|\d{5})\b/i.test(base)?' · deutschlandweit, alle Marken und Modelle':'');
  const budget=message.match(/(\d[\d.,]*)\s*(?:euro|eur|€)/i)||(follow?earlier.match(/(\d[\d.,]*)\s*(?:euro|eur|€)/i):null);
  return {query,car:car||follow,budget:budget?Number(budget[1].replace(/\.(?=\d{3}(?:\D|$))/g,'').replace(',','.')):null};
 },
 safeUrl(raw){try{const u=new URL(raw);return ['https:','http:'].includes(u.protocol)?u.href:'';}catch{return ''; }},
 async search(bridge,intent,rows){
  let data;try{data=await bridge('cloudSearchRequest',JSON.stringify({query:intent.query,context:rows.slice(-4).map(m=>m.role+': '+String(m.content||'').split('\n\n--- Angefügte Datei:')[0]).join('\n').slice(-3000),max_results:6}));}catch{}
  const results=(data?.ok&&Array.isArray(data.results)?data.results:[]).filter(r=>this.safeUrl(r.url));
  const intro=intent.car?'Ich suche zunächst deutschlandweit und markenoffen.':'Ergebnisse der Websuche:';
  if(results.length)return {text:intro+'\n\n'+results.map((r,i)=>(i+1)+'. '+String(r.title||'Treffer')+'\n'+this.safeUrl(r.url)+'\n'+String(r.snippet||'')).join('\n\n')+'\n\nAbruf: '+new Date(data.fetched_at||Date.now()).toLocaleString('de-DE')+(intent.car?'\nPreis und Verfügbarkeit bitte im jeweiligen Inserat prüfen.':''),model:data.engine||'AutoForge Web Scout'};
  if(intent.car&&Number.isFinite(intent.budget)&&intent.budget>0){const b=Math.floor(intent.budget);return {text:'Die Live-Suche hat gerade keine verlässlichen Inserate geliefert. Hier sind direkt anklickbare Suchseiten mit maximal '+b+' Euro, deutschlandweit und ohne feste Marke:\n\nMobile.de · bis '+b+' Euro\nhttps://suchen.mobile.de/fahrzeuge/search.html?vc=Car&isSearchRequest=true&p=%3A'+b+'\n\nKleinanzeigen · Autos bis '+b+' Euro\nhttps://www.kleinanzeigen.de/s-autos/preis:0:'+b+'/c216\n\nDas sind gefilterte Suchseiten; einzelne Fahrzeuge habe ich dabei noch nicht verifiziert.',model:'Websuche · gefilterte Suchseiten'};}
  return {text:'Die Live-Websuche liefert gerade keine verlässlichen Treffer. Du kannst diese Suche direkt öffnen:\nhttps://www.google.com/search?q='+encodeURIComponent(intent.query),model:'Websuche · derzeit keine Treffer'};
 },
 validateAttachments(items){if(!Array.isArray(items)||items.length>3)throw Error('Bitte höchstens drei Anhänge auswählen.');let text=0,images=0;return items.map(a=>{if(!a||typeof a.name!=='string')throw Error('Ungültiger Anhang.');const name=a.name.replace(/[\r\n]/g,' ').slice(0,100);if(typeof a.text==='string'){text+=a.text.length;if(text>12000)throw Error('Die Textdateien dürfen zusammen höchstens 12.000 Zeichen enthalten.');return {name,text:a.text,mime:'text/plain'};}if(/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(a.dataUrl||'')){images++;if(images>2||a.dataUrl.length>1000000)throw Error('Bitte höchstens zwei kleine Bilder auswählen.');return {name,mime:a.mime,dataUrl:a.dataUrl};}throw Error('Dieser Dateityp wird noch nicht unterstützt: '+name);});},
 content(message,items){return message+items.map(a=>a.text!==undefined?'\n\n--- Angefügte Datei: '+a.name+' ---\n'+a.text+'\n--- Ende der Datei ---':'\n[Angefügtes Bild: '+a.name+']').join('');},
 fileBlocks(text){const found=[];const re=/```([^\n`]*)\n([\s\S]*?)```/g;let m;while((m=re.exec(text))&&found.length<10){const lang=m[1].trim().toLowerCase();const ext=({javascript:'js',js:'js',typescript:'ts',ts:'ts',python:'py',py:'py',html:'html',css:'css',json:'json',markdown:'md',md:'md',xml:'xml',csv:'csv',text:'txt',txt:'txt'})[lang]||'txt';found.push({name:'AutoForge-Ergebnis'+(found.length?'-'+(found.length+1):'')+'.'+ext,text:m[2]});}return found;}
};
