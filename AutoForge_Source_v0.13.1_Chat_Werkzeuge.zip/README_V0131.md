# AutoForge Mobile 0.13.1 / Build 42

## Änderungen

- Oben im Chat stehen **Privat**, **Familienchat** und **Familie**. Familienzugehörigkeit wird beim Start geladen. Ohne Familie führt der Familienchat direkt zum Anlegen oder Beitreten.
- „Such mir ein Auto für 1000 Euro“ startet sofort die vorhandene Websuche, zunächst deutschlandweit und ohne bestimmte Marke. Treffer erscheinen mit anklickbaren URLs. Wenn die Live-Suche keine Treffer liefert, erscheinen ausdrücklich als Suchseiten gekennzeichnete Links zu Mobile.de und Kleinanzeigen mit maximal 1000 Euro. Keine erfundenen Inserate und keine behauptete Preisprüfung.
- **＋** neben dem Eingabefeld öffnet Androids Dateiauswahl. Bis zu drei Anhänge: Text-/Codedateien (zusammen 12.000 Zeichen) oder bis zu zwei JPG/PNG/WebP-Bilder. Bilder werden für Analyse verkleinert. Versand erfolgt erst mit Senden an die gewählte Cloud-KI. Bildanalyse benötigt AutoForge Cloud; Textdateien funktionieren auch mit eigenem kostenlosen OpenRouter-Zugang.
- Zur Dateiüberarbeitung: Datei wählen und zum Beispiel „Überarbeite diese Datei und gib den vollständigen Inhalt zurück“ schreiben. Codeblöcke der Antwort erhalten eine Schaltfläche zum Speichern einer Ergebnisdatei. Android 10 und neuer: Downloads/AutoForge. Android 8/9: Downloadbereich der App.
- Beim Wechsel Privat/Familie werden ungesendete Anhänge entfernt. Private Dateiinhalte werden nicht als Kontext an die Websuche geschickt.

## Grenzen und Prüfung

45 automatische Tests bestanden, einschließlich direkter Autosuche, fehlgeschlagener Suche ohne erfundene Angebote, vollständigen Textanhängen, Bildanalyse und getrennten Familienchats. Echter Backend-Test: Bildanalyse HTTP 200 erfolgreich. Live-Websuche HTTP 502 ohne Treffer; gefilterte Suchseiten sind daher derzeit die verlässliche Alternative. Isolierte Testidentität anschließend entfernt.

PDF/Word/Binärdateien, bearbeitete Bilddateien und lokale Anhänge sind noch nicht implementiert. Bilder können analysiert werden; eine neue bearbeitete Bilddatei wird hier noch nicht erzeugt. Textdateien werden als neue Ergebnisdatei gespeichert, die Originaldatei bleibt bestehen. Der Cloud-Verlauf enthält Bildnamen und Antworten, keine dauerhafte Speicherung der hochgeladenen Bilder. Familienchat-Mitglieder sehen die gesendeten Textdateiinhalte im gemeinsamen Chat. Gerätegebundene Identität: App nicht deinstallieren oder Daten löschen.

## APK bauen

Der neue Stand ist als **AutoForge_Source_v0.13.1_Chat_Werkzeuge.zip** vorbereitet. Die vorhandene APK 0.13.0 enthält diese Änderungen noch nicht.

1. ZIP unverändert im vorhandenen Repository hochladen: https://github.com/Kane101983/AutoForge-Mobile-app/upload/main
2. GitHub startet den bisherigen signierten APK-Bau. Nach Erfolg das Artefakt **AutoForge-Mobile-SIGNED-APK** herunterladen und entpacken.
3. Darin **app-release.apk** als Update installieren. Anzeige danach: **v0.13.1 · Build 42**.

Automatischer Upload ist derzeit durch einen Fehler beim Start der Browsersteuerung blockiert (`failed to write kernel assets / os error 3`), auch nach Zurücksetzen. Kein 0.13.1-Android-Bau oder Geräteprüfung bestätigt. Lokale Android-Bauumgebung und signierender GitHub-CLI-Zugang fehlen. Keine neue Signatur erzeugen; vorhandenen GitHub-Bau verwenden.

## Ergänzungen nach weiterer Prüfung
Private Dateien, die noch gelesen werden, werden beim Wechsel in einen Familienchat verworfen. Bei „Zeig mir die Links“ bleibt das Budget der vorherigen Nutzeranfrage erhalten. Die Anbieterantwort verändert dieses Budget nicht. Für längere Dateiaufträge ist der OpenRouter-Antwortraum erhöht.
Der aktuelle öffentliche Pollinations-Katalog enthält die alte Suchmodellkennung lixsearch nicht mehr. Andere Suchmodelle weisen Kosten aus; es wurde kein Wechsel zu einem kostenpflichtigen Modell vorgenommen. Direkte Portalfilter bleiben verfügbar.
Browsersteuerung weiterhin mit Kernel-Startfehler blockiert. Ein zusätzlicher Test bestätigt: kein vorhandener GitHub-Zugang im Git Credential Manager, keine GitHub-Tokens in der Umgebung. GitHub-Erweiterung zur Verbindung angeboten; noch keine Verbindung bestätigt. Neue APK daher weiterhin ausstehend.