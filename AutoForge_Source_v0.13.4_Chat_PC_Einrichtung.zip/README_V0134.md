# Mobile 0.13.4 / Build 45

Doppelten Chat-Eintrag entfernt; Antworten mit lesbarer Fettschrift, Listen und Code. Sicheres Text-Rendering ohne HTML-Ausführung. PC-Assistent im Menü, teilbarer Paketlink und bestehende Code-Kopplung. Erstinstallation muss einmal am PC geöffnet/bestätigt werden. Keine unvorbereitete Netzwerkinstallation oder beliebige PC-Erkennung behaupten. Details: APP_OPTIONEN.md.
