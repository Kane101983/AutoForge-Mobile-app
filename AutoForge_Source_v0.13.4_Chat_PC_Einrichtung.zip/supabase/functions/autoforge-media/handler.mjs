const allowed=['community/scriptsnsenses-sys/flux-2-dev-free','community/scriptsnsenses-sys/sdxl-lightning-free'];
export function freeModel(m,edit){
 if(!allowed.includes(m.name)||m.paid_only||!m.output_modalities?.includes('image')||!m.input_modalities?.includes(edit?'image':'text')||m.health?.status==='down')return false;
 if(m.pricing?.currency!=='pollen')return false;
 const prices=[m.pricing,...(m.pricing_variants||[]).map(v=>v.pricing),...(m.pricing_adjustments||[])];
 return prices.every(p=>p&&Object.entries(p).every(([k,v])=>['currency','name','kind','label','unit','quantity'].includes(k)||Number(v)===0));
}
export async function media(body,ctx){
 if(!await ctx.authenticate())return {status:401,error:'Zugang ungültig.'};
 const edit=body.mode==='edit'||body.kind==='edit';
 if(body.mode==='routes'){
  const catalog=await ctx.catalog();
  const routes=allowed.map(n=>catalog.find(m=>m.name===n)).filter(m=>m&&freeModel(m,edit)).map(m=>({model:m.name,name:m.title||m.name,description:m.name.includes('flux-2')?'Fotos bearbeiten und neue Bilder erstellen; geeignet für Hintergrundwechsel.':'Bilder schnell erstellen oder mit einem Referenzfoto bearbeiten.',privacy:'Eingaben werden laut Modellhinweis gespeichert; Ergebnislinks sind öffentlich abrufbar.'}));
  return {status:200,ok:true,routes,count:routes.length,quota_known:false};
 }
 if(body.consent!==true)return {status:400,error:'Bitte den Bildanbieter-Hinweis bestätigen.'};
 if(!['generate','edit'].includes(body.mode)||typeof body.prompt!=='string'||!body.prompt.trim()||body.prompt.length>6000)return {status:400,error:'Bildauftrag ungültig.'};
 if(edit&&(!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(body.image||'')||body.image.length>1000000))return {status:400,error:'Ein kleines Ausgangsfoto fehlt.'};
 const catalog=await ctx.catalog();
 const model=allowed.map(n=>catalog.find(m=>m.name===n)).find(m=>m&&(!body.model||m.name===body.model)&&freeModel(m,edit));
 if(!model)return {status:503,error:'Zurzeit ist kein geprüfter kostenloser Bildanbieter verfügbar. Es wird kein kostenpflichtiges Modell verwendet.'};
 const r=await ctx.generate(model.name,body);
 let url;try{url=new URL(r?.url);}catch{}
 if(!url||url.protocol!=='https:'||!['gen.pollinations.ai','media.pollinations.ai'].includes(url.hostname))return {status:502,error:'Der Bildanbieter hat kein darstellbares Bild geliefert. Bitte später erneut versuchen.'};
 return {status:200,ok:true,url:url.href,model:model.name,provider:'Pollinations · kostenloses Community-Modell'};
}
