# AutoForge Mobile 0.13.2 / Build 43

Die APK als Update installieren; vorher nicht deinstallieren oder App-Daten löschen. Nur die APK weitergeben, keine persönliche Sicherung.

Neu: Menü als Liste, sichtbarer Zurück-zum-Chat-Knopf, Recherche und Offline-Übung getrennt, Protokolle ohne eigene kleine Scrollfenster.

Bildauftrag: Cloud-Chat wählen, Foto über ＋ anhängen und z.B. „Ersetze den Hintergrund durch einen Strand mit Meer“ senden. Nach dem Anbieter-Hinweis wird eine echte kostenlose Bildbearbeitung angefordert. Das Bild erscheint im Chat mit Speichern-Knopf. Ohne Foto sind Bildgenerierungen möglich. Fotos werden verkleinert; bei mehreren Bildern bearbeitet der Auftrag das erste.

Der Bildanbieter ist ein kostenloses Communitymodell über Pollinations. Der Modellhinweis nennt Speicherung von Eingaben und Ergebnissen. Ergebnislinks sind beim Anbieter öffentlich abrufbar. Vor jedem Auftrag erscheint dazu ein Hinweis. Die App wechselt nicht zu kostenpflichtigen Bildmodellen. Anbieterlimits und Ausfälle bleiben möglich.

Familie: Familie öffnen, als Besitzer anlegen und Einladung teilen. Freunde benötigen für private Chats keine Einladung und keinen PC. Einladungen sind nur für gemeinsame Familienchats. Private Chats und PC-Zugriff bleiben getrennt.

Vollständige Funktionsbewertung: outputs/AutoForge-App-Optionen.md. Zwei echte Testzugänge bestätigten Datenisolation; echter Bildbearbeitungs-Test lieferte ein sichtbares Ergebnis. Bedienprüfung mit simulierter Android-Brücke, noch kein Test auf deinem Handy.
