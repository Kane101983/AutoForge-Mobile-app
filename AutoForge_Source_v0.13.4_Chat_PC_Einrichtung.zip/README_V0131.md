# AutoForge Mobile 0.13.1 / Build 42

## Änderungen

- Oben im Chat stehen **Privat**, **Familienchat** und **Familie**. Familienzugehörigkeit wird beim Start geladen. Ohne Familie führt der Familienchat direkt zum Anlegen oder Beitreten.
- „Such mir ein Auto für 1000 Euro“ startet sofort die vorhandene Websuche, zunächst deutschlandweit und ohne bestimmte Marke. Treffer erscheinen mit anklickbaren URLs. Wenn die Live-Suche keine Treffer liefert, erscheinen ausdrücklich als Suchseiten gekennzeichnete Links zu Mobile.de und Kleinanzeigen mit maximal 1000 Euro. Keine erfundenen Inserate und keine behauptete Preisprüfung.
- **＋** neben dem Eingabefeld öffnet Androids Dateiauswahl. Bis zu drei Anhänge: Text-/Codedateien (zusammen 12.000 Zeichen) oder bis zu zwei JPG/PNG/WebP-Bilder. Bilder werden für Analyse verkleinert. Versand erfolgt erst mit Senden an die gewählte Cloud-KI. Bildanalyse benötigt AutoForge Cloud; Textdateien funktionieren auch mit eigenem kostenlosen OpenRouter-Zugang.
- Zur Dateiüberarbeitung: Datei wählen und zum Beispiel „Überarbeite diese Datei und gib den vollständigen Inhalt zurück“ schreiben. Codeblöcke der Antwort erhalten eine Schaltfläche zum Speichern einer Ergebnisdatei. Android 10 und neuer: Downloads/AutoForge. Android 8/9: Downloadbereich der App.
- Beim Wechsel Privat/Familie werden ungesendete Anhänge entfernt. Private Dateiinhalte werden nicht als Kontext an die Websuche geschickt.

## Grenzen und Prüfung

45 automatische Tests bestanden, einschließlich direkter Autosuche, fehlgeschlagener Suche ohne erfundene Angebote, vollständigen Textanhängen, Bildanalyse und getrennten Familienchats. Echter Backend-Test: Bildanalyse HTTP 200 erfolgreich. Live-Websuche HTTP 502 ohne Treffer; gefilterte Suchseiten sind daher derzeit die verlässliche Alternative. Isolierte Testidentität anschließend entfernt.

PDF/Word/Binärdateien, bearbeitete Bilddateien und lokale Anhänge sind noch nicht implementiert. Bilder können analysiert werden; eine neue bearbeitete Bilddatei wird hier noch nicht erzeugt. Textdateien werden als neue Ergebnisdatei gespeichert, die Originaldatei bleibt bestehen. Der Cloud-Verlauf enthält Bildnamen und Antworten, keine dauerhafte Speicherung der hochgeladenen Bilder. Familienchat-Mitglieder sehen die gesendeten Textdateiinhalte im gemeinsamen Chat. Gerätegebundene Identität: App nicht deinstallieren oder Daten löschen.

## Installation

Die signierte APK ist fertig: **AutoForge-Mobile-0.13.1.apk** im outputs-Ordner. Auf das Handy übertragen und als Update installieren. Vorher nicht deinstallieren oder App-Daten löschen. Anzeige danach: **v0.13.1 · Build 42**. Dieselbe APK kann an Familienmitglieder gegeben werden.

1. Oben **Familie** öffnen und als Besitzer eine Familie anlegen.
2. Einladung erstellen und den Code über den Teilen-Dialog weitergeben.
3. Familienmitglied installiert die APK und tritt unter **Familie** mit dem Code bei.
4. **Privat** öffnet eigene Gespräche; **Familienchat** gemeinsame Gespräche. PC-Steuerung bleibt beim Administrator.

Für Anhänge im Cloud-Chat **＋** neben dem Eingabefeld antippen. Zum Beispiel: „Überarbeite diese Textdatei und gib sie vollständig zurück“. Ergebnisdateien über den Speichern-Knopf der Antwort herunterladen.

[Bau auf GitHub](https://github.com/Kane101983/AutoForge-Mobile-app/actions/runs/37488947306) erfolgreich; 45 Tests bestanden und APK-Prüfsumme sowie enthaltene App-Dateien geprüft. Auf echten Handys noch nicht geprüft.

SHA256: 44a4debc47e482892f4e75fdb26799024fa44d0a1ba4fefd56cfe53859f578f5
