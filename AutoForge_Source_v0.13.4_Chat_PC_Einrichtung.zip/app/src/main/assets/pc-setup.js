function networkHint(){const n=$('pcNetwork').value;$('pcNetworkHint').textContent=n==='same'?'Teile den Paketlink zum Beispiel über die Android-Freigabe an deinen PC. Die spätere Kopplung läuft über AutoForge Cloud; dafür muss der PC nicht im selben WLAN bleiben.':n==='remote'?'Schicke den Paketlink an deinen PC und öffne ihn dort. Die Verbindung funktioniert anschließend über das Internet.':'Du kannst den Paketlink trotzdem am PC öffnen. Für die Kopplung brauchen beide Geräte eine Internetverbindung.';}
$('setupPc').onclick=()=>{$('pcWizard').hidden=false;networkHint();};
$('pcNetwork').onchange=networkHint;
$('pcInstalled').onclick=()=>{$('pcInstallSteps').hidden=true;$('pcCodeStep').hidden=false;};
$('pcNew').onclick=()=>{$('pcInstallSteps').hidden=false;$('pcCodeStep').hidden=false;};
$('pcShare').onclick=()=>{const text='AutoForge auf meinem Windows-PC einrichten: '+$('pcPackage').href;if(window.AndroidBridge?.shareText)AndroidBridge.shareText(text);else notice('Paketlink kopieren: '+$('pcPackage').href);};
$('pcShowMine').onclick=()=>action(async()=>{await loadDevices();notice(device?'Dein PC ist in der Liste ausgewählt.':'Noch kein PC gekoppelt. Bitte zuerst den Verbindungscode vom PC eingeben.');});
