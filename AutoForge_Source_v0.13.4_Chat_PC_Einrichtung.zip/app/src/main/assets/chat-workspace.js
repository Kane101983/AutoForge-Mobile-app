function workspaceTitle(){ $('areaTitle').textContent=cloud.groupId?'Familienchat':engine==='local'?'Chat auf deinem PC':'Privater Chat'; }
const privateAction=$('privateChatButton').onclick,familyActionClick=$('familyChatButton').onclick;
$('privateChatButton').onclick=async()=>{await privateAction();openPage('chat');workspaceTitle();};
$('familyChatButton').onclick=async()=>{await familyActionClick();if(cloud.groupId)openPage('chat');workspaceTitle();};
$('providerButton').onclick=()=>{};
const conversationAction=$('conversationsButton').onclick;
$('conversationsButton').onclick=()=>{const r=conversationAction();$('settings').open=true;return r;};
const freshAction=$('newChat').onclick;
$('newChat').onclick=()=>{freshAction();$('taskDetails').hidden=true;openPage('chat');workspaceTitle();};
window.addEventListener('af-task-progress',e=>{
 const d=e.detail;$('taskDetails').hidden=false;$('taskSummary').textContent=d.state==='running'?'Bild-KI '+d.attempt+'/'+d.total+': '+d.active.name+' · noch '+d.remaining+' unversucht':d.state==='done'?'Bild fertig · '+d.active.name:'Keine kostenlose Bild-KI hat geliefert';
 $('taskTrace').replaceChildren();if(d.active)$('taskTrace').append(element('p',d.active.description));for(const a of d.attempts||[])$('taskTrace').append(element('p','Wechsel nach '+a.name+': '+a.error));$('taskTrace').append(element('p','Gezählt werden geprüfte Modellrouten, keine eigenständigen Agenten. Ob deren Kontingent frei ist, zeigt sich erst beim Aufruf.'));
});
workspaceTitle();

for(const id of ['engineSelect','chatScope','chatSelect']){const old=$(id).onchange;$(id).onchange=async e=>{await old?.(e);$('taskDetails').hidden=true;workspaceTitle();if(id==='chatSelect')openPage('chat');};}
