window.AutoForgeMedia={
 progress:null,
 async routes(bridge,kind){const r=await bridge('cloudMediaRequest',JSON.stringify({mode:'routes',kind}));if(!r?.ok||!Array.isArray(r.routes))throw Error(r?.error||'Bild-Katalog nicht erreichbar.');return r.routes.slice(0,5);},
 emit(d){this.progress=d;if(typeof CustomEvent!=='undefined')window.dispatchEvent?.(new CustomEvent('af-task-progress',{detail:d}));},
 async run(bridge,mode,prompt,image){
  const routes=await this.routes(bridge,mode),attempts=[];
  if(!routes.length)throw Error('Zurzeit keine geprüfte kostenlose Bild-KI verfügbar. Kein Wechsel auf kostenpflichtige Modelle.');
  for(let i=0;i<routes.length;i++){
   const route=routes[i];this.emit({active:route,attempt:i+1,total:routes.length,remaining:routes.length-i-1,attempts:[...attempts],state:'running'});
   try{
    const r=await bridge('cloudMediaRequest',JSON.stringify({mode,prompt,image,consent:true,model:route.model}));
    if(!r?.ok||!AutoForgeChatTools.mediaUrl(r.url))throw Error(r?.error||'Kein gültiges Bild erhalten.');
    const text=(mode==='edit'?'Dein bearbeitetes Bild:':'Dein erzeugtes Bild:')+'\n\n![AutoForge-Bild]('+r.url+')\n\nBild-KI: '+route.name+'\n'+route.description+(attempts.length?'\nAutomatisch gewechselt: '+attempts.map(a=>a.name).join(' → ')+' → '+route.name:'')+'\nWeitere unversuchte kostenlose Kandidaten: '+(routes.length-i-1)+' (Kontingent nicht im Voraus bekannt).';
    this.emit({active:route,attempt:i+1,total:routes.length,remaining:routes.length-i-1,attempts,state:'done'});return {ok:true,text,model:r.model};
   }catch(e){attempts.push({name:route.name,error:String(e.message||e).slice(0,250)});}
  }
  this.emit({attempts,total:routes.length,remaining:0,state:'failed'});
  throw Error('Alle '+routes.length+' geprüften kostenlosen Bild-KIs haben den Auftrag abgelehnt oder sind nicht erreichbar. '+attempts.map(a=>a.name+': '+a.error).join(' · '));
 }
};
