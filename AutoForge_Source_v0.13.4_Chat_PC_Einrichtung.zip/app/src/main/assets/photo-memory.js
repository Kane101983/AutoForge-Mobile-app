/* Private to this installation; never read across conversation or family scopes. */
window.AutoForgePhotos={
 async db(){return new Promise((resolve,reject)=>{const r=indexedDB.open('af-photo-context',1);r.onupgradeneeded=()=>r.result.createObjectStore('photos',{keyPath:'key'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(Error('Foto-Kontext nicht verfügbar'));});},
 key(group,chat){return (group||'private')+':'+chat;},
 async get(group,chat){if(!chat)return null;let db;try{db=await this.db();return await new Promise(resolve=>{const r=db.transaction('photos').objectStore('photos').get(this.key(group,chat));r.onsuccess=()=>resolve(r.result&&Date.now()-r.result.time<86400000?r.result.photo:null);r.onerror=()=>resolve(null);});}catch{return null;}finally{db?.close();}},
 async put(group,chat,photo){if(!chat||!photo?.dataUrl)return;let db;try{db=await this.db();await new Promise((resolve,reject)=>{const tx=db.transaction('photos','readwrite'),s=tx.objectStore('photos');s.put({key:this.key(group,chat),time:Date.now(),photo});const req=s.getAll();req.onsuccess=()=>{for(const r of req.result.sort((a,b)=>b.time-a.time).slice(10))s.delete(r.key);};tx.oncomplete=resolve;tx.onerror=reject;});}catch{}finally{db?.close();}},
 async remove(group,chat){let db;try{db=await this.db();await new Promise(resolve=>{const tx=db.transaction('photos','readwrite');tx.objectStore('photos').delete(this.key(group,chat));tx.oncomplete=resolve;tx.onerror=resolve;});}catch{}finally{db?.close();}}
};
