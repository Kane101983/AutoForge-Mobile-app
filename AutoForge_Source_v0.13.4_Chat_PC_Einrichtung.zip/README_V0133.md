# AutoForge Mobile 0.13.3 / Build 44

Chat im Mittelpunkt, alle Bereiche im Menü rechts oben. Größere Nachrichtenfläche; tatsächlich verwendetes Modell an der Antwort.

Direkte höfliche Fotoaufträge, chatbezogener Fotokontext für bis zu 24 Stunden, aktueller Gratis-Katalog und sichtbarer Wechsel nach Fehlern. Kein kostenpflichtiger Ersatz, keine Zusicherung eines freien Dienstkontingents. Ausdrücklicher Anbieter-Hinweis vor Fotos.

Präsentationen und Excel-Tabellen werden im Cloud-Chat als echte einfache PPTX/XLSX-Dateien mit Vorschau und Download erstellt. Noch kein Office-Import, Formeln, Musik- oder Videodienst. Details: APP_OPTIONEN.md.

Server: autoforge-media Version 2. Zugriff mit geprüftem JWT; Preise und erlaubte Modelle werden pro Auftrag geprüft. 56 automatische Tests, Browserbedienung mit simulierter Android-Brücke und tatsächliche Cloud-Bild-/Präsentationsaufrufe geprüft. Installieren als Update, App-Daten behalten.
