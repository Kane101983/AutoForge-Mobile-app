# AutoForge Mobile 0.15.8 / Build 61

Unter Meine Geräte → Mein PC → Lernen kannst du den verbundenen PC lernen lassen, Automatik einschalten und Lernen samt Automatik stoppen. Die vorhandene PC-Zuordnung und Auftragsnummern bleiben maßgeblich. Ein Auftrag wird erst nach bestätigter PC-Rückmeldung als erledigt angezeigt. Neue Optionen benötigen PC 0.6.20 und KI 0.3.6.

Dateispeicher und Arbeitsspeicher werden getrennt angezeigt. Modelle/Trainingsdaten/Trainingscache liegen auf G. RAM wird zum Rechnen verwendet und ist kein freier Platz auf C. Die App kann auf Wunsch im Chat zur lokalen PC-KI wechseln. Eine vorhandene Auswahl kostenloser Cloud-KI bleibt bis zu deinem Wechsel erhalten.

Automatik ist zunächst aus. Wenn du sie einschaltest, verarbeitet der PC nach mindestens zwei Minuten ohne neue Chatfrage acht oder mehr unterschiedliche von dir bestätigte Korrekturen, jedes unveränderte Paket einmal. Keine normalen privaten Chats oder ungeprüften Internettexte als automatischer Trainingssatz. Ohne neue Beispiele wartet er. Fehler halten die Automatik an. Chatfragen haben Vorrang; ein unterbrochener automatischer Lauf beginnt später neu. Stoppen schaltet die Automatik ebenfalls aus.

Unter Details kannst du deine letzte eigene lokale PC-Antwort korrigieren. Diese Korrektur wird ausdrücklich bestätigt gespeichert. Das Gewichtstraining betrifft weiterhin ein getrenntes 0,5B-Modell; normale PC-Chats verwenden das bisherige 7B-Modell. Unabhängige breitere Qualitätstests bleiben nötig. Kein neuer Cloud-Dienst, kein Tarifwechsel und keine Freigabe für Familienmitglieder zur PC-Steuerung.

Die APK ersetzt die bisherige App mit demselben Signierschlüssel. Oberflächen- und automatische Prüfungen verwenden simulierte PC-Aufträge; ein Test auf dem echten Handy steht aus.
