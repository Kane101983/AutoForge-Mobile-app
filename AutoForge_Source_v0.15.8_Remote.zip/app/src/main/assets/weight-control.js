/* Owner PC jobs retain the existing authenticated device and job-id mechanism. */
(()=>{
 const page=$('pcLearning');if(!page)return;
 const n=(tag,text='')=>element(tag,text),b=(text,fn)=>{const x=n('button',text);x.type='button';x.onclick=fn;return x;};
 const info=n('p','Wähle deinen PC unter Meine Geräte. Lernen läuft auf deinem Rechner; die großen Dateien liegen auf G.'),status=n('p','Status noch nicht geprüft.'),space=n('p','Speicherorte werden vom PC gemeldet.'),autoStatus=n('p','Automatik noch nicht geprüft.');
 status.id='weightStatus';status.setAttribute('role','status');space.id='weightSpace';
 const profile=n('select');profile.id='weightProfile';for(const [value,title] of [['25','Wenig'],['50','Mittel'],['75','Max'],['100','Turbo']])profile.append(new Option(title,value));profile.value='50';
 const time=n('input');time.id='weightMinutes';time.type='number';time.min='1';time.max='120';time.value='30';
 const label=n('label','Leistung erlauben');label.append(profile);const duration=n('label','Spätestens stoppen nach Minuten');duration.append(time);
 let localBusy=false;
 async function run(operation,extra={}){
  if(localBusy||busy){notice('Bitte den laufenden Auftrag zuerst abwarten.');return;}
  if(pending){notice('Ein PC-Auftrag ist noch offen. Bitte im Chat Auftrag prüfen verwenden.');return;}
  localBusy=true;status.textContent='Auftrag wird an deinen PC übertragen …';
  let received=false;try{await action(async()=>{await loadDevices();if(!device||!pcOnline)throw Error('Dein PC ist nicht erreichbar. Bitte einschalten und AutoForge laufen lassen.');const d=await job(operation,extra);render(d);received=true;});}
  finally{localBusy=false;if(!received)status.textContent=$('sendStatus').textContent||'Auftrag nicht abgeschlossen.';}
 }
 function settings(){const minutes=Number(time.value);if(!Number.isInteger(minutes)||minutes<1||minutes>120)throw Error('Bitte 1–120 Minuten wählen.');const cpu=Number(profile.value);return {cpuPercent:cpu,ramMb:cpu===25?4096:8192,diskMb:4096,steps:12,minutes,threads:cpu===25?1:cpu===50?2:4,allowDownload:false};}
 const start=b('Jetzt auf dem PC lernen',()=>{try{return run('weight-start',{training:settings()});}catch(e){notice(e.message);}});start.id='weightStart';
 const stop=b('Lernen und Automatik stoppen',()=>run('weight-stop'));stop.id='weightStop';
 const auto=n('input');auto.id='weightAutomatic';auto.type='checkbox';auto.onclick=()=>{const enabled=auto.checked;auto.checked=!enabled;try{return run('weight-auto',{automatic:{enabled,...(enabled?{settings:settings()}: {})}});}catch(e){notice(e.message);}};
 const autoLabel=n('label','Automatisch im Leerlauf lernen');autoLabel.prepend(auto);
 const refresh=b('Status vom PC abrufen',()=>run('weight-status'));refresh.id='weightRefresh';
 const usePc=b('Im Chat mit meinem PC antworten',()=>{$('engineSelect').value='local';return Promise.resolve($('engineSelect').onchange()).then(()=>AutoForgeNavigation.go('chat'));});usePc.id='weightUsePc';
 const details=n('details'),summary=n('summary','Details und bestätigte Lernbeispiele');details.append(summary,n('p','Der erste Trainingsmodus verwendet ein getrenntes 0,5B-Modell. Normale PC-Chats verwenden weiterhin das bisherige 7B-Modell. Automatik verarbeitet mindestens acht unterschiedliche bestätigte Korrekturen, keine normalen privaten Chats oder ungeprüften Internettexte. Bei Unterbrechung beginnt später ein neuer Lauf.'));
 const correction=n('textarea');correction.id='weightCorrection';correction.maxLength=600;correction.rows=4;correction.placeholder='Die richtige kurze Antwort auf meine letzte lokale Chatfrage …';
 const teach=b('Letzte PC-Antwort damit korrigieren',()=>{
  if(!correction.value.trim())return notice('Bitte zuerst die richtige Antwort eingeben.');
  if(localBusy||busy||pending)return notice('Bitte den laufenden PC-Auftrag zuerst abwarten.');
  if(engine!=='local'||!chat||cloud.groupId)return notice('Bitte zuerst einen eigenen lokalen PC-Chat öffnen.');
  return action(async()=>{const h=await job('history',{chatId:chat});const last=(h.messages||[]).filter(m=>m.role==='assistant').at(-1);if(!last?.id)throw Error('Keine lokale Antwort zum Korrigieren gefunden.');await job('teach',{messageId:last.id,answer:correction.value.trim()});correction.value='';notice('Deine Korrektur wurde als bestätigtes Lernbeispiel gespeichert.');});
 });details.append(correction,teach);
 const log=n('pre');log.id='weightLog';details.append(log);
 page.append(info,space,label,duration,start,stop,autoLabel,autoStatus,status,refresh,usePc,details);
 function render(d){
  if(d.automatic){auto.checked=d.automatic.enabled===true;autoStatus.textContent=d.automatic.message||'';}
  const sys=d.system;if(sys){space.textContent='Dateien: '+sys.storageRoot+' · '+(sys.diskFreeMb==null?'Speicherplatz unbekannt':(sys.diskFreeMb/1024).toFixed(1)+' GB auf dem Laufwerk frei')+'\nArbeitsspeicher (RAM): '+(sys.ramFreeMb/1024).toFixed(1)+' GB frei. RAM ist kein Speicherplatz auf C.';}
  const r=d.training;if(!r){status.textContent='Noch kein Lernlauf. Starten oder Automatik einschalten.';return;}
  const names={running:'Läuft',completed:'Abgeschlossen',failed:'Fehlgeschlagen',stopped:'Gestoppt',interrupted:'Unterbrochen',deadline:'Endzeit erreicht'};
  status.textContent=(names[r.status]||r.status)+' · '+r.completed+'/'+r.total+' Schritte · '+r.message;
  log.textContent=(r.events||[]).map(e=>new Date(e.time).toLocaleTimeString()+' '+e.message).join('\n');
 }
 setInterval(()=>{if(!document.hidden&&document.body.dataset.page==='pcLearning'&&!busy&&!pending&&!localBusy)run('weight-status');},15000);
 window.AutoForgeWeights={render};
})();
