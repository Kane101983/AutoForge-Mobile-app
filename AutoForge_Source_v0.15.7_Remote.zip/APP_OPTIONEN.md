# AutoForge Mobile: Welche Funktionen brauchst du?

Stand: 0.13.4 / Build 45, 06.10.2026.

## Alltag

| Option | Was bringt sie? | Empfehlung |
|---|---|---|
| Chat / Senden | Fragen beantworten, recherchieren, Texte und Code bearbeiten; passende Bildaufträge ausführen. | Hauptansicht. |
| Menü → KI auswählen | Zwischen vorhandener Cloud und deiner lokalen PC-KI wechseln; Anbieter und Modell sehen. | Behalten. Cloud funktioniert ohne deinen PC. |
| Privat | Eigene Cloud-Gespräche, getrennt von anderen Zugängen. | Behalten. |
| Familienchat | Ausdrücklich gemeinsame Gespräche der eingeladenen Mitglieder. | Behalten; private Chats werden nicht hineinkopiert. |
| Familie | Einladung erstellen/annehmen, Mitglieder sehen/entfernen, Codes widerrufen. | Behalten, aber Verwaltung im Menü. Kein PC-Zugriff durch Einladung. |
| Chats / Neuer Chat | Gespräche auswählen, nach Datum sortieren, Titel lesen, löschen. | Im Menü; Liste bleibt geschlossen, bis du sie öffnest. |
| ＋ Anhänge | Text-/Codedateien für Überarbeitung, Bilder für Analyse oder Bearbeitung auswählen. | Behalten. PDF/Word noch nicht unterstützt. |
| Bild speichern / Ergebnisdatei speichern | Ergebnis auf dem Handy als Datei behalten. | Behalten. Eine Bildantwort ist jetzt ein sichtbares Bild. |
| Offene Antwort erneut abrufen | Einen unterbrochenen Auftrag fortsetzen, ohne seine Nachricht doppelt zu speichern. | Nur anzeigen, wenn ein Auftrag offen ist. |
| Zur neuesten Antwort | Nach manuellem Scrollen zurück zum aktuellen Ende. | Nur bei Bedarf anzeigen. |

## Werkzeuge auf deinem PC

| Option | Tatsächlicher Nutzen / Grenze | Empfehlung |
|---|---|---|
| Programme erstellen | Kleine Webprogramme auf deinem gekoppelten PC unter G erstellen und überarbeiten. Vorschau am Windows-PC. Kein beliebiger PC-Autopilot. | Eigenen Menüeintrag behalten. Ohne PC verständlichen Hinweis zeigen. |
| Zweite lokale KI prüft | Zusätzliche Einschätzung zu einem Programmentwurf; benötigt ein passendes lokales Modell. | Option lassen, standardmäßig aus. Keine Garantie, dass der Entwurf fehlerfrei ist. |
| Thema recherchieren | Wikipedia-Quellen sammeln, mit Herkunft automatisch im lokalen Gedächtnis speichern; dadurch bei passenden späteren Fragen nutzbar. | Behalten, aber ausdrücklich Recherche nennen. Kein Training der Modellgewichte. |
| Offline üben | Prüft einen kleinen festen Aufgabenbereich vor/nach einer vorgeschlagenen Arbeitsanweisung. | Als optionalen Prüfbereich behalten. Für normalen Chat nicht nötig. |
| „Verbessere dich selbst“ | Bisher nur Einstieg zu Recherche und Offline-Übung; kein allgemeines Selbsttraining. | Irreführenden zusätzlichen Knopf aus dem sichtbaren Menü entfernt. |
| CPU/RAM/Dateibudget/Endzeit/Quellen | Grenzen für den Rechercheprozess; CPU-Threads für den Übungsserver sind kein Prozentlimit. | Unter „Grenzen anpassen“ bündeln. Bestehende Modelle zählen nicht zum Dateibudget. |
| Speicher auf G / Arbeitsweg | Zeigt Platzbedarf von Quellen, Chats, Projekten und Modellen. | Einklappbar, nicht ständig im Weg. |
| Protokoll / geprüfte Antworten | Zeigt echte Tätigkeiten, Resultate, Fehler und Fortschritt. Prozent bedeutet bearbeitete Schritte, keine Intelligenzsteigerung. | Einklappbar, im normalen Seiten-Scrollbereich. |
| Live-Status | Regelmäßig den aktuellen PC-Auftrag abfragen. | Optional; nicht für Chat notwendig. |
| Eine Idee merken | Eigene Information für das lokale Gedächtnis auf G speichern. | Unter PC-Verwaltung lassen. Cloud-/Familienchats übernehmen diese Notiz nicht automatisch. |
| PC koppeln / auswählen / aktualisieren | Eigenen PC ausdrücklich verbinden und offene Aufträge abholen. | Unter PC-Verwaltung bündeln. Eine frische Freundesinstallation hat keinen gekoppelten PC. |

## Bisherige Oberfläche / erweiterte Funktionen

Diese bleiben für vorhandene Gespräche erreichbar, gehören aber nicht auf den neuen Startbildschirm. Zwei parallele Oberflächen sind langfristig unnötig; die alte Oberfläche erst nach vollständiger Übernahme ihrer Verläufe ablösen.

| Option | Nutzen / Problem | Empfehlung |
|---|---|---|
| KI-Scout / Modellkatalog | Findet Katalogeinträge. Ein gefundenes Modell ist nicht automatisch installiert oder ausführbar. | Nur erweiterte Einstellungen. |
| Automatischer Scout | Aktualisiert Modellkataloge im Hintergrund; Android bestimmt den Zeitpunkt mit. | Für Alltagsnutzer verzichtbar, ausgeschaltet lassen. |
| Spezialisten / Universal Router | Unterschiedliche Aufgaben und Anbieter zuordnen. Nicht jeder aufgelistete Adapter ist tatsächlich ausführbar. | Die App soll intern passend routen; keinen zusätzlichen Bedienbereich im Hauptchat. |
| Fortsetzungs-Engine / Checkpoints | Speichert bestimmte Aufträge/Zwischenstände. Kann keinen internen Rechenzustand einer fremden KI retten. | Technische Hintergrundfunktion; kein eigener Hauptmenüpunkt nötig. |
| Lokale Handy-KI | Kleines, separat herunterladbares Offline-Textmodell, ungefähr 550 MB. Schwächer als große Cloudmodelle, keine Fotobearbeitung. | Optional, nur für bewusst gewünschten Offlinebetrieb. |
| Eigener OpenRouter-Schlüssel | Optionaler Textanbieter mit einem kostenlosen Modell; Limits beim Anbieter bleiben möglich. | Unter erweiterten Einstellungen, nicht bei erster Nutzung verlangen. |
| Eigener Pollinations-Schlüssel / Modellfelder | Technischer Entwicklerzugang. Preis-/Gratis-Angaben alter Modelle können überholt sein. | Nicht für Freunde nötig. Nicht zum automatischen Bildweg des neuen Chats verwenden. |
| Direkte PC-Adresse / Token | Alter lokaler Netzwerkzugang. | Nur für bestehende Entwicklungsfälle. Nicht erforderlich für normalen Cloud-Chat. |
| Remote Builder / PC-Auftrag / PC-Werkzeuge | Verwaltung des ausdrücklich gekoppelten PCs. | Erweiterter Besitzerbereich. Familienmitgliedschaft gibt dafür keine Rechte. |
| Standby / Neustart / Herunterfahren | Besitzeraktionen mit Bestätigung. | Nur Besitzerbereich. |
| Lokal aufwecken / WoWLAN | Auf deinem PC bisher nicht zuverlässig funktionsfähig. | Kein Alltagsversprechen; weiterhin zurückgestellt. |
| Konsole / Projekt-ZIP / Sicherungen | Ergebnisse exportieren und Probleme nachvollziehen. | Nur bei laufender Arbeit oder in erweiterten Einstellungen. Eine persönliche Sicherung niemals statt der APK an Freunde geben. |

## Weitergabe und Bildanbieter

Die signierte APK enthält Programmdateien und einen öffentlichen Supabase-Schlüssel, keine persönlichen Chats, Fotos, Besitzer-Sitzungen oder eigenen API-Schlüssel. Der öffentliche Schlüssel ist kein Zugang zu privaten Daten: Datenbankregeln und geprüfte Nutzeridentitäten begrenzen den Zugriff. Neue Installationen erhalten einen eigenen Zugang. Private Daten werden nicht mitinstalliert; Familie und PC-Verbindung entstehen erst ausdrücklich. Die Erzeugung vieler neuer Konten und Cloudmodelle ist dennoch durch Anbieterlimits begrenzt; das ist noch kein zugesicherter öffentlicher Dienst.

Cloud-Inhalte gehen an den ausgewählten KI-Anbieter. Der neue Bildweg prüft vor jedem Auftrag zwei bekannte, aktuell kostenfrei gelistete Communitymodelle. Bei Preisen, fehlender Verfügbarkeit oder Fehlern wird kein kostenpflichtiger Ersatz verwendet. Der Modellhinweis nennt Speicherung von Eingaben/Ergebnissen; die App zeigt dies vor jedem Bildauftrag. Ergebnislinks beim Bildanbieter sind öffentlich abrufbar. Für vertrauliche Fotos ist dieser Weg deshalb ungeeignet. Die Bildlinks bleiben als Antwort im eigenen bzw. ausdrücklich gemeinsamen Chat. Fotos werden für die Verarbeitung verkleinert; Originalauflösung wird nicht zugesichert. Mehrere angehängte Bilder: Bearbeitung verwendet das erste Bild, Analyse kann zwei verwenden.

Quellen: [Pollinations-Modelle](https://gen.pollinations.ai/image/models), [offizielle API-Dokumentation](https://github.com/pollinations/pollinations/blob/main/gen.pollinations.ai/src/docs/apidocs-recipes.md).

## Durchgeführte Prüfungen

- Zwei echte frische Testzugänge: fremder privater Chat verweigert; neuer Zugang hat keine Chats, PCs oder Familien und darf keine Familie verwalten. Testzugänge abgemeldet und anschließend entfernt.
- Echter Bildauftrag mit synthetischem Testbild: grauen Hintergrund in Strand/Meer geändert, roter Kreis erhalten, HTTP 200 und tatsächlich abrufbares Bild. Keine persönlichen Fotos für diesen Test verwendet.
- App-Oberfläche in Browserprüfung mit 320×568, 393×430 und 800×1000 Pixeln: Menü, Zurück zum Chat, Recherche/Übung getrennt, keine inneren Log-Scrollfenster, Senden und sichtbare Bildantwort. Android-Brücke in dieser Bedienprüfung simuliert. Kein Zugriff auf dein echtes Handy und kein Emulator-Test.
- Automatische Prüfungen decken auch getrennte Chatverläufe, private Anhänge beim Bereichswechsel und Ablehnung kostenpflichtiger Bildrouten ab.

## Änderungen in 0.13.3

Alle Bereichswechsel, private/familiäre Gespräche, Chatliste und Einstellungen stehen im Menü oben rechts. Im Chat verbleiben Nachrichten, Eingabe, Anhänge und nur bei Bedarf ein Auftragsstatus. Die frühere große „Antworten: AutoForge Cloud“-Zeile ist ins Menü verschoben. Das tatsächlich verwendete Modell steht an der Antwort.

Fotoaufträge wie „Kannst du in diesem Bild einen Strand als Hintergrund machen?“ starten die Bildbearbeitung direkt nach dem Anbieter-Hinweis. Das letzte hochgeladene Ausgangsfoto bleibt auf diesem Gerät im selben Chat für Folgeaufträge verfügbar: bis 24 Stunden, höchstens zehn Chat-Fotokontexte, höchstens 1 MB pro Foto. Private Chats und Familienbereiche verwenden getrennte Schlüssel. Chat löschen entfernt seinen Fotokontext. Fotos aus älteren App-Versionen bitte erneut anhängen. Der Kontext wird nicht als Originalfoto an andere Familienmitglieder verteilt.

Bei Fehlern versucht die App nacheinander die aktuell geprüften kostenlosen Bildmodelle. Sie zeigt Modellname, Fähigkeit, Wechselgrund und unversuchte Kandidaten. Das sind Modellrouten beim selben Dienst, keine unabhängigen KI-Agenten. Gemeinsame Dienstlimits können deshalb beide betreffen; deren Restkontingent ist nicht vorab bekannt. Aktueller Katalogtest: zwei kostenlose Bildmodelle, kein kostenloses Audio-/Videomodell im angeschlossenen Katalog. Kein kostenpflichtiger Ersatz.

Präsentation oder Excel-Tabelle im Cloud-Chat beauftragen: Die ausgewählte Text-KI liefert strukturierte Inhalte, die App erstellt daraus echte .pptx/.xlsx-Dateien mit Vorschau und Speichern in Downloads/AutoForge. Erste Version: höchstens 12 einfache Textfolien bzw. 200 Zeilen × 20 Spalten auf einem Tabellenblatt; keine automatischen Bilder, Makros oder Formeln. Formelausdrücke bleiben Text. Werte und KI-Inhalte bitte prüfen. Vorhandene Office-Dateien importieren/bearbeiten ist noch nicht umgesetzt; bisherige Text-, Code- und Fotoanhänge bleiben unterstützt.

Fertige Musik-/Videodateien sind weiterhin offen. Der Chat nennt den fehlenden Dienst, statt eine Audio-/Videodatei vorzutäuschen. Liedtexte und Drehbücher können als Text entstehen. Programmcode bleibt als Textdatei erhältlich; der PC-Projektbereich setzt einen verbundenen PC voraus. Websuche liefert Links und Beschreibungen; die Suchseite als Rückfall ist ausdrücklich keine verifizierte Anzeige. Angebotsfotos sind noch nicht verlässlich verfügbar und werden nicht erfunden.

Prüfstand: 56 automatische Prüfungen bestanden; echte Browser-Bedienprüfung mit simulierter Android-Brücke in drei Größen, einschließlich Fotokontext, privater/familiärer Trennung und Anbieterwechsel. Echte Cloud-Aufrufe bestätigten Katalog (2), Bildbearbeitung und strukturierte Präsentationsdaten (2 Folien). Office-Testdateien mit Python-Bibliotheken lesbar, Unicode und Formeltext geprüft. Der einzelne Testzugang wurde abgemeldet und entfernt. Kein Test auf deinem echten Handy oder Emulator.

## 0.13.4: verständlicher Chat und PC-Einrichtung

Der doppelte Menüeintrag Chat ist entfernt. Privat und Familie öffnen ihre jeweiligen Gespräche; der Rückweg aus Werkzeugen bleibt über ← Chat möglich. Antworten rendern Fettschrift, Listen, Überschriften und Code sicher als DOM-Elemente. HTML aus Antworten wird nicht ausgeführt.

Menü → Mein PC → PC hinzufügen oder einrichten fragt nach demselben Netzwerk und vorhandener Installation. Der Link kann über den Android-Teilen-Dialog an den PC weitergegeben werden. Es gibt keine Erkennung beliebiger Windows-Rechner im Netzwerk und keine Installation auf einem unvorbereiteten PC ohne dortiges Öffnen. Bekannte PCs werden nur über den eigenen Cloud-Zugang geladen.

Das neue PC-Paket enthält den Windows-x64-Agenten mit seiner .NET-Laufzeit. ZIP am PC entpacken, AutoForge installieren.cmd öffnen, zustimmen. Programmdateien werden unter dem eigenen lokalen AppData-Ordner abgelegt, Desktop-Verknüpfung erstellt und der Agent mit Verbindungscode geöffnet. Kein Administratorzugang erforderlich. Das Paket ist nicht mit einem Windows-Code-Signierzertifikat signiert; Windows kann deshalb einen Herausgeberhinweis zeigen. Es enthält keine Sitzungen, eigenen Cloud-Schlüssel oder KI-Modelle. Der bestehende Projektbereich bleibt G:\gpt\AutoForge; ohne Laufwerk G stoppt die Einrichtung vor dem Kopieren. Vorhandene Daten/Modelle bleiben unverändert. Für lokale KI und Projektbau bleiben vorhandene Modelle, Node/Ollama bzw. SDK nötig.

Heimnetzerkennung ergänzt: nur laufende AutoForge-Agenten ab 0.6.2, wenn sie am PC ausdrücklich aktiviert wurde. UDP 47771 antwortet ausschließlich an private IPv4-Adressen im selben Subnetz, mit zufälligem Anfragenachweis, Rechnername und Version. Keine Schlüssel, Verbindungscodes oder Befehle über diesen Kanal. Die App zeigt erkannte Rechner, die Kopplung erfordert weiterhin den Code am PC. Windows-Firewall bzw. WLAN-Gasttrennung können die Erkennung blockieren; die Cloud-Kopplung funktioniert weiterhin. Unvorbereitete Windows-PCs werden nicht gefunden oder ferninstalliert. Die Erkennung wird durch die Datei %LOCALAPPDATA%/AutoForge/discovery-enabled aktiviert; deren Entfernen und Agent-Neustart schaltet sie wieder ab.

# Mobile 0.13.5 / PC 0.6.3

Mein PC enthält jetzt KI auswählen. Der Kopf zeigt die zuletzt verwendete oder gerade angefragte KI; Antippen öffnet den KI-Katalog. Öffentlich gefundene kostenlose OpenRouter-Modelle benötigen einen eigenen Schlüssel. Der bestehende AutoForge-Cloudzugang ist getrennt aufgeführt; Restkontingente sind unbekannt. Eine Katalogsuche installiert oder trainiert keine Modelle.

Das Schreibfeld nutzt die volle Breite, wächst mit Text und lässt sich vergrößern. Anhänge stehen in einer Werkzeugleiste darunter. Neue Fotos erhalten Vorschaubilder im Chatverlauf. Höchstens 96 Nachrichten mit verkleinerten Vorschaubildern werden auf diesem Gerät gespeichert; keine automatische Übertragung der Originale an Familienmitglieder. Der vollständige Foto-Kontext bleibt wie bisher höchstens 24 Stunden für Folgeaufträge. Chat löschen entfernt auch die Vorschau.

PC 0.6.3 enthält einen nativen Chat über die vorhandene lokale Ollama-KI, bestehende Chats und ein Formular für kontrollierte Wikipedia-Recherche mit Internetfreigabe, Grenzen, Endzeit, Stoppen und Protokoll/Speicheranzeige. Vorausgesetzt sind die vorhandene AutoForge-Brain-Installation auf G, Node und Ollama mit Modell. Modelle werden nicht mitgeliefert. Sprachdialog ist noch nicht eingebaut; Schreiben funktioniert im neuen Chatfenster. Quellen landen im Gedächtnis; Modellgewichte werden nicht trainiert.

Die grüne Handy-Ampel verwendet eine Besitzer-Heartbeatmeldung der geöffneten neuen App (alle 30 Sekunden), mit 75 Sekunden Ablaufzeit. Kopplung, Aktivität und Cloud-Fehler sind getrennte Zustände. Familienmitglieder können diese Besitzer-Aktivität nicht melden. Die App muss für die Ampel geöffnet und mit dem gekoppelten PC ausgewählt sein.
