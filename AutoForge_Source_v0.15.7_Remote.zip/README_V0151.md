# AutoForge Mobile 0.15.1 / Build 54

Als Update installieren, alte App nicht deinstallieren. PC-Agent bleibt 0.6.14.

Ordnerstruktur ist die neue Standardansicht. Das Hauptmenü hat vier Bereiche: Chats, Meine Geräte, Werkzeuge, Einstellungen. Unterbereiche haben einen Zurück-Knopf; Hauptmenü führt wieder zur obersten Ebene. Gesprächsliste mit Datum, Sortierung und Löschen ist unter Chats erreichbar. Chats bleiben die Startseite der App.

Einstellungen → App & Darstellung → Menüansicht: Ordnerstruktur, Startkacheln oder Arbeitsbereich. Die Auswahl wird nur auf diesem Gerät gespeichert und bleibt nach einem Neustart erhalten. Alle Ansichten benutzen dieselben Funktionen und Berechtigungen. Der Arbeitsbereich zeigt aufklappbare Gruppen, die Kachelansicht zeigt die Einträge als Kacheln. Auf breiten Bildschirmen bleibt das Menü sichtbar.

Meine Geräte → dein PC: Bildschirm öffnen, Starten / Herunterfahren, Verbindung & Freigabe und KI auswählen. PC-Kopplung, Stromaktionen und KI-Zugang liegen auf getrennten Seiten. Einstellungen enthält Darstellung, Familie & Einladungen sowie App-Version & Hilfe. Bilder und Dateien werden weiterhin im Chat bearbeitet; der Menüeintrag führt dorthin.

Dieses Update ändert die Menüführung. Automatisches Vollbild beim Verbinden, automatische Drehung unabhängig von Androids Drehsperre sowie Windows-Textfelderkennung für die Tastatur sind noch offen. Die Bildschirmfunktion, Zwei-Finger-Zoom und Rückkehr nach Handysperre entsprechen 0.15.0. Kein PC-, Cloud- oder Datenbank-Update erforderlich.

Prüfung: 67 bestehende Tests bestanden. Navigation im Browser mit simulierten App-Daten geprüft: Untermenüs, Zurück, getrennte PC-Steuerung, alle drei Ansichten, gespeicherte Auswahl nach Neuladen, Chatverlauf und ungesendeter Text, Familie, Version und KI-Auswahl. Drei Bildschirmgrößen pro Ansicht geprüft. Kein physisches Android-Gerät im Entwicklertest. Signierte APK wird nach dem Build mit der Quelle und dem bisherigen Signierer abgeglichen.
