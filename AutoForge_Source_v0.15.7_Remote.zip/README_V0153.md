# AutoForge Mobile 0.15.3 – offene PC-Aufträge klar erkennen

Die APK als Update zur bisherigen App installieren. Anmeldungen, private und gemeinsame Chats sowie die Ordneransicht bleiben erhalten. Android-Version 0.15.3 / Build 56. PC-Agent weiterhin mindestens der vorhandene 0.6.14; PC 0.6.15 verbessert zusätzlich das lokale PC-Chatfenster, ist für diese Handy-Änderung aber nicht erforderlich.

Bei lokalen Aufträgen erscheint direkt im Chat eine kompakte Anzeige: wartet auf den PC, vom PC übernommen oder Bestätigung prüfen. Sie zeigt die Zeit seit der Übertragung. Die Cloud liefert noch keine einzelnen Modellschritte und keinen laufenden Antworttext ans Handy; dafür wird kein erfundener Fortschrittswert angezeigt.

„Warten beenden“ beendet nur das Warten in der App. Der Auftrag bleibt auf dem Server bestehen; die KI auf dem PC wird damit nicht gestoppt. „Auftrag prüfen“ fragt dieselbe Auftragsnummer erneut ab. Anschließend kannst du auch „Cloud-KI nutzen“ wählen, ohne den lokalen Auftrag zu verlieren. Beim nächsten Wechsel zur lokalen KI lässt er sich weiter prüfen. Ein Neustart der App sendet ihn nicht erneut.

Nach dem Abholen einer verspäteten Antwort wird nur die unveränderte ursprüngliche Frage aus dem Eingabefeld entfernt. Eine während des Wartens neu geschriebene Nachricht bleibt erhalten. Fehler oder fehlende Aufträge erzeugen keine falsche Erfolgsmeldung; bei fehlender Statusauskunft bleibt die gespeicherte Auftragsnummer erhalten. Ältere offene Aufträge ohne Startzeit bleiben prüfbar.

Geprüft: 77 bestehende automatische Tests und ein Browser-Bedienungstest mit simuliertem Android-Zugang/PC-Aufträgen für Warteschlange, Übernahme, Zeitangabe, Pause ohne Abbruch, erneutes Prüfen ohne Doppelauftrag, unterschiedliche Entwürfe, App-Neuladen, fehlende Aufträge, Anbieterwechsel und kleine/querformatige Ansichten. Kein physischer Android-Test und keine neue Cloud- oder Datenbankänderung.
