# AutoForge Mobile 0.15.2 / Build 55

Als Update installieren, alte App nicht deinstallieren. PC-Agent bleibt 0.6.14. Die wählbare Ordnerstruktur aus 0.15.1 bleibt erhalten.

Meine Geräte → dein PC → Bildschirm öffnen. Wähle „Nur ansehen“ oder „PC bedienen“ und tippe auf Verbinden. Die Verbindung öffnet automatisch Vollbild; die Handy-Ausrichtung wird über den Drehsensor gewählt, auch bei ausgeschalteter allgemeiner Android-Drehung. „Ansicht“ verlässt Vollbild und gibt die normale Android-Ausrichtung frei. „Querformat fest“ ist in der Fensteransicht weiterhin wählbar. Geräte ohne Drehsensor oder mit vom System erzwungener Ausrichtung können abweichen.

Das alte Kästchen „Selbst bedienen“ entfällt. Vor Verbinden ist „Nur ansehen“ voreingestellt. „PC bedienen“ erlaubt kurze Tipps als PC-Klicks und aktiviert Tastatur und zusätzliche Tasten. Im Vollbild zeigt die Modustaste jeweils die Aktion zum Wechseln: „PC bedienen“ oder „Nur ansehen“. Die Tastaturtaste ist unmittelbar erreichbar, ohne erst weitere Bedienelemente zu öffnen.

„Tastatur“ öffnet ein Textfeld und fordert die Android-Tastatur an. Der eingegebene Text wird erst durch „Text am PC eingeben“ gesendet. „Weitere Tasten“ öffnet Enter, Tab, Pfeiltasten, Scrollen und Rechtsklickauswahl. STOPP bleibt auch über der Texteingabe erreichbar. Beim Wechsel zu Nur ansehen, Stopp oder Unterbrechung wird der Texteingabeentwurf verworfen. Die Tastatur öffnet sich noch nicht automatisch beim Antippen eines Windows-Textfelds: dafür fehlt dem PC-Agenten eine Fokusmeldung. Der neue Knopf ist der verlässliche manuelle Weg.

Nach Sperren und Entsperren wird bei unveränderter aktiver Dauerfreigabe weiter automatisch verbunden, immer als „Nur ansehen“. Alte Texte und Eingaben werden nie wiederholt. STOPP beendet die laufende Verbindung und kehrt zur Verbindungsansicht zurück. Eine am PC aktivierte Dauerfreigabe bleibt dabei erhalten; STOPP am PC entzieht sie. Familie erhält weiterhin keine PC-Steuerungsrechte. Keine Änderungen an PC, Cloud oder Datenbank nötig.

Unverändert: ungefähr ein JPEG pro Sekunde, Hauptmonitor ohne Ton, Zwei-Finger-Zoom, Verschieben des vergrößerten Bildes. Ein TURN-Relay für zuverlässige Verbindungen durch beliebige Router fehlt weiterhin. Windows muss eingeschaltet, entsperrt und erreichbar sein; der PC wird nicht aufgeweckt.

Prüfung: 67 bestehende Tests; Browsernavigation für drei Menüansichten und drei Größen; echter Chrome-zu-.NET-WebRTC-Test mit künstlichem Bild und simulierten Eingaben für Moduswahl, automatisches Vollbild, Orientierungsschnittstelle, Tastatur/Fokus, explizite Textübertragung, STOPP bei verkleinertem Tastatur-Viewport, Zoom, Pause/Rückkehr und Entzug der Freigabe. Android-Systemleisten, Drehsensor und echte Bildschirmtastatur sind im Browser nur simuliert; ein physisches Handy wurde nicht getestet. Signierte APK wird nach dem Build mit der Quelle und dem bisherigen Signierer abgeglichen.
