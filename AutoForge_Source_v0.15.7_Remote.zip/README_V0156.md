# AutoForge Mobile 0.15.6 – Arbeitsschritte deiner lokalen KI

APK als Update installieren, die alte App nicht löschen. Version 0.15.6 / Build 59. Für die neuen Meldungen am PC zusätzlich den PC-Agenten 0.6.17 und das KI-Modul 0.3.3 aktualisieren; das gemeinsame PC/KI-Updatepaket enthält beides. Ältere PC-/KI-Versionen bleiben kompatibel, melden aber nur den bisherigen allgemeinen Bearbeitungsstatus.

Im lokalen Chat zeigt der offene Auftrag jetzt den zuletzt vom KI-Dienst gemeldeten Schritt, zum Beispiel Entwurf, Prüfung, Korrektur, Internetsuche oder Webseite lesen. Der PC ruft diesen Stand etwa alle zwei Sekunden ab und überträgt geänderte Stufen über die bestehenden, besitzergeschützten Auftragsmeldungen. Die App fragt wie bisher regelmäßig nach. Sehr kurze Schritte können daher fehlen; es wird kein Prozentwert oder Fertigstellungstermin erfunden. Antworttext erscheint weiterhin nach Abschluss.

Warten beenden hält nur den Abruf in der App an. Es stoppt weder Modell noch PC-Auftrag. Auftrag prüfen fragt dieselbe Nummer erneut ab und startet keine zweite Anfrage. Die bisherigen gespeicherten Auftragsnummern bleiben auch im KI-Dienst erhalten. Ein Ausfall der Fortschrittsmeldung darf keine Modellfrage wiederholen. Nur festgelegte Stufennamen werden übertragen; keine Antworten, Fragen, Dateipfade oder Internetadressen im zusätzlichen Fortschrittskanal.

Privat-/Familienbereiche, Quellenkarten, Programme und Entwürfe funktionieren weiter wie bisher. An Cloud-Funktion, Datenbank, Zugriffsregeln und PC-Freigaben wurde nichts geändert. Es werden bestehende Ereignisfelder verwendet. Eine reine Cloud-Datenbankprobe war während der Entwicklung über das Verwaltungswerkzeug nicht erreichbar; Live-Übertragung auf einem echten Handy ist deshalb noch zu testen. Die implementierten Wege wurden mit simulierten Diensten geprüft.

Prüfungen und die abschließenden Paketdaten stehen im Masterplan und der Chat-Übergabe. Kein Modelltraining und noch kein laufender Antworttext vom PC aufs Handy.
