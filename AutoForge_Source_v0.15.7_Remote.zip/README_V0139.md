# Mobile 0.13.9 / Build 50 – Robis Antworten anhören

Unter jeder KI-Antwort im neuen Chat steht „Vorlesen“. Ein Tipp startet die Android-Stimme; „Vorlesen stoppen“ beendet sie. Gilt für lokale und Cloud-Antworten, private und Familienchats. Kein automatisches Vorlesen beim Senden oder Laden alter Chats. Diktieren aus 0.13.9 bleibt erhalten.

AutoForge wählt eine installierte deutsche Stimme, die laut Android keine Netzwerkverbindung benötigt. Keine automatische Online-Ersatzstimme und kein automatischer Download. Fehlt eine passende Stimme, erscheint ein Hinweis zum Einrichten der Android-Sprachdaten; der Textchat bleibt nutzbar. Die Wiedergabe nutzt die Medienlautstärke und gegebenenfalls deine Kopfhörer. Audiofokusverlust, Verlassen der App, neuer Chat, Wechsel von KI/PC/Familienbereich und Diktieren stoppen die Ausgabe. Nur die ausgewählte Antwort wird an den eingerichteten Android-Sprachausgabedienst übergeben, nicht der gesamte Verlauf. Android-Spracherkennung fürs Diktieren kann weiterhin Audiodaten online verarbeiten; dafür bleibt der separate Hinweis bestehen.

Lange Antworten werden nur fürs Vorlesen auf etwa 3900 Zeichen gekürzt, mit Hinweis. Vollständiger Text bleibt im Chat. Codeblöcke werden ausgelassen, Linkbeschriftungen statt URLs gelesen. Kein Aktivierungswort, kein Dauerlauschen und kein fließender Sprachdialog. Es werden keine Audiodateien gespeichert. Nach fünf Minuten wird eine Ausgabe beendet; startet die Stimme nicht, gibt es eine Fehlerrückmeldung.

67 automatische Mobile-Prüfungen inklusive acht neuer Sprachprüfungen bestanden. Zusätzliche Chrome-Bedienprüfung mit simulierter Android-Stimme in drei Größen: nur Antworten erhalten Vorlesen, kein automatischer Start, sichtbarer tatsächlicher Stimmstatus, Stopp und Navigation. Native Android-Kompilierung und signierter APK-Build werden über GitHub geprüft. Keine Prüfung auf physischem Android-Gerät; Stimme und Lautstärke bitte dort ausprobieren. Alte App nicht deinstallieren, APK als Update installieren.

PC bleibt 0.6.11. Keine Änderungen an Cloud-Funktionen, Datenbank, Modellen oder Kopplung. Keine Änderung von Modellgewichten. Hauptzweig bleibt zunächst auf 0.13.9; neue APK wird auf einem separaten Entwicklungszweig gebaut.

Android-Grundlage: https://developer.android.com/reference/android/speech/tts/TextToSpeech
