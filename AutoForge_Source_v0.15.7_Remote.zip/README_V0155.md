# AutoForge Mobile 0.15.5 – Quellen direkt öffnen

Die APK als Update installieren, die bisherige App nicht löschen. Version 0.15.5 / Build 58. Ordnerstruktur, Chats, Kopplung, offene PC-Aufträge und Projektkarten bleiben erhalten. Vorhandener PC-Agent und KI-Modul bleiben kompatibel; kein Cloud-/Datenbankupdate nötig. PC-Version 0.6.16 ergänzt dieselben Quellenknöpfe im nativen PC-Chat, wird für die Handy-Ansicht aber nicht vorausgesetzt.

Nach einer lokalen Internetrecherche zeigt der Chat unter der Antwort eine Quellenliste mit anklickbarem Titel und sichtbarer Internetadresse beziehungsweise Domain. Bei bis zu zwei Quellen ist die Liste geöffnet, größere Listen kannst du über „Quellen“ aufklappen. Ein Antippen öffnet den Link über den vorhandenen Android-Browserweg außerhalb der AutoForge-Webansicht.

Die Kennzeichnung unterscheidet „Webseite gelesen · gekürzter Auszug“ und „Nur Suchausschnitt · Webseite nicht gelesen“. Wenn die gespeicherten Metadaten keine Abrufart nennen, steht dort ausdrücklich „Link · Abrufart nicht gemeldet“. Eine Abrufzeit erscheint nur, wenn sie tatsächlich gespeichert wurde. Das bestätigt weder aktuelle Preise noch Verfügbarkeit oder den Wahrheitsgehalt einer Quelle.

Es werden ausschließlich gespeicherte Quellenadressen angezeigt, keine neuen Links aus Modellprosa erfunden. Die Anzeige lädt keine Webseiten oder Bilder automatisch. Normale HTTP-/HTTPS-Links werden geprüft, doppelte Adressen zusammengefasst und höchstens acht Quellen je Antwort angezeigt. Projektverweise behalten ihre eigenen Karten. Lokale Quellen werden beim Wechsel zum Cloud-/Familienchat nicht übernommen; die bereits anklickbaren Links in Cloud-Antworten bleiben unverändert.

Geprüft: 80 automatische Handy-Tests sowie Browserprüfung mit künstlichen Quellen für Linkvalidierung, Textdarstellung, Deduplizierung, Abrufart/-zeit, explizites Anklicken ohne automatisches Nachladen, Entwurferhalt, Bereichstrennung und kleine/querformatige Ansichten. Bestehende Menü-, Projekt- und Warteschlangenprüfungen werden ebenfalls mit dem neuen Stand geprüft. Noch kein physischer Android-Test; die nativen Android-Browseraufrufe bleiben unverändert.
