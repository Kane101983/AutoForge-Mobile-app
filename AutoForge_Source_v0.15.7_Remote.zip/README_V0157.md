# AutoForge Mobile 0.15.7 / Build 60

Die Handy-App zeigt beim Senden sofort, ob sie die lokale PC-KI oder die Cloud-KI anspricht und ob sie noch die Verbindung prüft. Eine nicht antwortende Startverbindung wird nach 15 Sekunden sichtbar gemeldet. Die Frage bleibt erhalten; offene Aufträge werden weiterhin geprüft statt doppelt gesendet. Fehler bei der Namensauflösung erhalten eine verständliche Meldung.

Am 27.10.2026 wurde die vorhandene kostenlose AutoForge-Cloud als INACTIVE vorgefunden und ihre Wiederaktivierung angestoßen. Danach wurden ACTIVE_HEALTHY und eine harmlose Datenbankprobe erfolgreich geprüft. Der echte Versand mit deinem Handy bleibt zu prüfen. Diese APK ersetzt keine notwendige Cloud-Verfügbarkeit. Bestehende Kopplungen und private Chats werden nicht absichtlich gelöscht.

APK über die bestehende App installieren. Gewähltes Modell und installierte Version stehen weiterhin in der Oberfläche. Der Entwicklungsvergleich auf dem PC benötigt PC 0.6.18 plus KI-Modul 0.3.4. Kein Modellgewichtstraining.
