const {test}=require('node:test'),assert=require('node:assert/strict');
const {normalise,evidence}=require('../app/src/main/assets/source-links.js');
test('only normal web addresses become source links',()=>{
 const invalid=['javascript:alert(1)','data:text/html,hi','file:///G:/private','intent://run','https://user:password@example.org/','https://example.org/\\evil',' https://example.org','https://example.org/\n'];
 assert.deepEqual(normalise(invalid.map(id=>({id}))),[]);
 assert.deepEqual(normalise([null,3,{}, {id:['https://example.org']}]),[]);
});
test('stored sources keep title, host, evidence and actual retrieval time',()=>{
 const rows=normalise([{id:'https://example.org/read',title:'A <script> is just text',kind:'page_excerpt',fetched:'2026-10-24T18:00:00Z'},{url:'http://example.net/search',kind:'search_excerpt',fetched:'not-a-time'},{id:'https://example.com/unknown'}]);
 assert.equal(rows.length,3);assert.equal(rows[0].title,'A <script> is just text');assert.equal(rows[0].host,'example.org');assert.equal(rows[0].fetched,'2026-10-24T18:00:00Z');assert.equal(rows[1].fetched,null);
 assert.match(evidence(rows[0].kind),/Webseite gelesen/);assert.match(evidence(rows[1].kind),/Webseite nicht gelesen/);assert.match(evidence(rows[2].kind),/nicht gemeldet/);
});
test('project references are separate, repeated addresses are deduplicated and list is bounded',()=>{
 const rows=normalise([{kind:'project',id:'https://example.org/project'}, {id:'https://example.org'}, {id:'https://example.org/'},...Array.from({length:20},(_,i)=>({id:'https://example.org/'+i}))]);
 assert.equal(rows.length,8);assert.equal(rows[0].url,'https://example.org/');assert(!rows.some(r=>r.url.endsWith('project')));
});
