/* Reading is an explicit per-answer action; history never triggers playback. */
(()=>{
 let sequence=0,id='',where='';
 const context=()=>JSON.stringify([engine,cloud.groupId||'',chat,device,document.body.dataset.page]);
 function prepare(text){
  text=String(text||'').replace(/```[\s\S]*?(?:```|$)/g,' Code ausgelassen. ').replace(/!\[[^\]]*\]\([^)]*\)/g,' Bild. ').replace(/\[([^\]]+)\]\([^)]*\)/g,'$1').replace(/https?:\/\/\S+/g,' Link. ').replace(/<[^>]*>/g,'').replace(/[#*_`~]/g,'').replace(/\s+/g,' ').trim();
  const truncated=text.length>3900;
  if(truncated){text=text.slice(0,3900);if(/[\uD800-\uDBFF]$/.test(text))text=text.slice(0,-1);text+=' … Vorlesen gekürzt. Vollständiger Text im Chat.';}
  return {text,truncated};
 }
 function clear(){ $('speechBar').hidden=true;$('speechStatus').textContent=''; }
 function stop(){
  const previous=id;id='';clear();
  if(previous&&typeof window.AndroidBridge?.stopSpeech==='function')bridge('stopSpeech').catch(()=>{});
 }
 window.AFSpeechState=(request,state,message)=>{
  if(request!==id)return;
  if(context()!==where){stop();return;}
  if(state==='speaking'){$('speechStatus').textContent='Robi liest vor · '+String(message||'Android-Stimme');return;}
  // Keep id until a later error callback, since native cancellation can precede an error.
  clear();if(state==='error'){notice('Vorlesen: '+message);id='';}
 };
 window.AutoForgeSpeech={prepare,stop,async read(text){
  stop();
  if(window.AutoForgeDictation?.pending){notice('Bitte zuerst die Spracheingabe beenden.');return;}
  if(typeof window.AndroidBridge?.speakText!=='function'){notice('Vorlesen benötigt die neue Android-App.');return;}
  const prepared=prepare(text);if(!prepared.text){notice('Keine vorlesbare Antwort vorhanden.');return;}
  notice('');id='mobile-speech-'+(++sequence);const request=id;where=context();
  $('speechBar').hidden=false;$('speechStatus').textContent='Stimme wird gestartet …'+(prepared.truncated?' · lange Antwort gekürzt':'');
  try{const result=await bridge('speakText',prepared.text,request);if(request===id&&!result.ok){id='';clear();notice('Vorlesen: '+(result.error||'Nicht verfügbar.'));}}
  catch(e){if(request===id){stop();notice('Vorlesen nicht verfügbar: '+e.message);}}
 }};
 $('stopSpeech').onclick=stop;
 const stopTargets='#send,#newChat,#privateChatButton,#familyChatButton,#familyManageButton,#deleteChat,#dictateButton,#backChat,[data-page],#settingsButton';
 document.addEventListener('click',e=>{if(e.target.closest?.(stopTargets))stop();},true);
 document.addEventListener('change',e=>{if(['engineSelect','chatSelect','chatScope','deviceSelect'].includes(e.target.id))stop();},true);
 $('chatForm').addEventListener('submit',stop,true);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
 window.addEventListener('af-history-rendered',()=>{if(id&&context()!==where)stop();});
})();
