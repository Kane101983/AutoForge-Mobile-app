/* Project references are display data from the authenticated PC, never executable URLs. */
(()=>{
 const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
 const valid=id=>typeof id==='string'&&uuid.test(id);
 let selected=null;
 const selection=element('aside','','projectSelection');selection.id='projectSelection';selection.hidden=true;selection.setAttribute('aria-live','polite');
 $('projectPrompt').before(selection);
 function sync(){
  if(selected&&selected.device!==device){selected=null;$('baseId').value='';}
  selection.hidden=!selected;
  selection.textContent=selected?'Änderung an „'+selected.title+'“. Die bisherige Fassung bleibt erhalten.':'';
  $('build').textContent=selected?'Neue Fassung erstellen':'Programm erstellen';
  for(const button of document.querySelectorAll('[data-project-action]'))button.disabled=busy||!!pending||button.dataset.projectDevice!==device;
  for(const card of document.querySelectorAll('.message .projectCard'))card.hidden=engine!=='local'||!!cloud.groupId||card.dataset.projectDevice!==device;
 }
 function select(project,navigate=true){
  if(!project||!valid(project.id)||!device)return;
  selected={id:project.id,title:String(project.title||'Mein Programm'),device};$('baseId').value=project.id;sync();
  if(navigate)window.AutoForgeNavigation?.go('projects');
  $('projectPrompt').focus();notice('Änderung an „'+selected.title+'“ beschreiben. Dein vorhandener Text bleibt erhalten.');
 }
 function button(label,fn){const owner=device,b=element('button',label);b.type='button';b.dataset.projectAction='true';b.dataset.projectDevice=owner;b.onclick=()=>{if(device!==owner){notice('Dieses Programm gehört zum zuvor ausgewählten PC. Bitte zuerst dessen Projektliste öffnen.');return;}fn();};return b;}
 function screen(){window.AutoForgeNavigation?.go('devices');$('desktopOpen').click();notice('Bildschirmansicht geöffnet. Verbinde dich, um die Vorschau am PC zu bedienen.');}
 function card(project,inline=false,byId=new Map()){
  const c=element('article','','card projectCard');c.dataset.projectId=project.id;c.dataset.projectDevice=device;
  c.append(element(inline?'strong':'h3',String(project.title||'Mein Programm')));
  if(!inline){
   const date=Date.parse(project.created);c.append(element('small',Number.isFinite(date)?'Erstellt: '+new Date(date).toLocaleString('de-DE'):'Erstellungszeit nicht gemeldet'));
   if(project.baseId)c.append(element('p','Überarbeitung von „'+String(byId.get(project.baseId)?.title||'einer früheren Fassung')+'“. Die vorherige Fassung bleibt gespeichert.','small'));
   if(project.model)c.append(element('small','Erstellt mit: '+String(project.model)+' · auf deinem PC'));
   if(project.notes)c.append(element('p',String(project.notes)));
   const reports=[...(Array.isArray(project.checks)?project.checks:[]),...(Array.isArray(project.warnings)?project.warnings:[])];
   if(project.quality||reports.length){const check=element('details','');check.append(element('summary','Prüfbericht'));if(project.quality)check.append(element('p',String(project.quality)));for(const report of reports)check.append(element('p',String(report)));c.append(check);}
   if(project.secondOpinion?.text){const review=element('details','');review.append(element('summary','Zweite KI · '+String(project.secondOpinion.model||'lokal')),element('p',String(project.secondOpinion.text)));c.append(review);}
  }
  c.append(element('p','Auf deinem PC gespeichert. Die Programmvorschau ist derzeit am PC verfügbar.','small'));
  const actions=element('div','','row');actions.append(button('Änderung vorbereiten',()=>select(project)),button('PC-Bildschirm öffnen',screen));c.append(actions);return c;
 }
 function appendSources(target,sources){
  if(engine!=='local'||cloud.groupId||!Array.isArray(sources))return;
  const seen=new Set();
  for(const source of sources){if(source?.kind!=='project'||!valid(source.id)||seen.has(source.id))continue;seen.add(source.id);target.append(card(source,true));if(seen.size===8)break;}
 }
 function renderList(projects){
  const rows=(Array.isArray(projects)?projects:[]).filter(p=>p&&valid(p.id));
  const byId=new Map(rows.map(p=>[p.id,p]));$('projectList').replaceChildren();
  rows.sort((a,b)=>(Date.parse(b.created)||0)-(Date.parse(a.created)||0));
  for(const p of rows)$('projectList').append(card(p,false,byId));
  if(!rows.length)$('projectList').append(element('p','Hier erscheinen deine erstellten Programme.'));
  if(selected&&!byId.has(selected.id)){selected=null;$('baseId').value='';notice('Die ausgewählte Fassung ist nicht mehr in der PC-Projektliste. Dein Text bleibt erhalten; wähle eine Fassung oder erstelle ein neues Programm.');}
  sync();
 }
 const fresh=$('freshProject').onclick;$('freshProject').onclick=()=>{if(busy||pending)return;selected=null;fresh?.();sync();$('projectPrompt').focus();};
 window.AutoForgeProjects={appendSources,renderList,select,sync};sync();
})();
