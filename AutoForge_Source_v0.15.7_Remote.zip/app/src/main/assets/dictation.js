/* Android's visible speech dialog returns a draft only. Never submits a message. */
(()=>{
 const button=document.getElementById('dictateButton');
 let active=false;
 const context=()=>JSON.stringify([engine,cloud.groupId||'',chat,device,document.body.dataset.page]);
 const bound=text=>{let s=String(text).slice(0,6000);if(/[\uD800-\uDBFF]$/.test(s))s=s.slice(0,-1);return s;};
 window.AutoForgeDictation={get pending(){return active;}};
 button.onclick=async()=>{
  if(active)return;
  if(busy||initializing){notice('Bitte den laufenden Vorgang abwarten. Dein Text bleibt erhalten.');return;}
  if(typeof window.AndroidBridge?.dictate!=='function'){notice('Diktieren benötigt die neue Android-App. Du kannst weiterhin tippen.');return;}
  const draft=$('prompt').value,where=context();
  if(draft.length>=6000){notice('Das Eingabefeld ist voll. Kürze den Text vor dem Diktieren.');return;}
  active=true;button.disabled=true;button.textContent='Spracheingabe …';
  notice('Android-Spracherkennung öffnen. Danach Text prüfen und selbst senden.');
  try{
   const result=await bridge('dictate');
   if(result.cancelled){notice('Diktieren abgebrochen. Dein Text bleibt erhalten.');return;}
   if(!result.ok)throw Error(result.error||'Spracherkennung nicht verfügbar.');
   if(context()!==where||$('prompt').value!==draft){notice('Chat oder Entwurf wurde geändert. Das Diktat wurde nicht eingefügt.');return;}
   const text=String(result.text||'').trim();
   if(!text){notice('Keine Sprache erkannt. Du kannst erneut diktieren oder tippen.');return;}
   const combined=draft+(draft&&!/\s$/.test(draft)?' ':'')+text;
   $('prompt').value=bound(combined);$('prompt').dispatchEvent(new Event('input',{bubbles:true}));
   notice(combined.length>6000?'Text auf 6000 Zeichen gekürzt. Bitte prüfen und selbst senden.':'Diktat eingefügt. Bitte prüfen und selbst senden.');
  }catch(e){notice('Diktieren nicht verfügbar: '+e.message+' Du kannst weiterhin tippen.');}
  finally{active=false;button.disabled=false;button.textContent='Diktieren';}
 };
})();
