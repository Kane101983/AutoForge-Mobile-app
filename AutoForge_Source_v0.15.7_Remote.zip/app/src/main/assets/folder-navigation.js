/* Presentation preferences are local; existing account and PC permissions stay authoritative. */
(()=>{
 const shell=window.AutoForgeShell,drawer=$('settings'),main=document.querySelector('main');
 const node=(tag,text,cls)=>element(tag,text,cls),button=(label,fn)=>{const b=node('button',label);b.type='button';b.onclick=fn;return b;};
 function page(id,title){const p=node('section','');p.id=id;p.hidden=true;p.append(node('h1',title));main.append(p);shell.register(id,title);return p;}
 const display=page('appearance','App & Darstellung'),power=page('devicePower','Starten / Herunterfahren'),connection=page('deviceConnection','Verbindung & Freigabe'),providers=page('providers','KI auswählen'),about=page('appInfo','App-Version & Hilfe');
 const label=node('label','Menüansicht'),select=node('select','');select.id='menuLayout';
 for(const [value,text] of [['folders','Ordnerstruktur'],['tiles','Startkacheln'],['workspace','Arbeitsbereich']]){const option=node('option',text);option.value=value;select.append(option);}label.append(select);display.append(label,node('p','Du kannst die Ansicht jederzeit wechseln. Chats, Aufträge und Verbindungen bleiben erhalten.'));
 power.append($('pcPower'));$('pcPower').querySelector('summary').hidden=true;
 // Pairing, provider configuration and power controls now each have one destination.
 providers.append($('providerSettings'));$('providerSettings').open=true;$('providerSettings').classList.add('workspaceSection');
 connection.append($('pcSettings'));$('pcSettings').open=true;
 about.append($('appVersion'));
 const preferences=$('preferences');for(const child of [...preferences.children])if(child.tagName==='DETAILS'&&!child.id)about.append(child);
 const advanced=$('advancedSettings');providers.append(advanced);advanced.dataset.destination='providers';$('pcSettings').dataset.destination='deviceConnection';
 const card=document.querySelector('.deviceCard');card.append($('deviceSelect').closest('label'));
 const mainPaths={chat:'Chats',people:'Einstellungen / Familie & Einladungen',devices:'Meine Geräte / Mein PC',devicePower:'Meine Geräte / Mein PC / Starten & Herunterfahren',deviceConnection:'Meine Geräte / Mein PC / Verbindung & Freigabe',providers:'Meine Geräte / KI auswählen',tools:'Werkzeuge',projects:'Werkzeuge / Programme erstellen',learning:'Werkzeuge / Recherche & Üben',preferences:'Einstellungen',appearance:'Einstellungen / App & Darstellung',appInfo:'Einstellungen / App-Version & Hilfe'};
 const parents={chat:null,people:'preferences',devices:null,devicePower:'devices',deviceConnection:'devices',providers:'devices',tools:null,projects:'tools',learning:'tools',preferences:null,appearance:'preferences',appInfo:'preferences'};
 function go(id){shell.open(id);$('areaTitle').textContent=mainPaths[id]||$('areaTitle').textContent;}
 function choices(target,items){const list=node('div','','folderChoices');for(const [title,description,id] of items){const b=button(title,()=>go(id));b.append(node('small',description),node('span','›','folderArrow'));list.append(b);}target.append(list);}
 choices($('devices'),[['Starten / Herunterfahren','Standby, Neustart und Stromaktionen','devicePower'],['Verbindung & Freigabe','PC koppeln oder Verbindung einrichten','deviceConnection'],['KI auswählen','Kostenlose Cloud-KI oder lokales Modell','providers']]);
 choices(preferences,[['App & Darstellung','Menüansicht umstellen','appearance'],['Familie & Einladungen','Mitglieder und gemeinsame Gespräche','people'],['App-Version & Hilfe','Installierte Version und Möglichkeiten','appInfo']]);
 const chatActions=drawer.querySelector('.chatActions'),conversations=$('conversations');
 const chatPane=node('div','','folderChatPane');chatPane.append(chatActions,conversations);drawer.insertBefore(chatPane,drawer.querySelector('.menuList'));
 const menu=drawer.querySelector('.menuList');menu.replaceChildren();
 const crumb=node('div','','folderBreadcrumb');crumb.setAttribute('aria-live','polite');drawer.insertBefore(crumb,chatPane);
 const back=button('‹ Zurück',()=>render(menuParent[current]||'root'));back.id='folderBack';drawer.insertBefore(back,crumb);
 const home=button('⌂ Hauptmenü',()=>render('root'));home.id='folderHome';drawer.querySelector('.menuHeading').after(home);
 const menuParent={chats:'root',devices:'root',pc:'devices',tools:'root',settings:'root'};
 let current='root',layout='folders';try{const saved=localStorage.getItem('af_menu_layout');if(['folders','tiles','workspace'].includes(saved))layout=saved;}catch{}
 const entries={
  root:[['Chats','Private und gemeinsame Gespräche','chats'],['Meine Geräte','Bildschirm und PC-Steuerung','devices'],['Werkzeuge','Erstellen, recherchieren und üben','tools'],['Einstellungen','Darstellung, Familie und App','settings']],
  chats:[['Private Gespräche','Nur für dich',()=>choose(false)],['Familiengespräche','Mit deiner Familie',()=>choose(true)]],
  devices:[['Mein PC','Status, Bildschirm und Steuerung','pc']],
  pc:[['Bildschirm öffnen','Ansehen oder selbst bedienen',()=>{go('devices');$('desktopOpen').focus();}],['Starten / Herunterfahren','Stromaktionen deines PCs',()=>go('devicePower')],['Verbindung & Freigabe','Koppeln und Einrichten',()=>go('deviceConnection')],['KI auswählen','Cloud oder dein eigener Rechner',()=>go('providers')]],
  tools:[['Programme erstellen','Entwürfe auf deinem PC',()=>go('projects')],['Bilder & Dateien','Im Chat anhängen oder erstellen',()=>{go('chat');$('attachButton').focus();}],['Recherche & Üben','Quellen sammeln oder Fähigkeiten prüfen',()=>go('learning')]],
  settings:[['App & Darstellung','Ordner, Kacheln oder Arbeitsbereich',()=>go('appearance')],['Familie & Einladungen','Mitglieder und gemeinsame Chats',()=>go('people')],['App-Version & Hilfe','Installierte Version und Möglichkeiten',()=>go('appInfo')]]
 };
 async function choose(shared){await chooseChatArea(shared);if(!shared||cloud.groupId)go('chat');}
 function makeEntry([title,description,destination]){const b=button(title,()=>typeof destination==='function'?destination():render(destination));b.append(node('small',description),node('span','›','folderArrow'));return b;}
 function render(id='root'){
  current=id;menu.replaceChildren();chatPane.hidden=id!=='chats';back.hidden=id==='root'||layout==='workspace';crumb.textContent=id==='root'?'Hauptmenü':({chats:'Chats',devices:'Meine Geräte',pc:'Meine Geräte / Mein PC',tools:'Werkzeuge',settings:'Einstellungen'}[id]);
  const reportedName=card.querySelector('h2').textContent;entries.devices[0][0]=reportedName.startsWith('Noch kein')?'Mein PC':reportedName;
  if(layout==='workspace'){
   crumb.textContent='Arbeitsbereich';chatPane.hidden=false;
   for(const [title,,key] of entries.root){const d=node('details','');d.open=key==='chats';d.append(node('summary',title));for(const entry of entries[key]){if(typeof entry[2]==='string'){for(const child of entries[entry[2]])d.append(makeEntry(child));}else d.append(makeEntry(entry));}menu.append(d);}
  }else for(const entry of entries[id]||entries.root)menu.append(makeEntry(entry));
 }
 function apply(){document.body.dataset.menuLayout=layout;select.value=layout;render('root');}
 select.onchange=()=>{layout=select.value;try{localStorage.setItem('af_menu_layout',layout);notice('Menüansicht gespeichert: '+select.selectedOptions[0].textContent);}catch{notice('Ansicht geändert; Speichern auf diesem Gerät nicht möglich.');}apply();};
 $('settingsButton').onclick=()=>{if(!drawer.open)render('root');drawer.open=!drawer.open;};
 $('backChat').textContent='‹ Zurück';$('backChat').onclick=()=>{const id=document.body.dataset.page;if(parents[id])go(parents[id]);else{render('root');drawer.open=true;}};
 $('aiBadge').onclick=()=>{go('providers');$('aiCatalog').open=true;};$('providerButton').onclick=()=>{$('engineSelect').focus();};
 openFamilySettings=()=>go('people');
 $('setupCloud').onclick=()=>{go('providers');$('cloudSetup').open=true;};
 // The original device card update remains in charge of reported availability.
 window.AutoForgeNavigation={go,layout:()=>layout};apply();
})();
