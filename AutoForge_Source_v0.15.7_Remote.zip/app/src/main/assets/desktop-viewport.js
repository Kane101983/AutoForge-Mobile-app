/* Local display gestures only. Pinch and pan never become PC clicks. */
(()=>{
 window.AutoForgeDesktopViewport=(viewport,image,onTap,onZoom)=>{
  let zoom=1,base=1,gesture=null,moved=false,multi=false;const pointers=new Map();
  function size(){base=Math.max(1,Math.min(viewport.clientWidth,viewport.clientHeight*(image.naturalWidth||16)/(image.naturalHeight||9)));image.style.width=(base*zoom)+'px';onZoom?.(zoom);}
  function setZoom(value,x,y){
   const old=image.getBoundingClientRect(),box=viewport.getBoundingClientRect();x??=box.left+box.width/2;y??=box.top+box.height/2;
   const ax=old.width?(x-old.left)/old.width:.5,ay=old.height?(y-old.top)/old.height:.5;
   zoom=Math.max(1,Math.min(5,value));size();const current=image.getBoundingClientRect();viewport.scrollLeft+=current.left+ax*current.width-x;viewport.scrollTop+=current.top+ay*current.height-y;
  }
  function pair(){const p=[...pointers.values()];return {distance:Math.max(1,Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y)),x:(p[0].x+p[1].x)/2,y:(p[0].y+p[1].y)/2,zoom};}
  viewport.addEventListener('pointerdown',e=>{
   if(!image.naturalWidth)return;e.preventDefault();viewport.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
   if(pointers.size===1){moved=false;multi=false;gesture={x:e.clientX,y:e.clientY,left:viewport.scrollLeft,top:viewport.scrollTop};}
   else if(pointers.size===2){multi=true;moved=true;gesture=pair();}
  });
  viewport.addEventListener('pointermove',e=>{
   if(!pointers.has(e.pointerId))return;e.preventDefault();pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
   if(pointers.size>=2){const next=pair();setZoom(gesture.zoom*next.distance/gesture.distance,next.x,next.y);}
   else if(gesture){const dx=e.clientX-gesture.x,dy=e.clientY-gesture.y;if(Math.hypot(dx,dy)>8)moved=true;if(moved){viewport.scrollLeft=gesture.left-dx;viewport.scrollTop=gesture.top-dy;}}
  });
  viewport.addEventListener('pointerup',e=>{
   const tracked=pointers.has(e.pointerId);pointers.delete(e.pointerId);
   if(tracked&&!moved&&!multi){const r=image.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;if(x>=0&&x<=1&&y>=0&&y<=1)onTap({x,y});}
   if(pointers.size===1){const p=[...pointers.values()][0];gesture={...p,left:viewport.scrollLeft,top:viewport.scrollTop};moved=true;}
   if(!pointers.size)gesture=null;
  });
  viewport.addEventListener('pointercancel',e=>{pointers.delete(e.pointerId);moved=true;multi=true;gesture=pointers.size>=2?pair():null;});
  viewport.addEventListener('wheel',e=>{if(e.ctrlKey){e.preventDefault();setZoom(zoom*Math.exp(-e.deltaY*.01),e.clientX,e.clientY);}},{passive:false});
  const resize=new ResizeObserver(()=>{size();});resize.observe(viewport);image.addEventListener('load',size);
  return {setZoom,reset(){zoom=1;pointers.clear();gesture=null;multi=true;size();viewport.scrollLeft=viewport.scrollTop=0;},get zoom(){return zoom;}};
 };
})();
