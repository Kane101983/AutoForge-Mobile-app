/* Stored source metadata only. No page fetch, image load or execution while rendering. */
(()=>{
 function normalise(sources){
  if(!Array.isArray(sources))return [];
  const output=[],seen=new Set();
  for(const source of sources){
   if(!source||source.kind==='project')continue;
   const raw=source.url??source.id;
   if(typeof raw!=='string'||raw.length>4096||/[\u0000-\u0020\\]/.test(raw))continue;
   let url;try{url=new URL(raw);}catch{continue;}
   if(!['https:','http:'].includes(url.protocol)||url.username||url.password||seen.has(url.href))continue;
   seen.add(url.href);
   const fetched=typeof source.fetched==='string'&&Number.isFinite(Date.parse(source.fetched))?source.fetched:null;
   output.push({url:url.href,host:url.host,title:typeof source.title==='string'&&source.title.trim()?source.title.slice(0,240):url.host,
    kind:source.kind==='page_excerpt'?'page_excerpt':source.kind==='search_excerpt'?'search_excerpt':'link',fetched});
   if(output.length===8)break;
  }
  return output;
 }
 function evidence(kind){return kind==='page_excerpt'?'Webseite gelesen · gekürzter Auszug':kind==='search_excerpt'?'Nur Suchausschnitt · Webseite nicht gelesen':'Link · Abrufart nicht gemeldet';}
 function append(target,sources){
  const rows=normalise(sources);if(!rows.length)return;
  const make=(tag,text)=>{const node=document.createElement(tag);node.textContent=text;return node;};
  const section=make('details','');section.className='sourceLinks';section.open=rows.length<=2;section.append(make('summary','Quellen · '+rows.length));
  for(const source of rows){
   const card=make('article','');card.className='sourceLink';
   const link=make('a',source.title);link.href=source.url;link.rel='noopener noreferrer';card.append(link,make('small',source.host),make('small',evidence(source.kind)));
   if(source.fetched)card.append(make('small','Abruf: '+new Date(source.fetched).toLocaleString('de-DE')));
   section.append(card);
  }
  target.append(section);
 }
 const api={normalise,evidence,append};if(typeof module!=='undefined'&&module.exports)module.exports=api;if(typeof window!=='undefined')window.AutoForgeSources=api;
})();
