package ai.autoforge.mobile;

import android.app.Activity;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

/** Foreground, explicit playback using an installed German voice requiring no network. */
final class AndroidSpeechOutput {
    interface StateSink { void state(String id, String state, String message); }
    private final Activity activity;
    private final StateSink sink;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private boolean ready, closed;
    private String currentId, pendingText;
    private AudioManager audio;
    private AudioFocusRequest focus;
    private Runnable timeout;

    AndroidSpeechOutput(Activity activity, StateSink sink) { this.activity = activity; this.sink = sink; }

    void speak(String text, String id) {
        stop();
        if (closed || !activity.hasWindowFocus()) { sink.state(id,"error","Bitte AutoForge im Vordergrund öffnen."); return; }
        if (text == null || text.trim().isEmpty() || text.length() > Math.min(4000,TextToSpeech.getMaxSpeechInputLength())) {
            sink.state(id,"error","Keine vorlesbare Antwort oder Text zu lang."); return;
        }
        currentId=id; pendingText=text;
        timeout=()->{ if (id.equals(currentId)) fail("Sprachausgabe antwortet nicht. Erneut versuchen oder Android-Sprachdaten prüfen."); };
        handler.postDelayed(timeout,15000);
        if (tts == null) {
            tts = new TextToSpeech(activity, status -> handler.post(() -> initialized(status)));
        } else if (ready) play();
    }

    private void initialized(int status) {
        if (closed || tts == null) return;
        if (status != TextToSpeech.SUCCESS) { fail("Android-Sprachausgabe konnte nicht gestartet werden."); tts.shutdown(); tts=null; return; }
        try {
            Voice selected=null;
            if (tts.getVoices()!=null) for (Voice voice:tts.getVoices()) {
                if ("de".equals(voice.getLocale().getLanguage()) && !voice.isNetworkConnectionRequired()
                    && (voice.getFeatures()==null || !voice.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED))) {
                    if (selected==null || ("DE".equals(voice.getLocale().getCountry()) && !"DE".equals(selected.getLocale().getCountry()))) selected=voice;
                }
            }
            if (selected==null || tts.setVoice(selected)!=TextToSpeech.SUCCESS) {
                fail("Keine installierte deutsche Offline-Stimme gefunden. Bitte Android-Sprachdaten einrichten; Textchat bleibt nutzbar.");
                tts.shutdown(); tts=null; return;
            }
            tts.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { handler.post(()->{if(id.equals(currentId)) {
                    clearTimeout();timeout=()->{if(id.equals(currentId))fail("Vorlesen nach fünf Minuten beendet.");};handler.postDelayed(timeout,300000);
                    sink.state(id,"speaking",tts.getVoice().getName());
                }}); }
                @Override public void onDone(String id) { handler.post(()->{if(id.equals(currentId)) stop();}); }
                @Override public void onError(String id) { handler.post(()->{if(id.equals(currentId)) fail("Android konnte diese Antwort nicht vorlesen.");}); }
            });
            ready=true;
            if (currentId!=null) play();
        } catch (Exception e) { fail("Android-Sprachausgabe nicht verfügbar. Bitte die Sprachdaten prüfen."); tts.shutdown(); tts=null; ready=false; }
    }

    private void play() {
        if (closed || currentId==null || pendingText==null) return;
        try {
            audio=(AudioManager)activity.getSystemService(Activity.AUDIO_SERVICE);
            String focusId=currentId;
            focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setOnAudioFocusChangeListener(change->{if(change<0) handler.post(()->{if(focusId.equals(currentId))stop();});}).build();
            if (audio==null || audio.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { fail("Audio ist gerade belegt. Bitte später erneut vorlesen."); return; }
            String id=currentId, text=pendingText; pendingText=null;
            if(tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,id)==TextToSpeech.ERROR) { fail("Vorlesen konnte nicht gestartet werden."); return; }
            clearTimeout();timeout=()->{if(id.equals(currentId)) fail("Die Android-Stimme startet nicht. Bitte erneut versuchen.");};handler.postDelayed(timeout,15000);
        } catch(Exception e) { fail("Sprachausgabe nicht verfügbar. Textchat bleibt nutzbar."); }
    }
    private void fail(String message) { String id=currentId; stop(); if(id!=null) sink.state(id,"error",message); }
    private void clearTimeout() { if(timeout!=null)handler.removeCallbacks(timeout);timeout=null; }
    void stop() {
        String id=currentId; currentId=null;pendingText=null;clearTimeout();
        if(tts!=null)tts.stop();
        if(audio!=null && focus!=null)audio.abandonAudioFocusRequest(focus);focus=null;
        if(id!=null)sink.state(id,"stopped","");
    }
    void shutdown() { if(closed)return;stop();closed=true;if(tts!=null){tts.shutdown();tts=null;}ready=false; }
}
