# Mobile 0.13.8 / Build 49 – Nachrichten diktieren

Im Chat neben „Anhang“ auf „Diktieren“ tippen. Der Hinweis erklärt den Android-Sprachdienst. Erst „Diktieren starten“ öffnet dessen sichtbare Aufnahme. Dort fertig sprechen oder abbrechen. Der erkannte Text wird an deinen Entwurf angehängt. Prüfen, gegebenenfalls korrigieren und selbst senden. Kein automatisches Senden, keine direkt ausgeführten Sprachbefehle und kein Dauerlauschen.

Android kann Audiodaten beim eingerichteten Sprachdienst im Internet verarbeiten. Offline-Erkennung wird angefragt, ist aber vom Dienst abhängig und nicht garantiert. Das gilt auch bei Auswahl der lokalen PC-KI. AutoForge bekommt nur das fertige Sprachergebnis und speichert keine Audioaufnahme. Der Text geht erst nach Senden über die gewählte KI-Route. Ein eingerichteter Android-Sprachdienst und dessen Mikrofonzugriff werden benötigt. Fehlt der Dienst, bleibt Tippen möglich. Ein ausgeschalteter PC verhindert Diktieren nicht; für eine lokale KI-Antwort muss er erreichbar sein.

Abbruch und Fehler erhalten den Entwurf. Bei inzwischen geändertem Chat, Familienbereich, KI, PC, Seite oder Entwurf wird ein verspätetes Diktat verworfen. Solange die Spracheingabe offen ist, verhindert „Senden“ einen versehentlichen Auftrag. Maximal 6000 Zeichen; Kürzung wird angezeigt. Dateien und bisherige Chats bleiben erhalten. Die Werkzeugzeile kann bei schmalen Bildschirmen umbrechen.

59 automatische Chat-/Medien-/Familien-/Bedienprüfungen einschließlich acht neuer Diktatprüfungen bestanden. Zusätzlich sieben bestehende Wake-Prüfungen bestanden. Chrome-Bedienprüfung mit simulierter Android-Brücke: Diktat, Abbruch, kein automatisches Senden, Bedienung in drei Größen, bestehende Navigation und Fotoauftrag. Mikrofon/Android-Sprachdienst wurden nicht auf einem echten Handy geprüft. Der Quellstand ist vorbereitet; eine installierbare 0.13.8-APK entsteht erst nach erfolgreichem Android-Build und Signaturprüfung. Bis dahin bleibt die verfügbare APK 0.13.7.

PC bleibt 0.6.11. Keine Cloud-/Datenbankänderung, keine neuen kostenlosen KI-Anbieter, kein Modelltraining in diesem Update. Die APK als Update installieren, die alte App nicht deinstallieren.

Android-Dokumentation: https://developer.android.com/reference/android/speech/RecognizerIntent
