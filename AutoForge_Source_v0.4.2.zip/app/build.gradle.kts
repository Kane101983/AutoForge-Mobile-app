plugins {
    id("com.android.application")
}

android {
    namespace = "ai.autoforge.mobile"
    compileSdk = 36

    defaultConfig {
        applicationId = "ai.autoforge.mobile"
        minSdk = 26
        targetSdk = 36
        versionCode = 6
        versionName = "0.4.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
