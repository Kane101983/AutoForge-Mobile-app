/* Only direct user commands reach this module; never model output or attachments. */
window.AutoForgePowerIntent=text=>{
 const t=String(text||'').toLowerCase().trim().replace(/[.!?]+$/,'').replace(/\bbitte\b/g,'').replace(/\s+/g,' ').trim().replace(/^(?:kannst|könntest) du /,'');
 if(t.length>120||/\b(nicht|kein|ohne|warum|wie|erklär|erklaer|beispiel)\b/.test(t))return null;
 const pc='(?:(?:meinen|den|deinen|mein|der) )?(?:pc|rechner|computer|robert)';
 const match=p=>new RegExp('^(?:'+p+')$','i').test(t);
 if(match('herunterfahren|ausschalten|'+pc+' (?:herunterfahren|ausschalten)|fahr(?:e)? '+pc+' (?:herunter|runter)|schalte '+pc+' aus|mach '+pc+' aus'))return 'shutdown';
 if(match('neustart|neu starten|'+pc+' (?:neu starten|neustarten)|starte '+pc+' neu'))return 'restart';
 if(match('standby|'+pc+' (?:standby|schlafen)|versetze '+pc+' in standby'))return 'sleep';
 if(match('(?:pc starten|einschalten|aufwecken)|'+pc+' (?:starten|einschalten|aufwecken)|starte '+pc+'|schalte '+pc+' ein|weck(?:e)? '+pc+' auf|mach '+pc+' an'))return 'wake';
 return null;
};
(()=>{
 const labels={shutdown:'herunterfahren',restart:'neu starten',sleep:'in Standby versetzen',wake:'starten / aufwecken'};
 let powerBusy=false;
 const status=t=>{$('powerStatus').textContent=t;notice(t);};
 function appendResult(command,result){const user=element('article','','message user');user.append(element('small','DU'),element('p',command));const answer=element('article','','message assistant');answer.append(element('small','PC-STEUERUNG'),element('p',result));$('messages').append(user,answer);if(followOutput)$('messages').scrollTop=$('messages').scrollHeight;}
 async function run(action,command){
  if(powerBusy||busy){status('Ein Auftrag läuft bereits. Bitte zuerst abwarten.');return false;}
  if(cloud.groupId){status('PC-Steuerung ist nur in deinem privaten Bereich möglich. Familienmitglieder erhalten keine PC-Rechte.');return false;}
  if(!device){$('settings').open=true;$('pcSettings').open=true;status('Bitte unter Mein PC deinen gekoppelten Rechner auswählen.');return false;}
  powerBusy=true;for(const b of document.querySelectorAll('[data-power]'))b.disabled=true;
  let jobId='',finished=false;
  try{
   const d=await remote('list_devices');const pc=(d.devices||[]).find(x=>x.id===device);if(!pc)throw Error('Dieser PC gehört nicht zu deinem Zugang oder ist nicht mehr gekoppelt.');
   const name=pc.device_name||'Mein PC';
   if(action==='wake'){
    if(!confirm(name+' starten / aufwecken versuchen? Das funktioniert bisher nur als Wake-Signal im gleichen Heimnetz; die Unterstützung deines PCs ist noch nicht bestätigt.')){status('Startversuch abgebrochen.');return false;}
    const mac=pc.status?.wake_mac;if(!mac)throw Error('Starten ist vorbereitet, aber der PC hat noch keine Wake-Adresse gemeldet. Bitte den Agenten am PC starten.');
    const baseline=Date.parse(pc.last_seen_at)||0,started=Date.now();status('Wake-Signal wird im aktuellen WLAN gesendet …');
    const r=await bridge('sendWakePacket',mac);if(!r?.ok)throw Error(r?.error||'Wake-Signal konnte nicht gesendet werden.');
    status('Wake-Signal gesendet. Warte auf eine neue Statusmeldung des PCs …');
    for(let i=0;i<20;i++){await new Promise(resolve=>setTimeout(resolve,1500));const fresh=(await remote('list_devices')).devices?.find(x=>x.id===device),seen=Date.parse(fresh?.last_seen_at)||0;if(seen>baseline&&seen>=started&&Date.now()-seen<70000){const text=name+' meldet sich online. Das beweist noch nicht, dass er zuvor ausgeschaltet war.';status(text);if(command)appendResult(command,text);return true;}}
    const text='Wake-Signal gesendet, aber keine neue Online-Meldung erhalten. Starten am PC ist noch nicht zuverlässig eingerichtet. Bitte bei Bedarf per Tastatur oder Einschaltknopf starten.';status(text);if(command)appendResult(command,text);return true;
   }
   const seen=Date.parse(pc.last_seen_at);if(!Number.isFinite(seen)||Date.now()-seen>=70000)throw Error('Der PC ist offline. Herunterfahren, Neustart und Standby werden nicht für später vorgemerkt.');
   if(!confirm('Soll '+name+' wirklich '+labels[action]+'? Ungespeicherte Arbeit kann verloren gehen.')){status('Aktion abgebrochen.');return false;}
   status('Bestätigter PC-Befehl wird übertragen …');
   const r=await remote('create_job',{device_id:device,job_type:'project_task',instruction:'Rechner '+labels[action],payload:{kind:'power_action',action,confirmed:true,source:'autoforge-mobile'}});jobId=r.job?.id;if(!jobId)throw Error('PC-Befehl konnte nicht angelegt werden.');
   for(let i=0;i<20;i++){const {job}=await remote('job_status',{job_id:jobId});if(job?.status==='completed'){finished=true;const text='PC-Agent hat '+labels[action]+' bestätigt. Die Aktion wird am PC ausgeführt.';status(text);if(command)appendResult(command,text);return true;}if(['failed','cancelled','waiting_approval'].includes(job?.status)){finished=true;throw Error(job.error||'PC-Befehl nicht ausgeführt: '+job.status);}await new Promise(resolve=>setTimeout(resolve,1500));}
   throw Error('Keine rechtzeitige Bestätigung vom PC.');
  }catch(e){let text=e.message;if(jobId&&!finished){try{await remote('cancel_job',{job_id:jobId});text+=' Der offene Auftrag wurde abgebrochen.';}catch{text+=' Abbruch nicht bestätigt. Unter der bisherigen Oberfläche den Auftrag prüfen; nicht erneut senden.';}}status(text);if(command)appendResult(command,text);return false;}
  finally{powerBusy=false;for(const b of document.querySelectorAll('[data-power]'))b.disabled=false;}
 }
 window.AutoForgePower={run,get busy(){return powerBusy;}};
 for(const b of document.querySelectorAll('[data-power]'))b.onclick=()=>run(b.dataset.power);
})();
