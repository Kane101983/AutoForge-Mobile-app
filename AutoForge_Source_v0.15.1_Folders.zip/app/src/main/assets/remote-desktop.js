/* Manual owner actions only. Never consume chat/model/attachment instructions here. */
(()=>{
 let peer=null,channel=null,epoch=0,interval=null,connectTimer=null,frame=null,url='',target='',control=false,opening=false,lastImage=0,pointer=null;
 let resumeIntent=null,resumeTimer=null,persistentKnown=false;
 const panel=$('desktopPanel'),image=$('desktopImage'),status=$('desktopStatus');
 const report=text=>{status.textContent=text;$('desktopFloatingStatus').textContent=text;};
 function stop(reason='Bildschirmverbindung beendet.',keepResume=false){
  if(!keepResume){resumeIntent=null;clearTimeout(resumeTimer);resumeTimer=null;}epoch++;opening=false;clearInterval(interval);clearTimeout(connectTimer);interval=connectTimer=null;
  if(channel?.readyState==='open')try{channel.send(JSON.stringify({type:'stop'}));}catch{}
  if(channel){channel.onmessage=channel.onopen=channel.onclose=null;channel.close();}channel=null;
  if(peer){peer.onconnectionstatechange=null;peer.close();}peer=null;frame=null;control=false;
  if(url)URL.revokeObjectURL(url);url='';image.removeAttribute('src');viewport.reset();$('desktopText').value='';
  $('desktopControl').checked=false;$('desktopInput').hidden=true;$('desktopConnect').disabled=false;
  report(reason);
 }
 function contextValid(){return !!target&&target===device&&!cloud.groupId&&!document.hidden;}
 function send(message){
  if(!contextValid()){stop('PC oder Gesprächsbereich geändert. Bitte neu verbinden.');return false;}
  if(channel?.readyState!=='open')return false;
  if(!['ping','frame','stop'].includes(message.type)&&!control){report('Nur Ansicht. Zum Bedienen den Schalter aktivieren.');return false;}
  if(channel.bufferedAmount>16384){report('Verbindung ausgelastet. Bitte kurz warten.');return false;}
  channel.send(JSON.stringify(message));return true;
 }
 async function signal(offer,myEpoch){
  const response=await remote('create_job',{device_id:target,job_type:'project_task',instruction:'Manuelle Bildschirmverbindung vom Besitzer öffnen',payload:{kind:'desktop_session',operation:'open',requestId:crypto.randomUUID(),offer}});
  const id=response.job?.id;if(!id)throw Error('Verbindungsauftrag konnte nicht angelegt werden.');
  try{
   for(let i=0;i<30;i++){
    if(myEpoch!==epoch||!contextValid())throw Error('Verbindungsaufbau abgebrochen.');
    const {job}=await remote('job_status',{job_id:id});
    if(job?.status==='completed')return job.result;
    if(['failed','cancelled','waiting_approval'].includes(job?.status))throw Error(job.error||'PC hat die Verbindung nicht freigegeben.');
    await new Promise(resolve=>setTimeout(resolve,1000));
   }
   throw Error('Keine rechtzeitige PC-Antwort. Bitte Agent und Freigabefenster am PC prüfen.');
  }catch(error){try{await remote('cancel_job',{job_id:id});}catch{}throw error;}
 }
 async function gather(connection){
  if(connection.iceGatheringState==='complete')return;
  await new Promise(resolve=>{const timeout=setTimeout(done,4000);function done(){clearTimeout(timeout);connection.removeEventListener('icegatheringstatechange',changed);resolve();}function changed(){if(connection.iceGatheringState==='complete')done();}connection.addEventListener('icegatheringstatechange',changed);});
 }
 function receive(data,myEpoch){
  if(myEpoch!==epoch)return;
  try{
   if(typeof data==='string'){
    if(data.length>200)throw Error('Ungültige Bildnachricht.');const meta=JSON.parse(data);
    if(meta.type!=='frame'||!Number.isInteger(meta.bytes)||meta.bytes<1||meta.bytes>250000||frame)throw Error('Ungültiger Bildanfang.');
    frame={bytes:meta.bytes,received:0,parts:[]};return;
   }
   if(!(data instanceof ArrayBuffer)||!frame||data.byteLength<1||data.byteLength>12000||frame.received+data.byteLength>frame.bytes)throw Error('Ungültiger Bildblock.');
   frame.parts.push(data);frame.received+=data.byteLength;
   if(frame.received===frame.bytes){
    const complete=frame;frame=null;const next=URL.createObjectURL(new Blob(complete.parts,{type:'image/jpeg'}));
    if(url)URL.revokeObjectURL(url);url=next;image.src=next;report('Verbunden · Hauptmonitor · ungefähr 1 Bild/Sekunde · '+(control?'Bedienung an':'nur Ansicht'));
   }
  }catch(error){stop(error.message);}
 }
 async function start(automatic=false){
  if(opening||peer)return;
  if(cloud.groupId){report('Bildschirmzugriff ist nur für deinen privaten PC-Besitzerzugang verfügbar.');return;}
  if(!device){report('Bitte unter Mein PC deinen gekoppelten Rechner auswählen.');return;}
  if(busy||pending||window.AutoForgeDictation?.pending){report('Bitte den laufenden PC-Auftrag oder das Diktat zuerst abschließen.');return;}
  if(!window.RTCPeerConnection){report('Diese Android-WebView unterstützt WebRTC nicht. Bitte Android System WebView aktualisieren.');return;}
  if(!automatic&&!confirm('Deinen PC-Bildschirm verbinden? Sichtbare Inhalte werden direkt verschlüsselt auf dieses Handy übertragen. Am PC muss eine zeitweise Freigabe oder deine Dauerfreigabe aktiviert sein. Du startest zunächst nur die Ansicht.'))return;
  window.AutoForgeSpeech?.stop();
  stop(automatic?'Handy entsperrt · Bildschirm wird wieder verbunden …':'Verbindung wird geprüft …',automatic);const myEpoch=epoch;target=device;opening=true;$('desktopConnect').disabled=true;
  try{
   const {devices=[]}=await remote('list_devices');if(myEpoch!==epoch)return;
   const pc=devices.find(d=>d.id===target);persistentKnown=pc?.status?.desktop_persistent===true;if(automatic&&!persistentKnown){resumeIntent=null;throw Error('Automatische Rückkehr benötigt die Dauerfreigabe am PC. Deine aktuelle Freigabe ist nicht dauerhaft.');}
   if(!pc||Date.now()-Date.parse(pc.last_seen_at)>=70000||!Number.isFinite(Date.parse(pc.last_seen_at)))throw Error('Dein PC ist nicht erreichbar.');
   if(pc.capabilities?.desktop_protocol!==1)throw Error('Bitte zuerst PC-Agent 0.6.13 installieren.');
   if(pc.status?.desktop_enabled!==true)throw Error('Am PC zuerst eine Bildschirmfreigabe erlauben. Für unterwegs kannst du dort die Dauerfreigabe einschalten.');
   const connection=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});peer=connection;
   channel=connection.createDataChannel('autoforge-desktop-v1',{ordered:true});channel.binaryType='arraybuffer';
   channel.onmessage=e=>receive(e.data,myEpoch);
   channel.onopen=()=>{
    if(myEpoch!==epoch)return;opening=false;clearTimeout(connectTimer);report('Verbunden · Bild wird geladen …');
    lastImage=Date.now();send({type:'frame'});interval=setInterval(()=>{if(!contextValid())stop('Ansicht beendet: Gerät, Bereich oder App geändert.');else if(Date.now()-lastImage>10000)stop('Kein aktuelles Bildschirmbild empfangen · Bedienung beendet.');else{send({type:'ping'});send({type:'frame'});}},1000);
   };
   channel.onclose=()=>{if(myEpoch===epoch)stop('PC hat den Bildschirmzugriff beendet.');};
   connection.onconnectionstatechange=()=>{if(myEpoch===epoch&&['failed','closed','disconnected'].includes(connection.connectionState))stop('Direkte Verbindung unterbrochen. Im gleichen WLAN erneut testen. Außerhalb des Heimnetzes kann ein Relay nötig sein.');};
   report('Verschlüsselter Verbindungsaufbau …');await connection.setLocalDescription(await connection.createOffer());await gather(connection);
   if(myEpoch!==epoch)return;
   const result=await signal(connection.localDescription.sdp,myEpoch);if(myEpoch!==epoch||!contextValid())return;
   if(result?.protocol!==1||typeof result.answer!=='string'||result.answer.length>32000)throw Error('PC lieferte kein gültiges Verbindungsangebot.');
   await connection.setRemoteDescription({type:'answer',sdp:result.answer});
   connectTimer=setTimeout(()=>{if(myEpoch===epoch&&channel?.readyState!=='open')stop('Direkte Verbindung nicht möglich. Zuerst im gleichen WLAN testen; ein Internet-Relay ist noch nicht eingerichtet.');},20000);
  }catch(error){if(myEpoch===epoch)stop(error.message,automatic&&!!resumeIntent);}
  return channel?.readyState==='open'||!!peer;
 }
 $('desktopOpen').onclick=()=>{panel.hidden=false;$('settings').open=false;};
 $('desktopClose').onclick=()=>{stop();fullscreen(false);panel.hidden=true;if(panel.dataset.landscape==='true'){bridge('setDesktopLandscape','auto').catch(()=>{});panel.dataset.landscape='false';$('desktopLandscape').textContent='Querformat';}};$('desktopStop').onclick=()=>stop();$('desktopConnect').onclick=()=>start(false);
 $('desktopControl').onchange=()=>{control=$('desktopControl').checked&&channel?.readyState==='open';$('desktopControl').checked=control;$('desktopInput').hidden=!control;report(control?'Bedienung aktiv: Tippen aufs Bild klickt am PC.':'Nur Ansicht · keine Eingaben.');};
 image.onload=()=>{lastImage=Date.now();};image.onerror=()=>{if(peer)stop('Bild konnte nicht angezeigt werden.');};
 const viewport=AutoForgeDesktopViewport($('desktopViewport'),image,point=>send({type:'click',button:$('desktopRight').checked?'right':'left',...point}),zoom=>{$('desktopZoom').textContent=Math.round(zoom*100)+' %';});
 $('desktopZoomIn').onclick=()=>viewport.setZoom(viewport.zoom*1.3);$('desktopZoomOut').onclick=()=>viewport.setZoom(viewport.zoom/1.3);$('desktopFit').onclick=()=>viewport.reset();
 async function fullscreen(enabled){
  try{if(window.AndroidBridge?.setDesktopFullscreen){const r=await bridge('setDesktopFullscreen',enabled);if(!r.ok)throw Error(r.error||'Vollbild nicht verfügbar.');}else if(enabled&&panel.requestFullscreen)await panel.requestFullscreen();else if(!enabled&&document.fullscreenElement)await document.exitFullscreen();}catch(error){report(error.message+' Die bildfüllende App-Ansicht bleibt verfügbar.');}
  panel.classList.toggle('desktopFullscreen',enabled);$('desktopFocus').textContent=enabled?'Vollbild verlassen':'Vollbild';$('desktopFloatingExit').hidden=!enabled;$('desktopFloatingStop').hidden=!enabled;$('desktopFloatingControls').hidden=!enabled;
 }
 $('desktopFocus').onclick=()=>fullscreen(!panel.classList.contains('desktopFullscreen'));
 $('desktopFloatingExit').onclick=()=>fullscreen(false);$('desktopFloatingStop').onclick=()=>stop();$('desktopFloatingControls').onclick=()=>panel.classList.toggle('showDesktopControls');
 $('desktopLandscape').onclick=async()=>{try{const result=await bridge('setDesktopLandscape',panel.dataset.landscape==='true'?'auto':'landscape');if(!result.ok)throw Error(result.error||'Drehen nicht verfügbar.');panel.dataset.landscape=panel.dataset.landscape==='true'?'false':'true';$('desktopLandscape').textContent=panel.dataset.landscape==='true'?'Automatisch drehen':'Querformat';}catch(error){report(error.message+' Drehe das Handy mit aktivierter Bildschirmdrehung.');}};
 $('desktopTextSend').onclick=()=>{const input=$('desktopText'),text=input.value;if(!text||text.length>500||/[\x00-\x1f\x7f]/.test(text)){report('Bitte 1–500 Zeichen ohne Zeilenumbruch eingeben.');return;}if(send({type:'text',text}))input.value='';};
 for(const key of document.querySelectorAll('[data-desktop-key]'))key.onclick=()=>send({type:'key',key:key.dataset.desktopKey});
 for(const scroll of document.querySelectorAll('[data-desktop-scroll]'))scroll.onclick=()=>send({type:'scroll',delta:Number(scroll.dataset.desktopScroll)});
 function pause(){
  if((peer||opening)&&persistentKnown)resumeIntent={device:target,scope:cloud.groupId||'',attempts:0};
  clearTimeout(resumeTimer);resumeTimer=null;stop(resumeIntent?'Handy gesperrt · beim Entsperren wird die Ansicht wieder verbunden.':'App verlassen · Verbindung beendet. Für automatische Rückkehr Dauerfreigabe am PC einschalten.',!!resumeIntent);
 }
 function resume(fresh=true){
  if(fresh&&resumeIntent&&!resumeTimer)resumeIntent.attempts=0;
  if(!resumeIntent||peer||opening||document.hidden||panel.hidden)return;
  if(resumeIntent.device!==device||resumeIntent.scope!==(cloud.groupId||'')){stop('Bereich oder Gerät geändert · bitte selbst verbinden.');return;}
  if(resumeTimer||resumeIntent.attempts>=3)return;
  resumeTimer=setTimeout(async()=>{resumeTimer=null;if(document.hidden)return;resumeIntent.attempts++;const connected=await start(true);if(!connected&&resumeIntent)resume(false);},resumeIntent.attempts?3000:700);
 }
 document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();else resume();});window.addEventListener('pagehide',()=>pause());
 window.AutoForgeDesktop={stop,pause,resume,get active(){return !!peer;}};
})();
