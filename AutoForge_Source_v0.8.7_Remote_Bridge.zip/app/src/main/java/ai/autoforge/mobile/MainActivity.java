package ai.autoforge.mobile;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebChromeClient.FileChooserParams;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.view.ViewGroup;
import android.graphics.Color;
import android.widget.Toast;
import android.util.Base64;

import com.google.mediapipe.tasks.genai.llminference.LlmInference;
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 1042;
    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Android 15/16 enforces edge-to-edge. Samsung Internet/WebView does not
        // reliably resize CSS visualViewport when the IME opens, so AutoForge
        // handles both system bars AND the keyboard natively.  The root container
        // is padded to the exact visible screen area; the WebView therefore never
        // extends behind the clock, navigation buttons or keyboard.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        } else {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        getWindow().setStatusBarColor(Color.rgb(11, 14, 18));
        getWindow().setNavigationBarColor(Color.rgb(11, 14, 18));

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11, 14, 18));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11, 14, 18));
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                boolean imeVisible = insets.isVisible(WindowInsets.Type.ime());
                top = bars.top;
                // ime.bottom is measured from the physical bottom of the display.
                // Using it as root padding leaves the child exactly above the keyboard.
                bottom = imeVisible ? Math.max(ime.bottom, bars.bottom) : bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            if (v.getPaddingTop() != top || v.getPaddingBottom() != bottom) {
                v.setPadding(0, top, 0, bottom);
            }
            return insets;
        });
        setContentView(root);
        root.requestApplyInsets();

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = filePathCallback;
                try {
                    android.content.Intent intent = fileChooserParams.createIntent();
                    intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                    intent.putExtra(android.content.Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, "Dateiauswahl konnte nicht geöffnet werden", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri == null ? "" : uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try {
                        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW, uri);
                        startActivity(i);
                        return true;
                    } catch (Exception ignored) {}
                }
                return false;
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(this, webView), "AndroidBridge");
        ScoutJobService.ensureDefault(this);
        webView.loadUrl("file:///android_asset/index.html");
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || fileChooserCallback == null) return;
        Uri[] result = null;
        if (resultCode == Activity.RESULT_OK) {
            if (data != null && data.getClipData() != null) {
                android.content.ClipData clip = data.getClipData();
                result = new Uri[clip.getItemCount()];
                for (int i = 0; i < clip.getItemCount(); i++) result[i] = clip.getItemAt(i).getUri();
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(result);
        fileChooserCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private static class AndroidBridge {
        private static final String LOCAL_MODEL_NAME = "Qwen2.5-0.5B-Instruct";
        private static final String LOCAL_MODEL_FILE = "Qwen2.5-0.5B-Instruct_q8.task";
        private static final String LOCAL_MODEL_URL = "https://huggingface.co/litert-community/Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task?download=true";
        private static final long LOCAL_MODEL_BYTES = 546660344L;
        private static final String SUPABASE_URL = "https://teqirtttlcqzdnfrivxt.supabase.co";
        private static final String SUPABASE_PUBLISHABLE_KEY = "sb_publishable_seeDF_uigEU2lxqt2wZVHw_XVN0OCLv";
        private static final String CLOUD_PREFS = "autoforge_cloud_session";
        private static final String LOCAL_MODEL_SHA256 = "e608953f169aeb1bd7b9155fec2559825e08453fc209b84eda3a781ed0452fd2";
        private final Context context;
        private final WebView webView;

        AndroidBridge(Context context, WebView webView) {
            this.context = context;
            this.webView = webView;
        }

        @JavascriptInterface
        public void download(String url, String token, String filename) {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                if (token != null && !token.isEmpty()) request.addRequestHeader("X-AutoForge-Token", token);
                request.setTitle(filename == null || filename.isEmpty() ? "AutoForge-Projekt" : filename);
                request.setDescription("AutoForge exportiert das Projekt als ZIP");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        filename == null || filename.isEmpty() ? "AutoForge_Project.zip" : filename);
                DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
                dm.enqueue(request);
                toast("Download gestartet");
            } catch (Exception e) {
                toast("Download fehlgeschlagen: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public void exportBackup(String json, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new Date());
                    String filename = "AutoForge_Backup_" + stamp + ".json";
                    byte[] data = (json == null ? "{}" : json).getBytes(StandardCharsets.UTF_8);
                    String location;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                        values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AutoForge");
                        Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new IllegalStateException("Backup-Datei konnte nicht angelegt werden");
                        try (OutputStream os = context.getContentResolver().openOutputStream(uri)) {
                            if (os == null) throw new IllegalStateException("Backup-Datei konnte nicht geöffnet werden");
                            os.write(data);
                        }
                        location = "Downloads/AutoForge/" + filename;
                    } else {
                        File dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        if (dir == null) throw new IllegalStateException("Download-Ordner ist nicht verfügbar");
                        File out = new File(dir, filename);
                        try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(data); }
                        location = out.getAbsolutePath();
                    }
                    result.put("ok", true);
                    result.put("file", location);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void saveChatStore(String json, String currentId) {
            try {
                File dir = new File(context.getFilesDir(), "autoforge");
                if (!dir.isDirectory() && !dir.mkdirs()) throw new IllegalStateException("Chat-Ordner konnte nicht erstellt werden");
                File out = new File(dir, "chats.json");
                try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out), StandardCharsets.UTF_8))) {
                    w.write(json == null ? "[]" : json);
                }
                File cur = new File(dir, "current_chat.txt");
                try (BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(cur), StandardCharsets.UTF_8))) {
                    w.write(currentId == null ? "" : currentId);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void loadChatStore(String callbackId) {
            JSONObject result = new JSONObject();
            try {
                File dir = new File(context.getFilesDir(), "autoforge");
                File in = new File(dir, "chats.json");
                File cur = new File(dir, "current_chat.txt");
                result.put("ok", true);
                if (in.isFile()) result.put("json", readUtf8(in));
                if (cur.isFile()) result.put("currentId", readUtf8(cur).trim());
            } catch (Exception e) {
                try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
            }
            callback(callbackId, result.toString());
        }

        private String readUtf8(File f) throws Exception {
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line).append('\n');
            }
            return sb.toString();
        }

        @JavascriptInterface
        public void openExternal(String url) {
            try {
                android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            } catch (Exception e) {
                toast("Link konnte nicht geöffnet werden");
            }
        }

        @JavascriptInterface
        public void scanFreeAI(String callbackId) {
            new Thread(() -> callback(callbackId, ScoutScanner.scanAndStore(context))).start();
        }

        @JavascriptInterface
        public void getScoutCache(String callbackId) {
            callback(callbackId, ScoutScanner.cached(context));
        }

        @JavascriptInterface
        public void configureAutoScout(boolean enabled, int hours, String callbackId) {
            int safeHours = Math.max(1, Math.min(hours, 168));
            ScoutJobService.configure(context, enabled, safeHours);
            JSONObject result = new JSONObject();
            try {
                result.put("ok", true);
                result.put("enabled", enabled);
                result.put("hours", safeHours);
            } catch (Exception ignored) {}
            callback(callbackId, result.toString());
        }

        @JavascriptInterface
        public void getLocalModelStatus(String callbackId) {
            JSONObject result = new JSONObject();
            try {
                File model = localModelFile();
                result.put("ok", true);
                result.put("installed", model.isFile() && model.length() > 500_000_000L);
                result.put("name", LOCAL_MODEL_NAME);
                result.put("bytes", model.isFile() ? model.length() : 0L);
                result.put("expectedBytes", LOCAL_MODEL_BYTES);
                result.put("path", model.getAbsolutePath());
            } catch (Exception e) {
                try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
            }
            callback(callbackId, result.toString());
        }

        @JavascriptInterface
        public void downloadLocalModel(String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                File part = null;
                try {
                    File model = localModelFile();
                    if (model.isFile() && model.length() > 500_000_000L) {
                        result.put("ok", true); result.put("installed", true); result.put("path", model.getAbsolutePath());
                        callback(callbackId, result.toString());
                        return;
                    }
                    File dir = model.getParentFile();
                    if (dir != null && !dir.isDirectory() && !dir.mkdirs()) throw new IllegalStateException("Modellordner konnte nicht erstellt werden");
                    long free = dir == null ? 0L : dir.getUsableSpace();
                    if (free > 0 && free < 1_200_000_000L) throw new IllegalStateException("Zu wenig freier Speicher. Bitte mindestens 1,2 GB freigeben.");
                    part = new File(model.getAbsolutePath() + ".part");
                    if (part.exists()) part.delete();
                    HttpURLConnection c = (HttpURLConnection) new URL(LOCAL_MODEL_URL).openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000); c.setReadTimeout(120000);
                    c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.8.7");
                    int code = c.getResponseCode();
                    if (code < 200 || code >= 300) throw new IllegalStateException("Modelldownload HTTP " + code);
                    long total = c.getContentLengthLong();
                    if (total <= 0) total = LOCAL_MODEL_BYTES;
                    MessageDigest md = MessageDigest.getInstance("SHA-256");
                    long done = 0L, lastNotify = 0L;
                    try (InputStream in = new BufferedInputStream(c.getInputStream()); FileOutputStream out = new FileOutputStream(part)) {
                        byte[] buf = new byte[1024 * 256]; int n;
                        while ((n = in.read(buf)) >= 0) {
                            if (n == 0) continue;
                            out.write(buf, 0, n); md.update(buf, 0, n); done += n;
                            if (done - lastNotify >= 4L * 1024L * 1024L) {
                                lastNotify = done; localProgress(done, total);
                            }
                        }
                    } finally { c.disconnect(); }
                    localProgress(done, total);
                    String hash = toHex(md.digest());
                    if (!LOCAL_MODEL_SHA256.equalsIgnoreCase(hash)) throw new IllegalStateException("Modellprüfung fehlgeschlagen (SHA-256 stimmt nicht)");
                    if (!part.renameTo(model)) {
                        try (InputStream in = new FileInputStream(part); OutputStream out = new FileOutputStream(model)) {
                            byte[] buf = new byte[1024 * 256]; int n; while ((n = in.read(buf)) > 0) out.write(buf,0,n);
                        }
                        part.delete();
                    }
                    result.put("ok", true); result.put("installed", true); result.put("path", model.getAbsolutePath()); result.put("bytes", model.length());
                } catch (Exception e) {
                    if (part != null && part.exists()) part.delete();
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void localLlmChat(String prompt, String system, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                LlmInference llm = null;
                LlmInferenceSession session = null;
                try {
                    File model = localModelFile();
                    if (!model.isFile() || model.length() < 500_000_000L) throw new IllegalStateException("Lokales KI-Modell ist noch nicht installiert");
                    String p = prompt == null ? "" : prompt;
                    String sys = system == null ? "" : system;
                    if (p.length() > 18000) p = p.substring(0, 18000) + "\n[gekürzt]";
                    if (sys.length() > 3500) sys = sys.substring(0, 3500);
                    String formatted = "<|im_start|>system\n" + sys + "<|im_end|>\n<|im_start|>user\n" + p + "<|im_end|>\n<|im_start|>assistant\n";

                    // In MediaPipe Tasks GenAI 0.10.27, engine options only contain
                    // model/runtime settings. Sampling settings such as top-k and
                    // temperature belong to LlmInferenceSessionOptions.
                    LlmInference.LlmInferenceOptions options = LlmInference.LlmInferenceOptions.builder()
                            .setModelPath(model.getAbsolutePath())
                            .setMaxTokens(512)
                            .build();
                    llm = LlmInference.createFromOptions(context, options);

                    LlmInferenceSession.LlmInferenceSessionOptions sessionOptions =
                            LlmInferenceSession.LlmInferenceSessionOptions.builder()
                                    .setTopK(20)
                                    .setTopP(0.85f)
                                    .setTemperature(0.15f)
                                    .build();
                    session = LlmInferenceSession.createFromOptions(llm, sessionOptions);
                    session.addQueryChunk(formatted);
                    String text = session.generateResponse();
                    result.put("ok", true); result.put("text", text == null ? "" : text.trim()); result.put("model", LOCAL_MODEL_NAME + " · lokal");
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                } finally {
                    if (session != null) try { session.close(); } catch (Exception ignored) {}
                    if (llm != null) try { llm.close(); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        private File localModelFile() {
            File base = context.getExternalFilesDir(null);
            if (base == null) base = context.getFilesDir();
            return new File(new File(base, "models"), LOCAL_MODEL_FILE);
        }

        private void localProgress(long done, long total) {
            ((Activity) context).runOnUiThread(() -> webView.evaluateJavascript(
                    "window.AFLocalModelProgress&&window.AFLocalModelProgress(" + done + "," + total + ")", null));
        }

        private static String toHex(byte[] data) {
            StringBuilder sb = new StringBuilder(data.length * 2);
            for (byte b : data) sb.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return sb.toString();
        }

        @JavascriptInterface
        public void openRouterChat(String apiKey, String model, String prompt, String system, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenRouter-Key fehlt");
                    if (model == null || model.trim().isEmpty()) throw new IllegalArgumentException("Kostenloses Modell fehlt");
                    JSONObject body = new JSONObject();
                    body.put("model", model.trim());
                    body.put("temperature", 0.2);
                    JSONArray msgs = new JSONArray();
                    if (system != null && !system.trim().isEmpty()) {
                        msgs.put(new JSONObject().put("role", "system").put("content", system));
                    }
                    msgs.put(new JSONObject().put("role", "user").put("content", prompt));
                    body.put("messages", msgs);
                    String raw = postJson("https://openrouter.ai/api/v1/chat/completions", body.toString(), apiKey.trim());
                    JSONObject json = new JSONObject(raw);
                    JSONArray choices = json.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) throw new IllegalStateException("Keine Modellantwort");
                    String text = choices.getJSONObject(0).getJSONObject("message").optString("content", "");
                    result.put("ok", true);
                    result.put("text", text);
                    result.put("model", model.trim());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void openRouterChatWithAttachments(String apiKey, String model, String prompt, String system, String attachmentsJson, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("OpenRouter-Key fehlt");
                    if (model == null || model.trim().isEmpty()) throw new IllegalArgumentException("Kostenloses Modell fehlt");
                    JSONArray content = new JSONArray();
                    content.put(new JSONObject().put("type", "text").put("text", prompt));
                    JSONArray atts = new JSONArray(attachmentsJson == null || attachmentsJson.isEmpty() ? "[]" : attachmentsJson);
                    StringBuilder textAppend = new StringBuilder();
                    for (int i = 0; i < atts.length(); i++) {
                        JSONObject a = atts.optJSONObject(i);
                        if (a == null) continue;
                        String mime = a.optString("mime", "");
                        String name = a.optString("name", "Anhang");
                        String dataUrl = a.optString("dataUrl", "");
                        String text = a.optString("text", "");
                        if (mime.startsWith("image/") && !dataUrl.isEmpty()) {
                            content.put(new JSONObject().put("type", "image_url")
                                    .put("image_url", new JSONObject().put("url", dataUrl)));
                        } else if (!text.isEmpty()) {
                            textAppend.append("\n\n--- Datei: ").append(name).append(" ---\n").append(text);
                        } else {
                            textAppend.append("\n\n[Anhang: ").append(name).append("; Typ: ").append(mime).append("]");
                        }
                    }
                    if (textAppend.length() > 0) {
                        content.put(new JSONObject().put("type", "text").put("text", textAppend.toString()));
                    }
                    JSONObject body = new JSONObject();
                    body.put("model", model.trim());
                    body.put("temperature", 0.2);
                    JSONArray msgs = new JSONArray();
                    if (system != null && !system.trim().isEmpty()) msgs.put(new JSONObject().put("role", "system").put("content", system));
                    msgs.put(new JSONObject().put("role", "user").put("content", content));
                    body.put("messages", msgs);
                    String raw = postJson("https://openrouter.ai/api/v1/chat/completions", body.toString(), apiKey.trim());
                    JSONObject json = new JSONObject(raw);
                    JSONArray choices = json.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) throw new IllegalStateException("Keine Modellantwort");
                    Object contentOut = choices.getJSONObject(0).getJSONObject("message").opt("content");
                    String textOut = contentOut instanceof String ? (String) contentOut : String.valueOf(contentOut);
                    result.put("ok", true);
                    result.put("text", textOut);
                    result.put("model", model.trim());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void pollinationsImageModels(String apiKey, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    String raw = get("https://gen.pollinations.ai/image/models", apiKey == null ? "" : apiKey.trim());
                    JSONArray items = new JSONArray();
                    String t = raw.trim();
                    if (t.startsWith("[")) {
                        items = new JSONArray(t);
                    } else {
                        JSONObject root = new JSONObject(t);
                        JSONArray a = root.optJSONArray("data");
                        if (a == null) a = root.optJSONArray("models");
                        if (a == null) a = root.optJSONArray("items");
                        if (a != null) items = a;
                    }
                    result.put("ok", true);
                    result.put("items", items);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void pollinationsText(String apiKey, String model, String prompt, String system, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("Pollinations-Zugriffsschlüssel fehlt");
                    JSONObject body = new JSONObject();
                    body.put("model", model == null || model.trim().isEmpty() ? "openai-fast" : model.trim());
                    JSONArray msgs = new JSONArray();
                    if (system != null && !system.trim().isEmpty()) msgs.put(new JSONObject().put("role", "system").put("content", system));
                    msgs.put(new JSONObject().put("role", "user").put("content", prompt == null ? "" : prompt));
                    body.put("messages", msgs);
                    String raw = postJson("https://gen.pollinations.ai/v1/chat/completions", body.toString(), apiKey.trim());
                    JSONObject json = new JSONObject(raw);
                    JSONArray choices = json.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) throw new IllegalStateException("Keine Modellantwort");
                    String text = choices.getJSONObject(0).getJSONObject("message").optString("content", "");
                    result.put("ok", true); result.put("text", text); result.put("provider", "pollinations");
                    result.put("model", body.optString("model"));
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void pollinationsTextModels(String apiKey, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    String raw = get("https://gen.pollinations.ai/text/models", apiKey == null ? "" : apiKey.trim());
                    JSONArray items = new JSONArray();
                    String t = raw.trim();
                    if (t.startsWith("[")) {
                        items = new JSONArray(t);
                    } else {
                        JSONObject root = new JSONObject(t);
                        JSONArray a = root.optJSONArray("data");
                        if (a == null) a = root.optJSONArray("models");
                        if (a == null) a = root.optJSONArray("items");
                        if (a != null) items = a;
                    }
                    result.put("ok", true);
                    result.put("items", items);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void pollinationsVision(String apiKey, String model, String prompt, String system, String imagesJson, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("Pollinations-Zugriffsschlüssel fehlt");
                    JSONArray images = imagesJson == null || imagesJson.trim().isEmpty() ? new JSONArray() : new JSONArray(imagesJson);
                    if (images.length() == 0) throw new IllegalArgumentException("Kein Bild für Vision-Analyse übergeben");

                    JSONObject body = new JSONObject();
                    body.put("model", model == null || model.trim().isEmpty() ? "qwen-vision" : model.trim());
                    JSONArray msgs = new JSONArray();
                    if (system != null && !system.trim().isEmpty()) {
                        msgs.put(new JSONObject().put("role", "system").put("content", system));
                    }
                    JSONArray content = new JSONArray();
                    content.put(new JSONObject().put("type", "text").put("text", prompt == null || prompt.trim().isEmpty() ? "Beschreibe und analysiere dieses Bild präzise." : prompt));
                    for (int i = 0; i < images.length() && i < 6; i++) {
                        String dataUrl = images.optString(i, "");
                        if (dataUrl.startsWith("data:image/") || dataUrl.startsWith("https://") || dataUrl.startsWith("http://")) {
                            JSONObject iu = new JSONObject().put("url", dataUrl).put("detail", "high");
                            content.put(new JSONObject().put("type", "image_url").put("image_url", iu));
                        }
                    }
                    msgs.put(new JSONObject().put("role", "user").put("content", content));
                    body.put("messages", msgs);

                    String raw = postJson("https://gen.pollinations.ai/v1/chat/completions", body.toString(), apiKey.trim());
                    JSONObject json = new JSONObject(raw);
                    JSONArray choices = json.optJSONArray("choices");
                    if (choices == null || choices.length() == 0) throw new IllegalStateException("Keine Vision-Modellantwort");
                    Object contentOut = choices.getJSONObject(0).getJSONObject("message").opt("content");
                    String text;
                    if (contentOut instanceof String) {
                        text = (String) contentOut;
                    } else if (contentOut instanceof JSONArray) {
                        StringBuilder sb = new StringBuilder();
                        JSONArray arr = (JSONArray) contentOut;
                        for (int i = 0; i < arr.length(); i++) {
                            Object part = arr.opt(i);
                            if (part instanceof JSONObject) {
                                JSONObject po = (JSONObject) part;
                                String pt = po.optString("text", po.optString("content", ""));
                                if (!pt.isEmpty()) { if (sb.length() > 0) sb.append('\n'); sb.append(pt); }
                            } else if (part != null) {
                                if (sb.length() > 0) sb.append('\n'); sb.append(String.valueOf(part));
                            }
                        }
                        text = sb.toString();
                    } else {
                        text = contentOut == null ? "" : String.valueOf(contentOut);
                    }
                    if (text.trim().isEmpty()) throw new IllegalStateException("Vision-Modell lieferte keinen Text");
                    result.put("ok", true);
                    result.put("text", text);
                    result.put("provider", "pollinations");
                    result.put("model", body.optString("model"));
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void pollinationsImageGenerate(String apiKey, String model, String prompt, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("Pollinations-Zugriffsschlüssel fehlt");
                    JSONObject body = new JSONObject();
                    body.put("prompt", prompt == null ? "" : prompt);
                    body.put("model", model == null || model.trim().isEmpty() ? "zimage" : model.trim());
                    body.put("n", 1); body.put("size", "1024x1024"); body.put("response_format", "b64_json");
                    String raw = postJson("https://gen.pollinations.ai/v1/images/generations", body.toString(), apiKey.trim());
                    JSONObject json = new JSONObject(raw);
                    JSONArray data = json.optJSONArray("data");
                    if (data == null || data.length() == 0) throw new IllegalStateException("Kein Bild erhalten");
                    JSONObject first = data.getJSONObject(0);
                    String b64 = first.optString("b64_json", "");
                    String url = first.optString("url", "");
                    result.put("ok", true); result.put("provider", "pollinations"); result.put("model", body.optString("model"));
                    if (!b64.isEmpty()) result.put("dataUrl", "data:image/png;base64," + b64);
                    if (!url.isEmpty()) result.put("url", url);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void pollinationsImageEdit(String apiKey, String model, String prompt, String imageDataUrl, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("Pollinations-Zugriffsschlüssel fehlt");
                    if (imageDataUrl == null || !imageDataUrl.startsWith("data:image/")) throw new IllegalArgumentException("Kein gültiges Bild übergeben");
                    String chosenModel = model == null || model.trim().isEmpty() ? "kontext" : model.trim();
                    String raw = postMultipartImageEdit("https://gen.pollinations.ai/v1/images/edits", apiKey.trim(), chosenModel, prompt == null ? "" : prompt, imageDataUrl);
                    JSONObject json = new JSONObject(raw);
                    JSONArray data = json.optJSONArray("data");
                    if (data == null || data.length() == 0) throw new IllegalStateException("Kein bearbeitetes Bild erhalten");
                    JSONObject first = data.getJSONObject(0);
                    String b64 = first.optString("b64_json", "");
                    String url = first.optString("url", "");
                    result.put("ok", true); result.put("provider", "pollinations"); result.put("model", chosenModel);
                    if (!b64.isEmpty()) result.put("dataUrl", "data:image/png;base64," + b64);
                    if (!url.isEmpty()) result.put("url", url);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void saveResumeState(String jobId, String stateJson, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    File dir = resumeDir(jobId);
                    if (!dir.mkdirs() && !dir.isDirectory()) throw new IllegalStateException("Resume-Ordner konnte nicht erstellt werden");
                    File out = new File(dir, "state.json");
                    try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out), StandardCharsets.UTF_8))) {
                        bw.write(stateJson == null ? "{}" : stateJson);
                    }
                    result.put("ok", true);
                    result.put("path", out.getAbsolutePath());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void saveResumeMedia(String jobId, String dataUrl, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    if (dataUrl == null || !dataUrl.startsWith("data:")) throw new IllegalArgumentException("Kein eingebettetes Medium übergeben");
                    int comma = dataUrl.indexOf(',');
                    if (comma < 0) throw new IllegalArgumentException("Ungültiges Data-URL-Format");
                    String header = dataUrl.substring(0, comma).toLowerCase(Locale.ROOT);
                    String b64 = dataUrl.substring(comma + 1);
                    String ext = header.contains("image/jpeg") ? ".jpg" : header.contains("image/webp") ? ".webp" : header.contains("image/gif") ? ".gif" : ".png";
                    byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                    File dir = resumeDir(jobId);
                    if (!dir.mkdirs() && !dir.isDirectory()) throw new IllegalStateException("Resume-Ordner konnte nicht erstellt werden");
                    File out = new File(dir, "checkpoint_media" + ext);
                    try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(bytes); }
                    result.put("ok", true);
                    result.put("path", out.getAbsolutePath());
                    result.put("bytes", out.length());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void loadResumeState(String jobId, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    File in = new File(resumeDir(jobId), "state.json");
                    if (!in.isFile()) { result.put("ok", true); result.put("found", false); callback(callbackId, result.toString()); return; }
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(in), StandardCharsets.UTF_8))) {
                        String line; while ((line = br.readLine()) != null) sb.append(line).append('\n');
                    }
                    result.put("ok", true); result.put("found", true); result.put("state", sb.toString().trim());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        private File resumeDir(String jobId) {
            String safe = safeName(jobId == null || jobId.trim().isEmpty() ? "job" : jobId);
            File base = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (base == null) base = context.getFilesDir();
            return new File(base, "AutoForge/Resume/" + safe);
        }

        @JavascriptInterface
        public void cloudBootstrap(String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    JSONObject session = ensureCloudSession();
                    JSONObject req = new JSONObject();
                    req.put("action", "bootstrap");
                    req.put("locale", Locale.getDefault().toLanguageTag());
                    JSONObject remote = new JSONObject(gatewayRequest(req.toString(), session.optString("access_token")));
                    result.put("ok", true);
                    result.put("user_id", session.optString("user_id"));
                    result.put("anonymous", true);
                    result.put("gateway", remote);
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void cloudSessionStatus(String callbackId) {
            JSONObject result = new JSONObject();
            try {
                SharedPreferences p = context.getSharedPreferences(CLOUD_PREFS, Context.MODE_PRIVATE);
                long exp = p.getLong("expires_at", 0L);
                result.put("ok", true);
                result.put("signed_in", !p.getString("refresh_token", "").isEmpty());
                result.put("user_id", p.getString("user_id", ""));
                result.put("expires_at", exp);
            } catch (Exception e) {
                try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
            }
            callback(callbackId, result.toString());
        }

        @JavascriptInterface
        public void cloudRequest(String payloadJson, String callbackId) {
            new Thread(() -> {
                JSONObject result;
                try {
                    JSONObject session = ensureCloudSession();
                    String raw;
                    try {
                        raw = gatewayRequest(payloadJson == null ? "{}" : payloadJson, session.optString("access_token"));
                    } catch (Exception first) {
                        if (String.valueOf(first.getMessage()).contains("HTTP 401")) {
                            clearCloudSession();
                            session = ensureCloudSession();
                            raw = gatewayRequest(payloadJson == null ? "{}" : payloadJson, session.optString("access_token"));
                        } else throw first;
                    }
                    result = new JSONObject(raw);
                    result.put("_cloud_ok", true);
                } catch (Exception e) {
                    result = new JSONObject();
                    try { result.put("_cloud_ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void cloudSearchRequest(String payloadJson, String callbackId) {
            new Thread(() -> {
                JSONObject result;
                try {
                    JSONObject session = ensureCloudSession();
                    String raw;
                    try {
                        raw = edgeFunctionRequest("autoforge-search", payloadJson == null ? "{}" : payloadJson, session.optString("access_token"));
                    } catch (Exception first) {
                        if (String.valueOf(first.getMessage()).contains("HTTP 401")) {
                            clearCloudSession();
                            session = ensureCloudSession();
                            raw = edgeFunctionRequest("autoforge-search", payloadJson == null ? "{}" : payloadJson, session.optString("access_token"));
                        } else throw first;
                    }
                    result = new JSONObject(raw);
                    result.put("_cloud_ok", true);
                } catch (Exception e) {
                    result = new JSONObject();
                    try { result.put("_cloud_ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void cloudRemoteRequest(String payloadJson, String callbackId) {
            new Thread(() -> {
                JSONObject result;
                try {
                    JSONObject session = ensureCloudSession();
                    String raw;
                    try {
                        raw = edgeFunctionRequest("autoforge-remote", payloadJson == null ? "{}" : payloadJson, session.optString("access_token"));
                    } catch (Exception first) {
                        if (String.valueOf(first.getMessage()).contains("HTTP 401")) {
                            clearCloudSession();
                            session = ensureCloudSession();
                            raw = edgeFunctionRequest("autoforge-remote", payloadJson == null ? "{}" : payloadJson, session.optString("access_token"));
                        } else throw first;
                    }
                    result = new JSONObject(raw);
                    result.put("_cloud_ok", true);
                } catch (Exception e) {
                    result = new JSONObject();
                    try { result.put("_cloud_ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void cloudReset(String callbackId) {
            clearCloudSession();
            JSONObject result = new JSONObject();
            try { result.put("ok", true); } catch (Exception ignored) {}
            callback(callbackId, result.toString());
        }

        private JSONObject ensureCloudSession() throws Exception {
            SharedPreferences p = context.getSharedPreferences(CLOUD_PREFS, Context.MODE_PRIVATE);
            long now = System.currentTimeMillis() / 1000L;
            String access = p.getString("access_token", "");
            String refresh = p.getString("refresh_token", "");
            long expiresAt = p.getLong("expires_at", 0L);
            if (!access.isEmpty() && expiresAt > now + 120L) return sessionInfo(p);
            if (!refresh.isEmpty()) {
                try {
                    JSONObject body = new JSONObject();
                    body.put("refresh_token", refresh);
                    JSONObject refreshed = new JSONObject(authRequest("/auth/v1/token?grant_type=refresh_token", body.toString()));
                    persistCloudSession(refreshed);
                    return sessionInfo(context.getSharedPreferences(CLOUD_PREFS, Context.MODE_PRIVATE));
                } catch (Exception ignored) {
                    clearCloudSession();
                }
            }
            JSONObject body = new JSONObject();
            JSONObject data = new JSONObject();
            data.put("client", "autoforge-mobile");
            data.put("app_version", "0.8.7");
            body.put("data", data);
            JSONObject created = new JSONObject(authRequest("/auth/v1/signup", body.toString()));
            persistCloudSession(created);
            return sessionInfo(context.getSharedPreferences(CLOUD_PREFS, Context.MODE_PRIVATE));
        }

        private JSONObject sessionInfo(SharedPreferences p) throws Exception {
            JSONObject out = new JSONObject();
            out.put("access_token", p.getString("access_token", ""));
            out.put("refresh_token", p.getString("refresh_token", ""));
            out.put("user_id", p.getString("user_id", ""));
            out.put("expires_at", p.getLong("expires_at", 0L));
            return out;
        }

        private void persistCloudSession(JSONObject session) throws Exception {
            String access = session.optString("access_token", "");
            String refresh = session.optString("refresh_token", "");
            if (access.isEmpty() || refresh.isEmpty()) throw new IllegalStateException("Supabase hat keine gültige Sitzung geliefert");
            long now = System.currentTimeMillis() / 1000L;
            long expiresAt = session.optLong("expires_at", 0L);
            if (expiresAt <= now) expiresAt = now + Math.max(300L, session.optLong("expires_in", 3600L));
            JSONObject user = session.optJSONObject("user");
            String userId = user == null ? "" : user.optString("id", "");
            context.getSharedPreferences(CLOUD_PREFS, Context.MODE_PRIVATE).edit()
                    .putString("access_token", access)
                    .putString("refresh_token", refresh)
                    .putString("user_id", userId)
                    .putLong("expires_at", expiresAt)
                    .apply();
        }

        private void clearCloudSession() {
            context.getSharedPreferences(CLOUD_PREFS, Context.MODE_PRIVATE).edit().clear().apply();
        }

        private String authRequest(String path, String body) throws Exception {
            HttpURLConnection c = (HttpURLConnection) new URL(SUPABASE_URL + path).openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
            c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.8.7");
            try (OutputStream os = c.getOutputStream()) { os.write((body == null ? "{}" : body).getBytes(StandardCharsets.UTF_8)); }
            return readResponse(c);
        }

        private String edgeFunctionRequest(String functionName, String body, String accessToken) throws Exception {
            String safeFn = functionName == null ? "" : functionName.replaceAll("[^a-zA-Z0-9_-]", "");
            if (safeFn.isEmpty()) throw new IllegalArgumentException("Edge Function fehlt");
            HttpURLConnection c = (HttpURLConnection) new URL(SUPABASE_URL + "/functions/v1/" + safeFn).openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(120000); c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("apikey", SUPABASE_PUBLISHABLE_KEY);
            c.setRequestProperty("Authorization", "Bearer " + accessToken);
            c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.8.7");
            try (OutputStream os = c.getOutputStream()) { os.write((body == null ? "{}" : body).getBytes(StandardCharsets.UTF_8)); }
            return readResponse(c);
        }

        private String gatewayRequest(String body, String accessToken) throws Exception {
            return edgeFunctionRequest("autoforge-gateway", body, accessToken);
        }

        @JavascriptInterface
        public void saveProject(String projectName, String projectJson, String callbackId) {
            new Thread(() -> {
                JSONObject result = new JSONObject();
                try {
                    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.GERMANY).format(new Date());
                    String safe = safeName(projectName == null ? "Projekt" : projectName);
                    File rootBase = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                    if (rootBase == null) rootBase = context.getFilesDir();
                    File root = new File(rootBase, "AutoForge/" + stamp + "_" + safe);
                    if (!root.mkdirs() && !root.isDirectory()) throw new IllegalStateException("Projektordner konnte nicht erstellt werden");
                    JSONObject project = parseProjectJson(projectJson);
                    JSONArray files = project.optJSONArray("files");
                    int written = 0;
                    if (files != null) {
                        String rootCanonical = root.getCanonicalPath() + File.separator;
                        for (int i = 0; i < files.length() && i < 80; i++) {
                            JSONObject f = files.optJSONObject(i);
                            if (f == null) continue;
                            String rel = f.optString("path", "").replace('\\', '/');
                            if (rel.isEmpty() || rel.startsWith("/") || rel.contains("../")) continue;
                            File out = new File(root, rel);
                            String outCanonical = out.getCanonicalPath();
                            if (!outCanonical.startsWith(rootCanonical)) continue;
                            File parent = out.getParentFile();
                            if (parent != null) parent.mkdirs();
                            try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out), StandardCharsets.UTF_8))) {
                                bw.write(f.optString("content", ""));
                            }
                            written++;
                        }
                    }
                    if (written == 0) {
                        File fallback = new File(root, "AUTOFORGE_RESPONSE.txt");
                        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fallback), StandardCharsets.UTF_8))) {
                            bw.write(projectJson);
                        }
                        written = 1;
                    }
                    File zip = new File(root.getParentFile(), root.getName() + ".zip");
                    zipFolder(root, zip, root);
                    result.put("ok", true);
                    result.put("files", written);
                    result.put("folder", root.getAbsolutePath());
                    result.put("zip", zip.getAbsolutePath());
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
                }
                callback(callbackId, result.toString());
            }).start();
        }

        @JavascriptInterface
        public void toast(String message) {
            ((Activity) context).runOnUiThread(() -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
        }

        private void callback(String callbackId, String json) {
            ((Activity) context).runOnUiThread(() -> {
                String js = "window.AFBridgeResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(json) + ")";
                webView.evaluateJavascript(js, null);
            });
        }

        private static double number(Object v) {
            try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return 0d; }
        }

        private static String classify(String text) {
            String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
            if (t.contains("coder") || t.contains("coding") || t.contains("code")) return "coding";
            if (t.contains("image") || t.contains("diffusion") || t.contains("flux")) return "image";
            if (t.contains("video")) return "video";
            if (t.contains("audio") || t.contains("speech") || t.contains("music")) return "audio";
            if (t.contains("3d") || t.contains("mesh")) return "3d";
            if (t.contains("agent")) return "agents";
            if (t.contains("vision") || t.contains("multimodal")) return "vision";
            return "general";
        }

        private static String get(String url, String token) throws Exception {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(12000); c.setReadTimeout(25000); c.setRequestMethod("GET");
            c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.8.7");
            if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
            return readResponse(c);
        }

        private static String postJson(String url, String body, String token) throws Exception {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(120000); c.setRequestMethod("POST");
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.8.7");
            if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);
            try (OutputStream os = c.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
            return readResponse(c);
        }

        private static String postMultipartImageEdit(String url, String token, String model, String prompt, String imageDataUrl) throws Exception {
            String boundary = "----AutoForge" + System.currentTimeMillis();
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000); c.setReadTimeout(180000); c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.8.7");
            if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization", "Bearer " + token);

            int comma = imageDataUrl.indexOf(',');
            if (comma < 0) throw new IllegalArgumentException("Ungültiges Bildformat");
            String header = imageDataUrl.substring(0, comma).toLowerCase(Locale.ROOT);
            String mime = header.contains("image/jpeg") ? "image/jpeg" : header.contains("image/webp") ? "image/webp" : "image/png";
            String filename = mime.equals("image/jpeg") ? "input.jpg" : mime.equals("image/webp") ? "input.webp" : "input.png";
            byte[] imageBytes = Base64.decode(imageDataUrl.substring(comma + 1), Base64.DEFAULT);

            try (OutputStream os = c.getOutputStream()) {
                writeMultipartField(os, boundary, "prompt", prompt == null ? "" : prompt);
                writeMultipartField(os, boundary, "model", model == null || model.isEmpty() ? "kontext" : model);
                writeMultipartField(os, boundary, "size", "1024x1024");
                writeMultipartField(os, boundary, "response_format", "b64_json");
                String head = "--" + boundary + "\r\n" +
                        "Content-Disposition: form-data; name=\"image\"; filename=\"" + filename + "\"\r\n" +
                        "Content-Type: " + mime + "\r\n\r\n";
                os.write(head.getBytes(StandardCharsets.UTF_8));
                os.write(imageBytes);
                os.write("\r\n".getBytes(StandardCharsets.UTF_8));
                os.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
            }
            return readResponse(c);
        }

        private static void writeMultipartField(OutputStream os, String boundary, String name, String value) throws Exception {
            String part = "--" + boundary + "\r\n" +
                    "Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" +
                    (value == null ? "" : value) + "\r\n";
            os.write(part.getBytes(StandardCharsets.UTF_8));
        }

        private static String readResponse(HttpURLConnection c) throws Exception {
            int code = c.getResponseCode();
            InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            if (is == null) throw new IllegalStateException("HTTP " + code);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) sb.append(line).append('\n');
            }
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + sb.toString().trim());
            return sb.toString();
        }

        private static JSONObject parseProjectJson(String text) throws Exception {
            String s = text == null ? "" : text.trim();
            if (s.startsWith("```")) {
                s = s.replaceFirst("^```(?:json)?\\s*", "");
                s = s.replaceFirst("\\s*```$", "");
            }
            int a = s.indexOf('{'); int b = s.lastIndexOf('}');
            if (a >= 0 && b > a) s = s.substring(a, b + 1);
            return new JSONObject(s);
        }

        private static String safeName(String s) {
            String x = s.replaceAll("[^a-zA-Z0-9äöüÄÖÜß_-]+", "_").replaceAll("^_+|_+$", "");
            if (x.isEmpty()) x = "Projekt";
            return x.length() > 45 ? x.substring(0, 45) : x;
        }

        private static void zipFolder(File current, File zipFile, File root) throws Exception {
            try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
                addZip(current, root, zos);
            }
        }

        private static void addZip(File file, File root, ZipOutputStream zos) throws Exception {
            if (file.isDirectory()) {
                File[] children = file.listFiles();
                if (children != null) for (File child : children) addZip(child, root, zos);
                return;
            }
            String name = root.toURI().relativize(file.toURI()).getPath();
            zos.putNextEntry(new ZipEntry(name));
            try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
                byte[] buf = new byte[8192]; int n;
                while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
            }
            zos.closeEntry();
        }
    }
}
