# Mobile 0.13.7 / Build 48

PC-Protokoll unter Mein PC → PC steuern: Datum, Zielrechner und Ergebnis, letzte 100 Einträge nur auf diesem Handy. PC-Befehle aus einem bestehenden privaten Chat bleiben dort nach Verlauf-Aktualisierung/App-Neustart sichtbar; kein Upload dieser Protokolle an Cloud-KI oder Familie. Befehle aus einem noch leeren Chat sind im PC-Protokoll auffindbar, aber eröffnen keinen KI-Chat.

Bekannte offene Power-Aufträge behalten ihre ID lokal. Offenen Auftrag prüfen liest nur den bestehenden Auftrag; Auftrag abbrechen sendet einen gezielten Abbruch. Solange ein solcher Auftrag ungeklärt ist, wird kein weiterer Power-Auftrag angelegt. Der normale KI-Chat bleibt erreichbar. Ein Abbruch macht bereits ausgeführte Windows-Aktionen nicht rückgängig. Ein während der Übertragung vollständig verlorener Auftrag ohne empfangene ID kann weiterhin nicht eindeutig wiedergefunden werden. Protokolle lassen sich lokal löschen; ein offener Auftrag bleibt erhalten.

PC-Wechsel während eines Auftrags ändert dessen ursprüngliches Ziel nicht. Familienchats erhalten weder Protokolle noch Steuerungsrechte. Desktop 0.6.3 bleibt aktuell. Keine Power-Aktion an ROBERT zu Testzwecken ausgeführt. Browserprüfung simuliert Android und Cloud-Power-Aufträge.
