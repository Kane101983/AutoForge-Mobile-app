function showLearningTool(tool=''){
 $('learningChoice').hidden=!!tool;$('learningBack').hidden=!tool;
 $('practiceTools').hidden=tool!=='practice';$('researchTools').hidden=tool!=='research';
 document.querySelector('main').scrollTop=0;
}
function openPage(page){
 document.body.dataset.page=page;
 $('settings').open=false;
 document.querySelectorAll('main>section').forEach(s=>s.hidden=s.id!==page);
 document.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
 $('backChat').hidden=page==='chat';document.querySelector('main').scrollTop=0;
 if(page==='learning'){showLearningTool();if(device&&pcOnline&&!pending)action(learning);else notice('Recherche und Üben benötigen deinen verbundenen PC. Der Cloud-Chat funktioniert weiterhin.');}
 if(page==='projects'){if(device&&pcOnline&&!pending)action(projects);else notice('Programme erstellen benötigt deinen verbundenen PC. Über ← Chat kommst du zurück.');}
}
document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>openPage(b.dataset.page));
$('backChat').onclick=()=>openPage('chat');
$('closeMenu').onclick=()=>{$('settings').open=false;};
$('improveMobile').onclick=()=>openPage('learning');
$('choosePractice').onclick=()=>showLearningTool('practice');
$('chooseResearch').onclick=()=>showLearningTool('research');
$('learningBack').onclick=()=>showLearningTool();
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('settings').open=false;});
document.body.dataset.page='chat';
