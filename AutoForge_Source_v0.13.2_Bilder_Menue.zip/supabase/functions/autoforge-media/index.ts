import {media} from './handler.mjs';
const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization,apikey,content-type','Access-Control-Allow-Methods':'POST,OPTIONS'};
const last=new Map<string,number>();
Deno.serve(async(req:Request)=>{
 const json=(d:unknown,status=200)=>new Response(JSON.stringify(d),{status,headers:{...cors,'Content-Type':'application/json'}});
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 if(req.method!=='POST')return json({error:'POST erforderlich'},405);
 try{
  const raw=await req.text();if(raw.length>1100000)return json({error:'Bildauftrag zu groß'},413);
  const body=JSON.parse(raw),key=Deno.env.get('POLLINATIONS_API_KEY');
  const fetchJSON=async(url:string,init:RequestInit={})=>{const r=await fetch(url,{...init,signal:AbortSignal.timeout(65000)});if(!r.ok)throw Error('Bildanbieter momentan nicht verfügbar (HTTP '+r.status+').');return r.json();};
  const result=await media(body,{
   authenticate:async()=>{const r=await fetch(Deno.env.get('SUPABASE_URL')+'/auth/v1/user',{headers:{apikey:Deno.env.get('SUPABASE_ANON_KEY')||'',Authorization:req.headers.get('Authorization')||''}});if(!r.ok)return false;const u=await r.json();if(!u.id)return false;const now=Date.now();if(now-(last.get(u.id)||0)<20000)throw Error('Bitte zwischen Bildaufträgen 20 Sekunden warten.');last.set(u.id,now);if(last.size>10000)last.clear();return true;},
   catalog:()=>fetchJSON('https://gen.pollinations.ai/image/models'),
   generate:async(model:string,b:any)=>{
    if(!key)throw Error('Bildanbieter ist noch nicht eingerichtet.');
    const headers={Authorization:'Bearer '+key};let r;
    if(b.mode==='edit'){
     const [prefix,base64]=b.image.split(',');const bytes=Uint8Array.from(atob(base64),(c:string)=>c.charCodeAt(0));
     const fd=new FormData();fd.append('image',new Blob([bytes],{type:prefix.slice(5).split(';')[0]}),'input.jpg');fd.append('model',model);fd.append('prompt',b.prompt);fd.append('response_format','url');fd.append('size','1024x1024');
     r=await fetchJSON('https://gen.pollinations.ai/v1/images/edits',{method:'POST',headers,body:fd});
    }else r=await fetchJSON('https://gen.pollinations.ai/v1/images/generations',{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({model,prompt:b.prompt,n:1,size:'1024x1024',response_format:'url'})});
    return r.data?.[0];
   }
  });return json(result,result.status);
 }catch(e){return json({ok:false,error:e instanceof Error?e.message:'Bildauftrag fehlgeschlagen.'},502);}
});
