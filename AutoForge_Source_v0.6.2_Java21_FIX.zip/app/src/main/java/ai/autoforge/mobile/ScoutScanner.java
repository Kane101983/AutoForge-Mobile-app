package ai.autoforge.mobile;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Background-safe scanner for public/free AI catalogs. */
public final class ScoutScanner {
    private ScoutScanner() {}

    public static String scanAndStore(Context context) {
        JSONObject result = new JSONObject();
        JSONArray items = new JSONArray();
        JSONArray errors = new JSONArray();
        try {
            try {
                JSONObject or = new JSONObject(get("https://openrouter.ai/api/v1/models"));
                JSONArray data = or.optJSONArray("data");
                if (data != null) {
                    for (int i = 0; i < data.length() && items.length() < 80; i++) {
                        JSONObject m = data.optJSONObject(i);
                        if (m == null) continue;
                        JSONObject p = m.optJSONObject("pricing");
                        double in = number(p == null ? null : p.opt("prompt"));
                        double out = number(p == null ? null : p.opt("completion"));
                        String id = m.optString("id", "");
                        if (!(id.endsWith(":free") || (in == 0d && out == 0d))) continue;
                        JSONObject x = new JSONObject();
                        x.put("uid", "openrouter:" + id);
                        x.put("source", "openrouter");
                        x.put("name", m.optString("name", id));
                        x.put("model_id", id);
                        x.put("category", classify(id + " " + m.optString("description", "")));
                        x.put("free_type", "free-cloud/rate-limited");
                        x.put("requires_key", true);
                        x.put("url", "https://openrouter.ai/" + id);
                        items.put(x);
                    }
                }
            } catch (Exception e) {
                errors.put("OpenRouter: " + e.getMessage());
            }

            try {
                String rawPollinations = get("https://gen.pollinations.ai/v1/models");
                JSONArray data;
                String trimmedPollinations = rawPollinations.trim();
                if (trimmedPollinations.startsWith("{")) data = new JSONObject(trimmedPollinations).optJSONArray("data");
                else data = new JSONArray(trimmedPollinations);
                if (data == null) data = new JSONArray();
                for (int i = 0; i < data.length() && items.length() < 120; i++) {
                    JSONObject m = data.optJSONObject(i);
                    if (m == null) continue;
                    String id = m.optString("id", m.optString("name", ""));
                    if (id.isEmpty()) continue;
                    JSONObject x = new JSONObject();
                    x.put("uid", "pollinations:" + id);
                    x.put("source", "pollinations");
                    x.put("name", id);
                    x.put("model_id", id);
                    x.put("category", classify(id + " " + m.optString("description", "")));
                    x.put("free_type", "free-credits-or-quest / provider-controlled");
                    x.put("requires_key", true);
                    x.put("adapter", "pollinations");
                    x.put("url", "https://pollinations.ai");
                    items.put(x);
                }
            } catch (Exception e) {
                errors.put("Pollinations: " + e.getMessage());
            }

            try {
                String hfUrl = "https://huggingface.co/api/models?sort=lastModified&direction=-1&limit=80&full=true";
                JSONArray data = new JSONArray(get(hfUrl));
                for (int i = 0; i < data.length() && items.length() < 140; i++) {
                    JSONObject m = data.optJSONObject(i);
                    if (m == null) continue;
                    String id = m.optString("id", m.optString("modelId", ""));
                    if (id.isEmpty()) continue;
                    JSONObject x = new JSONObject();
                    x.put("uid", "huggingface:" + id);
                    x.put("source", "huggingface");
                    x.put("name", id);
                    x.put("category", classify(id + " " + m.optString("pipeline_tag", "")));
                    x.put("free_type", "open-weights/local-or-cloud");
                    x.put("requires_key", false);
                    x.put("url", "https://huggingface.co/" + id);
                    x.put("downloads", m.optLong("downloads", 0));
                    items.put(x);
                }
            } catch (Exception e) {
                errors.put("Hugging Face: " + e.getMessage());
            }

            result.put("ok", true);
            result.put("items", items);
            result.put("errors", errors);
            result.put("scanned_at", System.currentTimeMillis());
        } catch (Exception e) {
            try { result.put("ok", false); result.put("error", e.getMessage()); } catch (Exception ignored) {}
        }

        try {
            SharedPreferences prefs = context.getSharedPreferences("autoforge", Context.MODE_PRIVATE);
            prefs.edit()
                    .putString("scout_cache", result.toString())
                    .putLong("scout_last_scan", System.currentTimeMillis())
                    .apply();
        } catch (Exception ignored) {}
        return result.toString();
    }

    public static String cached(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("autoforge", Context.MODE_PRIVATE);
        return prefs.getString("scout_cache", "{\"ok\":true,\"items\":[],\"cached\":true}");
    }

    private static double number(Object v) {
        try { return Double.parseDouble(String.valueOf(v)); } catch (Exception e) { return 0d; }
    }

    private static String classify(String text) {
        String t = text == null ? "" : text.toLowerCase(Locale.ROOT);
        if (t.contains("coder") || t.contains("coding") || t.contains("code")) return "coding";
        if (t.contains("image") || t.contains("diffusion") || t.contains("flux")) return "image";
        if (t.contains("video")) return "video";
        if (t.contains("audio") || t.contains("speech") || t.contains("music")) return "audio";
        if (t.contains("3d") || t.contains("mesh")) return "3d";
        if (t.contains("agent")) return "agents";
        if (t.contains("vision") || t.contains("multimodal")) return "vision";
        return "general";
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(25000);
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "AutoForge-Mobile/0.6.1");
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        if (is == null) throw new IllegalStateException("HTTP " + code);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line; while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + sb.toString().trim());
        return sb.toString();
    }
}
