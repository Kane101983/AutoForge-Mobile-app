const $=id=>document.getElementById(id);let cb=0;const callbacks={};let device='',chat='',busy=false,pending=null,followOutput=true,shownChat='',chatRows=[],practiceRunning=false;
try{const saved=JSON.parse(localStorage.getItem('af_studio_selection')||'{}');device=saved.device||'';chat=saved.chat||'';pending=JSON.parse(localStorage.getItem('af_studio_pending')||'null');}catch{}
window.AFBridgeResult=(id,json)=>{const p=callbacks[id];if(!p)return;delete callbacks[id];clearTimeout(p.timer);try{p.resolve(JSON.parse(json));}catch(e){p.reject(e);}};
function bridge(method,...args){return new Promise((resolve,reject)=>{if(!window.AndroidBridge||typeof AndroidBridge[method]!=='function')return reject(Error('Android-Verbindung fehlt.'));const id='studio'+(++cb),timer=setTimeout(()=>{delete callbacks[id];reject(Error('Verbindung hat zu lange gedauert.'));},90000);callbacks[id]={resolve,reject,timer};AndroidBridge[method](...args,id);});}
async function remote(action,extra={}){const data=await bridge('cloudRemoteRequest',JSON.stringify({action,...extra}));if(data._cloud_ok===false||data.error)throw Error(data.error||'Cloud nicht erreichbar.');return data;}
function element(tag,text,cls){const n=document.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;}
function save(){localStorage.setItem('af_studio_selection',JSON.stringify({device,chat}));}
function notice(text){$('notice').textContent=text;}
function controls(){for(const id of ['send','newChat','chatSelect','deviceSelect','build','learnStart','remember','practiceStart','practiceRefresh','practiceStop'])$(id).disabled=busy||!!pending;$('practiceStart').disabled=busy||!!pending||practiceRunning;}
async function poll(){for(let i=0;i<220;i++){const {job}=await remote('job_status',{job_id:pending.id});if(job?.status==='completed'){pending=null;localStorage.removeItem('af_studio_pending');const result=job.result||{};if(result.run)renderPractice(result);return result;}if(['failed','cancelled','waiting_approval'].includes(job?.status)){pending=null;localStorage.removeItem('af_studio_pending');throw Error(job.error||'Auftrag nicht abgeschlossen.');}notice(job?.status==='queued'?'Wartet auf deinen PC …':'AutoForge arbeitet auf ROBERT …');await new Promise(r=>setTimeout(r,1500));}throw Error('Dauert länger. Aktualisieren holt denselben Auftrag ab.');}
async function job(operation,extra={}){if(pending)throw Error('Bitte zuerst Aktualisieren: ein Auftrag ist noch offen.');if(!device)throw Error('Bitte zuerst deinen PC verbinden.');const {job}=await remote('create_job',{device_id:device,job_type:'project_task',instruction:'AutoForge Studio · '+operation,payload:{kind:'local_brain',operation,...extra}});if(!job?.id)throw Error('Auftrag nicht angelegt.');pending={id:job.id,operation,device};localStorage.setItem('af_studio_pending',JSON.stringify(pending));return poll();}
async function action(fn){if(busy)return;busy=true;controls();try{await fn();}catch(e){notice(e.message);}finally{busy=false;controls();}}
async function loadDevices(){const {devices=[]}=await remote('list_devices');$('deviceSelect').replaceChildren(new Option('PC auswählen',''));for(const d of devices)$('deviceSelect').add(new Option(d.device_name,d.id));if(!devices.some(d=>d.id===device)){device=devices.length===1?devices[0].id:'';chat='';} $('deviceSelect').value=device;save();const pc=devices.find(d=>d.id===device);$('connection').textContent=pc?(Date.now()-Date.parse(pc.last_seen_at)<70000?'ROBERT erreichbar':'ROBERT zuletzt offline'):'PC verbinden';}
function messageBody(text){const box=element('div','');const expression=/https?:\/\/[^\s<>]+/g;let last=0;for(const match of text.matchAll(expression)){box.append(document.createTextNode(text.slice(last,match.index)));const link=element('a',match[0]);link.href=match[0];link.rel='noopener noreferrer';box.append(link);last=match.index+match[0].length;}box.append(document.createTextNode(text.slice(last)));return box;}
function renderChatHeading(){const selected=chatRows.find(c=>c.id===chat);$('chatHeading').hidden=!selected;$('chatFullTitle').textContent=selected?.fullTitle||selected?.title||'';}
async function history(){renderChatHeading();const same=shownChat===chat;const previousTop=$('messages').scrollTop;if(!same)followOutput=true;shownChat=chat;if(!chat){$('messages').replaceChildren(element('p','Was möchtest du heute entwickeln?','welcome'));return;}const result=await job('history',{chatId:chat});$('messages').replaceChildren();for(const m of result.messages||[]){const box=element('article','','message '+m.role);box.append(element('small',m.role==='user'?'DU':'AUTOFORGE'),messageBody(m.content));$('messages').append(box);} $('messages').scrollTop=followOutput?$('messages').scrollHeight:previousTop;}
function renderChats(){const order=$('chatOrder').value;const rows=[...chatRows].sort((a,b)=>order==='oldest'?a.created.localeCompare(b.created):order==='newest'?b.created.localeCompare(a.created):(b.updated||b.created).localeCompare(a.updated||a.created));$('chatSelect').replaceChildren(new Option('Neues Gespräch',''));for(const c of rows)$('chatSelect').add(new Option(c.title+' · Erstellt '+new Date(c.created).toLocaleDateString('de-DE')+' · Zuletzt '+new Date(c.updated||c.created).toLocaleString('de-DE'),c.id));$('chatSelect').value=chat;renderChatHeading();}
async function chats(){const d=await job('list');chatRows=d.chats||[];renderChats();}
async function projects(){const d=await job('projects');$('projectList').replaceChildren();for(const p of d.projects||[]){const card=element('article','','card');card.append(element('h3',p.title),element('p',p.notes),element('small',p.quality),element('p','Vorschau im Windows-Programm unter Projekte.'));if(p.secondOpinion)card.append(element('p','KI-Zweitmeinung ('+p.secondOpinion.model+'): '+p.secondOpinion.text));const edit=element('button','Dieses Projekt überarbeiten');edit.onclick=()=>{$('baseId').value=p.id;$('projectPrompt').focus();notice('Neue Version von '+p.title);};card.append(edit);$('projectList').append(card);}if(!d.projects?.length)$('projectList').append(element('p','Hier erscheinen deine erstellten Programme.'));}
function renderLearning(data){const j=data.job;if(!j){$('learningStatus').textContent='Noch kein Lernlauf.';return;} $('learningStatus').textContent=j.message+' · '+j.processed+'/'+j.plan.length+' Quellen · '+j.percent+' %';$('learnProgress').value=j.percent;$('learnLog').textContent=j.events.map(e=>new Date(e.time).toLocaleTimeString()+'  '+e.message).join('\n');$('flow').textContent='Internet → '+j.completed+' Quellen → automatisch ins Gedächtnis\nDer Chat läuft lokal. Eine zweite lokale KI ist für Projekt-Einschätzungen optional.';$('sources').replaceChildren();for(const n of j.notes){const row=element('article','','card');row.append(element('h3',n.title),element('p',n.reason),element('p',n.text));const accept=element('button',n.accepted?'Automatisch gespeichert':'Speichern erneut versuchen');accept.disabled=n.accepted;accept.onclick=()=>action(async()=>{await job('learn-accept',{noteId:n.id});renderLearning(await job('learn-status'));});row.append(accept);$('sources').append(row);}}
async function learning(){renderPractice(await job('practice-status'));renderLearning(await job('learn-status'));const d=await job('storage');$('space').textContent=[['Lernquellen',d.research],['Chats & Wissen',d.memory],['Projekte',d.projects],['Modelle',d.models]].map(([k,v])=>k+': '+(v/1048576).toLocaleString('de-DE',{maximumFractionDigits:2})+' MB').join('\n');}
document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{document.querySelectorAll('main>section').forEach(p=>p.hidden=p.id!==b.dataset.page);document.querySelectorAll('[data-page]').forEach(x=>x.classList.toggle('active',x===b));if(b.dataset.page==='projects')action(projects);if(b.dataset.page==='learning')action(learning);});
$('settingsButton').onclick=()=>$('settings').open=!$('settings').open;
$('refresh').onclick=()=>action(async()=>{if(pending){const old=pending;const r=await poll();if(r.chatId){chat=r.chatId;device=old.device;save();}}await loadDevices();await chats();await history();notice('Aktuell.');});
$('newChat').onclick=()=>{chat='';save();$('chatSelect').value='';history();};
$('chatSelect').onchange=()=>action(async()=>{chat=$('chatSelect').value;save();await history();});
$('deviceSelect').onchange=()=>action(async()=>{device=$('deviceSelect').value;chat='';save();await chats();await history();});
$('chatForm').onsubmit=e=>{e.preventDefault();action(async()=>{const message=$('prompt').value.trim();if(!message)return;const r=await job('chat',{chatId:chat||null,message});chat=r.chatId;save();$('prompt').value='';await chats();await history();notice('Antwort gespeichert.');});};
$('projectForm').onsubmit=e=>{e.preventDefault();action(async()=>{const r=await job('project-build',{message:$('projectPrompt').value,baseId:$('baseId').value||undefined,review:$('review').checked});if(r.chatId){chat=r.chatId;save();}await projects();notice('Projekt erstellt. Vorschau am PC öffnen.');});};
$('freshProject').onclick=()=>{$('baseId').value='';notice('Neues Projekt.');};
$('learnForm').onsubmit=e=>{e.preventDefault();action(async()=>{if(!$('learnInternet').checked)throw Error('Bitte Internet für diesen Recherchelauf erlauben.');renderLearning(await job('learn-start',{learning:{topic:$('topic').value,cpuPercent:Number($('cpu').value),ramMb:Number($('ram').value),diskMb:Number($('disk').value),packages:Number($('packages').value),deadline:new Date($('deadline').value).toISOString()}}));});};
$('learnStop').onclick=()=>action(async()=>{if(pending)await poll();renderLearning(await job('learn-stop'));});
$('learnRefresh').onclick=()=>action(learning);
$('remember').onclick=()=>action(async()=>{await job('memory',{title:$('ideaTitle').value,body:$('idea').value});$('idea').value='';notice('Gedanke auf G gespeichert.');});
$('pair').onclick=()=>action(async()=>{await remote('pair_device',{code:$('pairCode').value});await loadDevices();notice('PC gekoppelt.');});
const deadline=new Date(Date.now()+3600000);$('deadline').value=new Date(deadline.getTime()-deadline.getTimezoneOffset()*60000).toISOString().slice(0,16);
setInterval(()=>{if(!document.hidden&&!$('learning').hidden&&!busy&&!pending&&$('live').checked)action(learning);},15000);
(async()=>{try{await bridge('cloudBootstrap');await loadDevices();if(pending)notice('Offener Auftrag: Aktualisieren tippen.');else if(device)await action(async()=>{await chats();await history();});}catch(e){notice(e.message);}controls();})();

$('deleteChat').onclick=()=>action(async()=>{if(!chat)return;if(!confirm('Diesen Chat löschen? Separat gespeicherte Notizen und Sicherungen bleiben erhalten.'))return;await job('delete-chat',{chatId:chat});chat='';save();await chats();await history();});

$('chatOrder').onchange=renderChats;
$('messages').addEventListener('scroll',()=>{const box=$('messages');followOutput=box.scrollHeight-box.scrollTop-box.clientHeight<40;$('followOutput').hidden=followOutput;},{passive:true});
$('followOutput').onclick=()=>{followOutput=true;$('messages').scrollTop=$('messages').scrollHeight;};


function renderPractice({run:r}){
 if(!r){practiceRunning=false;$('practiceStatus').textContent='Noch keine Übung auf diesem PC.';$('practiceLog').textContent='';$('practiceDetails').textContent='';$('practiceProgress').value=0;return;}
 practiceRunning=r.status==='running';
 const score=Number.isInteger(r.before)&&Number.isInteger(r.after)?' · Vorher '+r.before+'/3 → Nachher '+r.after+'/3':'';
 $('practiceStatus').textContent=r.message+score+' · '+r.completed+'/'+r.total+' Modellanfragen · '+(r.bytes/1024).toFixed(1)+' KB Ergebnisdaten';
 $('practiceProgress').value=r.completed;
 $('practiceLog').textContent=r.events.map(e=>new Date(e.time).toLocaleTimeString()+' '+e.message).join('\n');
 $('practiceDetails').textContent=r.results.map(x=>x.phase+': '+(x.passed?'bestanden':'nicht bestanden')+'\n'+(x.prompt||x.task)+'\n'+x.answer).join('\n\n')+'\n\nKandidat (nicht aktiviert):\n'+r.candidate;
 controls();
}
$('practiceForm').onsubmit=e=>{e.preventDefault();return action(async()=>renderPractice(await job('practice-start',{practice:{minutes:Number($('practiceMinutes').value),threads:Number($('practiceThreads').value)}})));};
$('practiceStop').onclick=()=>action(async()=>renderPractice(await job('practice-stop')));
$('practiceRefresh').onclick=()=>action(async()=>renderPractice(await job('practice-status')));
$('improveMobile').onclick=()=>{
 document.querySelectorAll('main>section').forEach(p=>p.hidden=p.id!=='learning');
 document.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page==='learning'));
 $('learningChoice').hidden=false;$('learningChoice').scrollIntoView({block:'start'});
 action(learning);
};
$('choosePractice').onclick=()=>{$('practiceForm').scrollIntoView({block:'center'});$('practiceMinutes').focus();};
$('chooseResearch').onclick=()=>{$('learnForm').scrollIntoView({block:'center'});$('topic').focus();};
